package demoJenkins;

import org.testng.annotations.Test;

public class DemoJenkinsJob {
	
	@Test
	public void testJenkins()
	{
		System.out.println("Welcome to world of Jenkins");
		
		
	}

}
