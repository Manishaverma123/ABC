package com.manulife.ap.steps;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
//import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.manulife.ap.listener.ListenerTest;

public class Utility {

		 // Excel file path
		 public static String XLS_FILE_PATH;
		 public static int r=0;
		 public static String values;

		public static void copydatafrommastertoinstance(String sheetname) throws Exception {
			
		 XLS_FILE_PATH = System.getProperty("user.dir") + "\\src\\main\\resources\\data\\"+ sheetname;
			
		 String testcase= ListenerTest.testcasename;
		 
		 FileInputStream file= new FileInputStream(XLS_FILE_PATH);
	
		 @SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(file);
		 // Getting sheet1
//		 Sheet sheet = workbook.getSheet("MasterSheet");
		 Sheet sheet = workbook.getSheetAt(1);
		 int rowsize= sheet.getLastRowNum()+1;
		 // Getting row at index 0 in sheet1
		 for(int i=0;i<rowsize;i++)
		 {
			String testdetails= sheet.getRow(i).getCell(0).toString();
			 System.out.println(testdetails);
			if(testdetails.equalsIgnoreCase(testcase))
			{
				r=i;
				break;
			}
		 }
		 
		 workbook.getSheetAt(0);
		 //row for headers
		 Row rowfields = sheet.getRow(r-1);
		 int rowLengthfields = rowfields.getPhysicalNumberOfCells();
//		 Row sheetTwo = workbook.getSheet("Home").createRow(0);
		 Row sheetTwo = workbook.getSheetAt(0).createRow(0);
		 for (int i = 0; i < rowLengthfields; i++) {
			 
			 Cell cell = sheetTwo.createCell(i);
			 Cell firstSheetCell = rowfields.getCell(i);
			 System.out.println(firstSheetCell.getStringCellValue());
			 cell.setCellValue(firstSheetCell.getStringCellValue());
			 }
		 System.out.println("gngh");
		 
//		 row for value
		 Row row = sheet.getRow(r);
		 int rowLength = row.getPhysicalNumberOfCells();
		 // Creating sheet2

		 // Creating row at index 0 in sheet2
//		 Row sheetTwoRow = workbook.getSheet("Home").createRow(1);
		 Row sheetTwoRow = workbook.getSheetAt(0).createRow(1);
		 // Setting value in row of sheet2 from sheet1
		 for (int i = 0; i < rowLength; i++) {
			 
		 Cell cell = sheetTwoRow.createCell(i);
		 Cell firstSheetCell = row.getCell(i);
		
		 try {
			values= firstSheetCell.getStringCellValue();
			System.out.println(firstSheetCell.getStringCellValue());
		} catch (Exception e) {
			// "" can be used to get string values
			values="";
		}
		 if(values!="")
		 {
		 cell.setCellValue(values);
		 }
		 }
		 System.out.println("gngh");
		 // Writing changes in Excel file

		 file.close();
		 
		 FileOutputStream outFile = new FileOutputStream(new File(XLS_FILE_PATH));
		 workbook.write(outFile);
		 outFile.close();
		 
		 
		 }
		 }

