package com.manulife.ap.steps.website.pages;

import org.openqa.selenium.JavascriptExecutor;

import com.qmetry.qaf.automation.ui.WebDriverBaseTestPage;
import com.qmetry.qaf.automation.ui.annotations.FindBy;
import com.qmetry.qaf.automation.ui.api.PageLocator;
import com.qmetry.qaf.automation.ui.api.WebDriverTestPage;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElement;
import com.qmetry.qaf.automation.util.StringMatcher;
import com.quantum.utils.DeviceUtils;

public class GooglePage extends WebDriverBaseTestPage<WebDriverTestPage> {

	@Override
	protected void openPage(PageLocator locator, Object... args) {
	}

	@FindBy(locator = "input.google.search.box")
	private QAFWebElement inputGoogleSearchBox;

	@FindBy(locator = "btn.google.search")
	private QAFWebElement btnGoogleSearch;

	@FindBy(locator = "lnk.google.search.results")
	private QAFWebElement lnkGoogleSearchResults;

	@FindBy(locator = "lnk.google.search.mobile.results")
	private QAFWebElement lnkGoogleSearchMobileResults;

	@FindBy(locator = "lnk.google.search.results.all")
	private QAFWebElement lnkGoogleSearchResultsAll;
	
	@FindBy(locator = "lnk.google.change.language")
	private QAFWebElement lnkGoogleChangeLanguage;

	public QAFWebElement getLnkGoogleSearchResultsAll() {
		return lnkGoogleSearchResultsAll;
	}

	public QAFWebElement getLnkGoogleSearchMobileResults() {
		return lnkGoogleSearchMobileResults;
	}

	public QAFWebElement getInputGoogleSearchBox() {
		return inputGoogleSearchBox;
	}

	public QAFWebElement getBtnGoogleSearch() {
		return btnGoogleSearch;
	}

	public QAFWebElement getLnkGoogleSearchResults() {
		return lnkGoogleSearchResults;
	}
	
	public QAFWebElement getLnkGoogleChangeLanguage() {
		return lnkGoogleChangeLanguage;
	}

	public void searchGoogle(String searchText) {
		getInputGoogleSearchBox().waitForVisible(15000);
		if(getLnkGoogleChangeLanguage().isPresent()) {
			getLnkGoogleChangeLanguage().click();
		}
		getInputGoogleSearchBox().click();
		getInputGoogleSearchBox().sendKeys(searchText);
		// getBtnGoogleSearch().click();
		JavascriptExecutor js = (JavascriptExecutor) DeviceUtils.getQAFDriver();
		js.executeScript("arguments[0].click();", getBtnGoogleSearch());
	}

	public void verifyGoogleResult(String linkText) {
		getLnkGoogleSearchResultsAll().waitForVisible(5000);
		if (getLnkGoogleSearchMobileResults().isPresent()) {
			getLnkGoogleSearchMobileResults().verifyText(StringMatcher.contains(linkText), "First link ");
		} else {
			getLnkGoogleSearchResults().verifyText(StringMatcher.contains(linkText), "First link ");
		}
	}

}
