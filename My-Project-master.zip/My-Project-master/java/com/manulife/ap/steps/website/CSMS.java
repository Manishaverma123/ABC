package com.manulife.ap.steps.website;


import static com.qmetry.qaf.automation.ui.webdriver.ElementFactory.$;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.support.ui.FluentWait;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.manulife.ap.Reusablefunction;
import com.manulife.ap.steps.Utility;
import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.util.QAFWebDriverWait;
import com.qmetry.qaf.automation.ui.util.QAFWebElementWait;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.DeviceUtils;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


import org.testng.annotations.Test;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;



@QAFTestStepProvider
public class CSMS extends Reusablefunction  {

	public static String language = "English";
	public static boolean retainExistingValue = true;
	public static String Surname, GivenName,ChineseName,NoOfDocs,BenificiaryAgeAbove18,Relationship,documentType,TrusteeSurname,TrusteeChineseName,TrusteeRelationship,TrusteedocumentType,TrusteeNoOfDocs,Percentageallocation;
    public static String Height,Weight,SmokingHabit,SmokingQuantity,DrinkingHabit,DrinkingUnits,FamilyMedicalHistory,SiblingMedicalHistory,InsuranceStatus,PersonalMedicalHistory;
    public static String HigherEducation,EmploymentStatus,MobileNumber,EmailAddress,ConfirmEmailAddress,Flat,NameOfBuilding,StreetNumber,CorrespondenceAddress,CorrespondenceFlat,CorrespondenceBuildingname,CorrespondenceStreetName,CorrespondenceLocation,Languagepreference;
	public static String FirstName,LastName,CardNumber,CVV,Month,Year;
	public static String Policyno,TransactionNo,TransactionDate,MerchantID,MerchantName,PurchaserName,TransactionAmount,MerchantOnlineAddress,MerchantContactNo,DescriptionOfGoodsService,TransactionType,AuthorizationCode;
	public static String url,Userid,Password,PolicyNo;
	public static String benificiaryrecId;
	/**
	 * 
	 * @param arg1
	 * @throws Throwable Launches AWS webpage in chrome browser for the requested
	 *                   URL Developed : Karthik Dhanapal
	 */
	@Given("^I launch CSMS in chrome \"([^\"]*)\"$")
	public void i_launch_CSMS_in_chrome(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("gngh");
		Thread.sleep(3000);
		// arg1 = "https://test.salesforce.com/";
		try {
			DeviceUtils.getQAFDriver().get(arg1);
//			DeviceUtils.getQAFDriver().get(arg1);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//		Thread.sleep(9000);
		

	}

	/**
	 * Login function for AWS System
	 * 
	 * @param arg1 - Username
	 * @param arg2 - Password
	 * @throws Throwable
	 * 
	 */
	@SuppressWarnings("unused")
//	@QAFTestStep(description="I login with CSMS user id as {0}")
	@When("^I login with CSMS user id as \"([^\"]*)\" agent and Password \"([^\"]*)\"$")
	public void iLoginWithCSMSUserIdAsAgentAndPassword(String arg1, String arg2) throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		new QAFExtendedWebElement("lnk.CSMS.login").click();
//		// SwitchWindow
//		SwitchTabandClose(DeviceUtils.getQAFDriver(), "CSMS", true, false);
		new QAFExtendedWebElement("input.CSMS.username").sendKeys(arg1);
		new QAFExtendedWebElement("input.CSMS.password").sendKeys(arg2);
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new QAFExtendedWebElement("btn.CSMS.LoginGO").click();
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		// SwitchWindow
		SwitchTabandClose(DeviceUtils.getQAFDriver(), "Contact History Reminder", true, false);

	}
	
	@SuppressWarnings("unused")
	@Then("^I enter value \"([^\"]*)\" for Voluntary Health Insurance Scheme Product having xpath as \"([^\"]*)\"$")
	public void dobVHIS(String arg1,String arg2) throws Throwable {
		
		waitclick(arg2);
//		new QAFExtendedWebElement(arg2).click();
		new QAFExtendedWebElement(arg2).sendKeys(arg1);

		waittime(1);
	}
	
	@SuppressWarnings("unused")
	@Then("^I enter height \"([^\"]*)\" and weight \"([^\"]*)\" for Voluntary Health Insurance Scheme Product$")
	public void heightweight(String arg1,String arg2) throws Throwable {
		
		waittime(3);
		DeviceUtils.getQAFDriver().findElements(By.xpath("//input[@class='biometric-input basic-input ng-untouched ng-pristine ng-invalid']")).get(0).sendKeys(arg1);
		waittime(1);
		DeviceUtils.getQAFDriver().findElement(By.xpath("//input[@class='biometric-input basic-input ng-untouched ng-pristine ng-invalid']")).sendKeys(arg2);
		waittime(1);
	}
	
	@SuppressWarnings("unused")
	@Then("^I enter HKID as \"([^\"]*)\" for Voluntary Health Insurance Scheme Product$")
	public void HKIDVHIS(String arg1) throws Throwable {
		
		waittime(1);
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		waitclick(arg1);
		new QAFExtendedWebElement("VHIS.HKID").sendKeys(arg1);
		waittime(1);
	}
	
	
	@SuppressWarnings("unused")
	@Then("^I enter value as \"([^\"]*)\" in the webpage having locator as \"([^\"]*)\"$")
	public void entervalue(String arg1,String arg2) throws Throwable {
		
		waittime(1);
		$(arg2).sendKeys(arg1);
		waittime(1);
	}
	
	@SuppressWarnings("unused")
	@Then("^I enter WebElement as \"([^\"]*)\" for XPATH as \"([^\"]*)\"$")
	public void M360EnterText(String arg1,String arg2) throws Throwable {
		
//		verifyobjectexists(arg1);
		new QAFExtendedWebElement(arg1).sendKeys(arg2);
		waittime(3);
	}
	
	@SuppressWarnings("unused")
	@Then("^I select education level as \"([^\"]*)\"$")
	public void educationlevel(String arg1) throws Throwable {

		switch(arg1.toUpperCase())
		{
		case"Primary":
			
			DeviceUtils.getQAFDriver().findElements(By.xpath("//label[contains(text(),'Education Level *')]/parent::div/mat-radio-group/mat-radio-button/label//div[@class='mat-radio-label-content']")).get(0).click();
			waittime(1);
			break;
			
		case"GCE":	
			
			DeviceUtils.getQAFDriver().findElements(By.xpath("//label[contains(text(),'Education Level *')]/parent::div/mat-radio-group/mat-radio-button/label//div[@class='mat-radio-label-content']")).get(1).click();
			waittime(1);
			break;
			
		case"Tertiary":
			
			DeviceUtils.getQAFDriver().findElements(By.xpath("//label[contains(text(),'Education Level *')]/parent::div/mat-radio-group/mat-radio-button/label//div[@class='mat-radio-label-content']")).get(2).click();
			waittime(1);
			break;

		
		}
		
	}
	
	
	@SuppressWarnings("unused")
	@Then("^we copy data from master sheet to instance sheet for the driver sheet named as \"([^\"]*)\"$")
	public void copydata(String sheetname) throws Throwable {
		
		waittime(1);
		Utility ele= new Utility();
		ele.copydatafrommastertoinstance(sheetname);
	
	}
	
	@SuppressWarnings("unused")
	@Then("^I enter the \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void details(String Surname1,String GivenName1,String ChineseName1) throws Throwable {
		
		waittime(1);
		System.out.println("gngh");
		DeviceUtils.getQAFDriver().findElements(By.xpath("//input[@class='basic-input ng-untouched ng-pristine ng-invalid']")).get(0).sendKeys(Surname1);
		waittime(1);
		DeviceUtils.getQAFDriver().findElements(By.xpath("//input[@class='basic-input ng-untouched ng-pristine ng-invalid']")).get(0).sendKeys(GivenName1);
		waittime(1);
		DeviceUtils.getQAFDriver().findElement(By.xpath("//input[@class='basic-input ng-untouched ng-pristine ng-invalid']")).sendKeys(ChineseName1);
		waittime(1);
	
	}

	
	@SuppressWarnings("unused")
	@Then("^I provide the xpath \"([^\"]*)\" and enter the value \"([^\"]*)\"$")
	public void enterVHIS(String xpath,String value) throws Throwable {
		
		waittime(1);
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
//		new QAFExtendedWebElement(xpath).click();
		waitclick(xpath);
		new QAFExtendedWebElement(xpath).sendKeys(value);
		waittime(1);
	}
	
	@SuppressWarnings("unused")
	@Then("^I take screenshots for the tested scenario \"([^\"]*)\"$")
	public void screenshot(String tc) throws Throwable {
		Reusablefunction scr= new Reusablefunction();
		scr.takeSnapShot(tc);
		waittime(1);
		
	}
	
	@SuppressWarnings("unused")
	@Then("^I take window screenshots for the tested scenario \"([^\"]*)\"$")
	public void windowscreenshot(String tc) throws Throwable {
		Reusablefunction scr= new Reusablefunction();
		scr.takewindowSnapShot(tc);
		waittime(1);
		
	}
	
	@SuppressWarnings("unused")
	@Then("^We store screenshots for TC \"([^\"]*)\"$")
	public void GroupScreenshots(String tc) throws Throwable {
		Reusablefunction scr= new Reusablefunction();
		scr.GroupScreenshots1(tc);
		waittime(1);
		
	}
	
	

	@And("^I retain existing value in fields \"([^\"]*)\"$")
	public void retainValue(String retainExistingValueInput) {
		// To Overwrite existing value
		if ("true".equalsIgnoreCase(retainExistingValueInput)) {
			retainExistingValue = true;
		} else {
			retainExistingValue = false;
		}
	}

	/**
	 * Verify the object is loaded for the requested page
	 * 
	 * @param arg1 - page object - XPATH
	 * @throws Throwable
	 */
	@When("^I verify \"([^\"]*)\" page is displayed$")
	public void i_verify_page_is_displayed(String arg1) throws Throwable {

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@When("^I input MCN \"([^\"]*)\"$")
	public void inputmcn(String mcn) throws InterruptedException {
		waittime(2);
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		retainExistingValue("input.CSMS.MCN", mcn, retainExistingValue);
		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	
	@When("^I input policy number \"([^\"]*)\"$")
	public void inputpolicy(String policy) throws InterruptedException {
		waittime(2);
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		retainExistingValue("input.CSMS.PolicyNumber", policy, retainExistingValue);
		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}

	@Then("^I click on the \"([^\"]*)\" button in customer search page$")
	public void clickbutton(String button) throws InterruptedException {
		DeviceUtils.getQAFDriver().switchTo().frame(0);
//		new QAFExtendedWebElement(button).click();
		waitclick(button);
		waittime(1);
		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	
	@SuppressWarnings("unused")
	public void waitclick(String locator) throws InterruptedException
	{
		WebDriverWait wait=new WebDriverWait(DeviceUtils.getQAFDriver(), 20);
		
		 Properties prop = new Properties();
		 
	        //Read configuration.properties file
	        try {
	            prop.load(new FileInputStream("./src/main/resources/web/CSMS.loc"));
	            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
	        } catch (IOException e) {
	            System.out.println("Configuration properties file cannot be found");
	        }
	 
	        //Get properties from configuration.properties
	    String locatorvalue = prop.getProperty(locator);
	    String arr[]= locatorvalue.split("xpath=");
	    
        System.out.println(arr[1]);
		WebElement webobj;
		
		webobj= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(arr[1])));
		waittime(3);
		webobj.click();
		waittime(2);
	}
	
	
	@SuppressWarnings("unused")
	public void dynamicwaitclick(String locator) throws Exception
	{

//		WebDriver driver = new ChromeDriver();
	
		
		propertyhandling(locator,"M360.loc");
//		$(locator).waitForPresent(40000);;
//		$(locator).click();
 
	}
	
	public void propertyhandling(String locator,String locfilename) throws Exception
	{
		
		
		
		Properties prop = new Properties();
		 
        //Read configuration.properties file
        try {
            prop.load(new FileInputStream("./src/main/resources/web/"+locfilename));
            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            System.out.println("Configuration properties file cannot be found");
        }
 
        //Get properties from configuration.properties
    String locatorvalue = prop.getProperty(locator);
    String arr[]= locatorvalue.split("xpath=");
    
    System.out.println("xpath="+arr[1]);
    
    NgWebDriver ngWebDriver = new NgWebDriver((JavascriptExecutor) DeviceUtils.getQAFDriver()); 
	
//	NgWebDriver ngWebDriver = new NgWebDriver((JavascriptExecutor)DeviceUtils.getQAFDriver());

//	DeviceUtils.getQAFDriver().findElement(ByAngular.model(arr[1])).click();
	
	ngWebDriver.waitForAngularRequestsToFinish();
	$(locator).click();
	
//	driver.findElement(ByAngular.model(“<locator>”).sendkeys(“<value>”);

//	
	
	
		
	}
	
	
	public void propertyhandlingangularjs(String locator,String locfilename) throws Exception
	{
		
		Properties prop = new Properties();
		 
        //Read configuration.properties file
        try {
            prop.load(new FileInputStream("./src/main/resources/web/"+locfilename));
            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            System.out.println("Configuration properties file cannot be found");
        }
 
        //Get properties from configuration.properties
    String locatorvalue = prop.getProperty(locator);
    String arr[]= locatorvalue.split("xpath=");
    
    System.out.println("xpath="+arr[1]);
    
    NgWebDriver ngWebDriver = new NgWebDriver((JavascriptExecutor) DeviceUtils.getQAFDriver()); 
	
//	NgWebDriver ngWebDriver = new NgWebDriver((JavascriptExecutor)DeviceUtils.getQAFDriver());

	DeviceUtils.getQAFDriver().findElement(ByAngular.model(arr[1])).click();
	
	ngWebDriver.waitForAngularRequestsToFinish();
	
//	driver.findElement(ByAngular.model(“<locator>”).sendkeys(“<value>”);

//	$(locator).click();
	
	
		
	}
	
	
	
	public void verifyobjectexists1(String locator,String locfilename) throws Exception
	{
		
		WebDriverWait wait=new WebDriverWait(DeviceUtils.getQAFDriver(), 30);
		Properties prop = new Properties();
		 
        //Read configuration.properties file
        try {
            prop.load(new FileInputStream("./src/main/resources/web/"+locfilename));
            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            System.out.println("Configuration properties file cannot be found");
        }
 
        //Get properties from configuration.properties
    String locatorvalue = prop.getProperty(locator);
    String arr[]= locatorvalue.split("xpath=");
    
    System.out.println(arr[1]);
	WebElement webobj;
	
	webobj= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(arr[1])));	
	
		
	}
	
	
	public void verifyobjectexists(String locator) throws Exception
	{
//	By name=(By)locator;
//		System.out.println("hjnfgh");
////		$(locator).waitForPresent(3000);
////		$(locator).waitForVisible();
//		@SuppressWarnings("unused")
		
//		com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebDriver.
//		QAFWebDriverWait  ref= new QAFWebDriverWait(DeviceUtils.getQAFDriver(), 20000, 2000);
		
		DeviceUtils.getQAFDriver().manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
	    
	    $(locator).waitForPresent();
	    
	    $(locator).click();
	    
		System.out.println("I am here");
	

	}
	
	public String fetchxpathfrompropertyfile(String locator,String locfilename) throws Exception
	{
		
		WebDriverWait wait=new WebDriverWait(DeviceUtils.getQAFDriver(), 20);
		
		Properties prop = new Properties();
		 
        //Read configuration.properties file
        try {
            prop.load(new FileInputStream("./src/main/resources/web/"+locfilename));
            //prop.load(this.getClass().getClassLoader().getResourceAsStream("configuration.properties"));
        } catch (IOException e) {
            System.out.println("Configuration properties file cannot be found");
        }
 
        //Get properties from configuration.properties
    String locatorvalue = prop.getProperty(locator);
    String arr[]= locatorvalue.split("xpath=");
    
    System.out.println(arr[1]);
    return arr[1];
		
	}
	
	
	@SuppressWarnings("unused")
	public void consentselectionvoicecall(String value) throws Exception
	{
		System.out.println("jhmfggfv");
		switch(value.toUpperCase())
		{
		
		case "YES":
			
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);",$("//mat-radio-button[@id='mat-radio-8']"));
			$("//mat-radio-button[@id='mat-radio-8']").click();
			Thread.sleep(2000);
			break;
			
		case "NO":
			
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);","//mat-radio-button[@id='mat-radio-9']");
			$("//mat-radio-button[@id='mat-radio-9']").click();
			Thread.sleep(2000);
			break;
		}
			
	}
	
	@SuppressWarnings("unused")
	public void consentselectionemail(String value) throws Exception
	{
		System.out.println("jhmfggfv");
		switch(value.toUpperCase())
		{
		
		case "YES":
			
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);",$("//mat-radio-button[@id='mat-radio-10']"));
			$("//mat-radio-button[@id='mat-radio-10']").click();
			Thread.sleep(2000);
			break;
			
		case "NO":
			
//			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0];","//input[@id='mat-radio-11-input' and @type='hidden']");
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);",$("//mat-radio-button[@id='mat-radio-11']"));
			$("//mat-radio-button[@id='mat-radio-11']").click();
			
			
			
			Thread.sleep(2000);
			break;
		}
			
	}
	
	@SuppressWarnings("unused")
	public void consentselectionsms(String value) throws Exception
	{
		System.out.println("jhmfggfv");
		switch(value.toUpperCase())
		{
		
		case "YES":
			
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);",$("//mat-radio-button[@id='mat-radio-12']"));
			$("//mat-radio-button[@id='mat-radio-12']").click();
			Thread.sleep(2000);
			break;
			
		case "NO":
			
			((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);","//mat-radio-button[@id='mat-radio-13']");
			$("//mat-radio-button[@id='mat-radio-13']").click();
			Thread.sleep(2000);
			break;
		}
			
	}
	
	public void waittime(int timeout) throws InterruptedException
	{	
		Thread.sleep(timeout*1000);
//		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
//		waittime(2);
	}
	
	
	@Then("^I select gender as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void genderoption(String gender) throws InterruptedException {
		
		switch(gender.toUpperCase()) {
		  case "MALE":
			  DeviceUtils.getQAFDriver().findElements(By.xpath("//div[@class='item float-left ng-star-inserted']")).get(0).click();
			  waittime(1);
		    break;
		  case "FEMALE":
			  DeviceUtils.getQAFDriver().findElements(By.xpath("//div[@class='item float-left ng-star-inserted']")).get(1).click();
			  waittime(1);
		    break;
		    
		  default:
		    // code block
		}
	}
	
	
	@Then("^I select smokinghabit as \"([^\"]*)\" option with number of cigarattes as \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void smokinghabit(String smoking,String cigarattesqnty) throws InterruptedException {
		
		System.out.println("ghgfgfgxh");
		switch(smoking.toUpperCase()) {
		  case "YES":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[3]/div[4]/div[2]/div/label")).click();
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[3]/div[5]/div[2]/div/div/input")).sendKeys(cigarattesqnty);
			  
		    break;
		  case "NO":  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[3]/div[4]/div[1]/div/label")).click();
		    break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Drinking Habit as \"([^\"]*)\" option with drinking unit as \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void DrinkingHabit(String smoking,String cigarattesqnty) throws InterruptedException {
		
		System.out.println("ghgfgfgxh");
		switch(smoking.toUpperCase()) {
		  case "YES":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[4]/div[4]/div[2]/div/label")).click();
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[4]/div[5]/div[2]/div/div[1]/input")).sendKeys(cigarattesqnty);  
		    break;
		  case "NO":
              DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[4]/div[4]/div[1]/div/label")).click(); 
		    break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Family medical history as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void Familymedicalhistory(String history) throws InterruptedException {
		
		switch(history.toUpperCase()) {
		  case "YES":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[5]/div[4]/div[2]/div/label")).click();
			  waittime(1);
		    break;
		  case "NO":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[5]/div[4]/div[1]/div/label")).click();
			  waittime(1);
		    break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select HKID type as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void selecthkidtype(String history) throws InterruptedException {
		
		switch(history.toUpperCase()) {
		  case "PERMANENT":
			  
			  DeviceUtils.getQAFDriver().findElements(By.xpath("//div[@class='item float-left ng-star-inserted']")).get(0).click();
			  waittime(1);
		    break;
		  case "NONPERMAMENT":
			 
			  DeviceUtils.getQAFDriver().findElements(By.xpath("//div[@class='item float-left ng-star-inserted']")).get(1).click();
			  waittime(1);
		    break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Siblings medical history as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void Siblingsmedicalhistory(String history) throws InterruptedException {
		
		switch(history.toUpperCase()) {
		  case "YES":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[5]/div[6]/div[2]/div/label")).click();
			  waittime(1);
		    break;
		  case "NO":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[5]/div[6]/div[1]/div/label")).click();
			  waittime(1);
		    break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Personal medical history as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void Personalmedicalhistory(String Personal) throws InterruptedException {
		
		 System.out.println("dfvdfhfghfgd");
		switch(Personal.toUpperCase()) {
		  case "YES":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[4]/div[2]/div/label")).click();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[6]/div[2]/div/label")).click();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[8]/div[2]/div/label")).click();
			  
		      DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[10]/div[2]/div/label")).click();
		      
		      break;
		  case "NO":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[4]/div[1]/div/label")).click();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[6]/div[1]/div/label")).click();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[8]/div[1]/div/label")).click();
			  
		      DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[6]/div[10]/div[1]/div/label")).click();
		      
			  break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Insurance status as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void InsuranceStatus(String Personal) throws InterruptedException {
		
		switch(Personal.toUpperCase()) {
		  case "YES":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[7]/div[4]/div[2]/div/label")).click();
			  waittime(1);
		      break;
		  case "NO":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-uw/div/div/div/div/div/div[2]/form/div[7]/div[4]/div[1]/div/label")).click();
			  waittime(1);
			  break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select highest education level as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void highesteducationlevel(String education) throws InterruptedException {
		
		System.out.println("dfvdfhfghfgd");
		switch(education) {
		  case "University & above":
		
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[5]/div[1]/div/label")).click();
			  waittime(1);
		      break;
		  case "Post-secondary / college":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[5]/div[2]/div/label")).click();
			  waittime(1);
			  break;
		  case "Secondary school":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[6]/div[1]/div/label")).click();
			  waittime(1);
			  break;
		  case "Primary school or below":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[6]/div[2]/div/label")).click();
			  waittime(1);
			  break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select Who is going to be the beneficiary of this policy as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void beneficiaryforthispolicy(String benifi) throws InterruptedException {
		
		
		System.out.println("dfvdfhfghfgd");
		List<WebElement> benificiary= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='item float-left ng-star-inserted']/div"));
		int size= benificiary.size();
		for(int i=0; i<size;i++)
		{
		String whobenificiary= benificiary.get(i).getText();
		if(whobenificiary.equalsIgnoreCase(benifi))
		{
			benificiary.get(i).click();
			waittime(2);
			break;
		}	
		}
	}
	
	
//	@Then("^I Get Trackers Devices By MoveKey {MoveKey} and Country {Country}")
//
//	public void getTrackersDevicesByMoveKey(String MoveKey,String Country){
//
//	       ConfigurationManager.getBundle().addProperty("MoveKey", MoveKey);
//	       ConfigurationManager.getBundle().addProperty("Country", Country);
//	       RestRequestBean bean = new RestRequestBean();
//
//	       bean.fillData("get.MOVE5.getTrackersDevicesByMoveKey");
//	       bean.resolveParameters(null);
//
//	       WsStep.request(bean);      
//
//	       String Status = new RestTestBase().getResponse().getStatus().toString();
//	       if (Status.equalsIgnoreCase("Ok")){
//	             assert true;
//	             System.out.println("Test Step Passed: Status code is coming as 200 !");
//
//	       String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
//	       //JSONObject reader = new JSONObject(myResponse);
//	       JSONArray reader = new JSONArray(myResponse);
//
//	       for(int i=0;i<reader.length()-1;i++){
//	       JSONObject reader1 = reader.getJSONObject(i);
//	       String strtype=reader1.getString("type");
//
//	       String strplatform=reader1.getString("platform");
//
//	       //String struserId= (String) reader.getJSONObject("member").getString("userId");
//
//	       //String struserId=reader.getJSONArray("0").getJSONObject("UserId")
//
//	       //String strCountry= (String) reader.getJSONObject("member").getString("country");
//	       System.out.println(strtype);
//
//	       System.out.println(strplatform);
//
//	if(strplatform.equalsIgnoreCase("fitbit") || strplatform.equalsIgnoreCase("misfit")||strplatform.equalsIgnoreCase("android")||strplatform.equalsIgnoreCase("ios")){
//
//	       System.out.println("Test Step Passed");
//	             assert true;
//	       }
//
//	       else{
//	             System.out.println("Test Step  Failed");
//	             assert false;
//	           }  
//
//	       }
//	       }
//	       else{
//	             System.out.println("Test Step Failed: Status Code is not Coming as 200 !");
//	             assert false;
//
//	       }
//	}

	
	@Then("^I add dynamically primary benificiary based on input sheet testcase \"([^\"]*)\"$")
	public void beneficiaryaddition(String recId) throws Throwable {
		
		System.out.println("Start Reading Excel....");
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(4); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
//		ExtentReporting ref= new ExtentReporting();
//		ref.startReport("Excel Jason Request");

		///////////////////////xlsx file READ /////////////////////////////////////////
		
		System.out.println("Fetching Data from Excel....");
		
         for(int i=1;i<=rowCount;i++){ 
            
//        	 logger = extent.startTest("testname"+ i);
        	 
        	   System.out.println("################# Executing TC Number: " +i+ "###################");
        	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
        	   Surname = sheet.getRow(i).getCell(1).toString();
        	   
            if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
            {
				GivenName = sheet.getRow(i).getCell(2).toString();
				ChineseName = sheet.getRow(i).getCell(3).toString();
				NoOfDocs = sheet.getRow(i).getCell(4).toString();
				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(5).toString();
				Relationship = sheet.getRow(i).getCell(6).toString();
				documentType = sheet.getRow(i).getCell(7).toString();
				Percentageallocation=sheet.getRow(i).getCell(8).toString();
				TrusteeSurname = sheet.getRow(i).getCell(9).toString();
				TrusteeChineseName = sheet.getRow(i).getCell(10).toString();
				TrusteeRelationship = sheet.getRow(i).getCell(11).toString();
				TrusteedocumentType = sheet.getRow(i).getCell(12).toString();
				TrusteeNoOfDocs = sheet.getRow(i).getCell(13).toString();
				
				
				primarybeneficiary("Add primary beneficiary");
				surnamegivenname("surname",Surname);
				surnamegivenname("GivenName",GivenName);
				surnamegivenname("ChineseName",ChineseName);
				relationship(Relationship);
				documenttype(documentType);
				surnamegivenname("Docs",NoOfDocs);
				benificiaryage(BenificiaryAgeAbove18);
				
				trusteesurnamegivenname("surname",TrusteeSurname);
				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
				trusteerelationship(TrusteeRelationship);
				trusteedocumenttype(TrusteedocumentType);
				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
				System.out.println("Mish");
				
//				screenshot("testname");
				
				Thread.sleep(2000);
				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
				
//				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
				Thread.sleep(2000);
				try {
					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
//					Thread.sleep(2000);
					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
					Thread.sleep(8000);
					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
                }  


               System.out.println("################# Executing TC for Benificiary 2 ###################");
//         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                
         	   try {
				Surname = sheet.getRow(i).getCell(14).toString();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						Surname="";
					}
         	   
             if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
             {
 				GivenName = sheet.getRow(i).getCell(15).toString();
 				ChineseName = sheet.getRow(i).getCell(16).toString();
 				NoOfDocs = sheet.getRow(i).getCell(17).toString();
 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(18).toString();
 				Relationship = sheet.getRow(i).getCell(19).toString();
 				documentType = sheet.getRow(i).getCell(20).toString();
 				Percentageallocation=sheet.getRow(i).getCell(21).toString();
 				TrusteeSurname = sheet.getRow(i).getCell(22).toString();
 				TrusteeChineseName = sheet.getRow(i).getCell(23).toString();
 				TrusteeRelationship = sheet.getRow(i).getCell(24).toString();
 				TrusteedocumentType = sheet.getRow(i).getCell(25).toString();
 				TrusteeNoOfDocs = sheet.getRow(i).getCell(26).toString();
 				
 				
 				primarybeneficiary("Add primary beneficiary");
 				surnamegivenname("surname",Surname);
 				surnamegivenname("GivenName",GivenName);
 				surnamegivenname("ChineseName",ChineseName);
 				relationship(Relationship);
 				documenttype(documentType);
 				surnamegivenname("Docs",NoOfDocs);
 				benificiaryage(BenificiaryAgeAbove18);
 				
 				trusteesurnamegivenname("surname",TrusteeSurname);
 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 				trusteerelationship(TrusteeRelationship);
 				trusteedocumenttype(TrusteedocumentType);
 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 				System.out.println("Mish");
 				
// 				screenshot("testname");
 				
 				Thread.sleep(2000);
 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 				
// 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 				Thread.sleep(2000);
 				try {
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 					Thread.sleep(2000);
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 					Thread.sleep(8000);
 					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
 				} catch (Exception e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				}
             }
 				
 			  System.out.println("################# Executing TC for Benificiary 3 ###################");
//         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                
         	   try {
				Surname = sheet.getRow(i).getCell(27).toString();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						Surname="";
					}
             if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
             {
 				GivenName = sheet.getRow(i).getCell(28).toString();
 				ChineseName = sheet.getRow(i).getCell(29).toString();
 				NoOfDocs = sheet.getRow(i).getCell(30).toString();
 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(31).toString();
 				Relationship = sheet.getRow(i).getCell(32).toString();
 				documentType = sheet.getRow(i).getCell(33).toString();
 				Percentageallocation=sheet.getRow(i).getCell(34).toString();
 				TrusteeSurname = sheet.getRow(i).getCell(35).toString();
 				TrusteeChineseName = sheet.getRow(i).getCell(36).toString();
 				TrusteeRelationship = sheet.getRow(i).getCell(37).toString();
 				TrusteedocumentType = sheet.getRow(i).getCell(38).toString();
 				TrusteeNoOfDocs = sheet.getRow(i).getCell(39).toString();
 				
 				
 				primarybeneficiary("Add primary beneficiary");
 				surnamegivenname("surname",Surname);
 				surnamegivenname("GivenName",GivenName);
 				surnamegivenname("ChineseName",ChineseName);
 				relationship(Relationship);
 				documenttype(documentType);
 				surnamegivenname("Docs",NoOfDocs);
 				benificiaryage(BenificiaryAgeAbove18);
 				
 				trusteesurnamegivenname("surname",TrusteeSurname);
 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 				trusteerelationship(TrusteeRelationship);
 				trusteedocumenttype(TrusteedocumentType);
 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 				System.out.println("Mish");
 				
// 				screenshot("testname");
 				
 				Thread.sleep(2000);
 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 				
// 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 				Thread.sleep(2000);
 				try {
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 					Thread.sleep(2000);
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 					Thread.sleep(8000); 
 					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
	 				} catch (Exception e) {
	 					// TODO Auto-generated catch block
	 					e.printStackTrace();
	 				}
             }
 				  System.out.println("################# Executing TC for Benificiary 4 ###################");
// 	         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
 	                
 	         	   try {
 					Surname = sheet.getRow(i).getCell(40).toString();
	 				} catch (Exception e1) {
	 					// TODO Auto-generated catch block
	 					Surname="";
	 				}
                 if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
                 {
 	 				GivenName = sheet.getRow(i).getCell(41).toString();
 	 				ChineseName = sheet.getRow(i).getCell(42).toString();
 	 				NoOfDocs = sheet.getRow(i).getCell(43).toString();
 	 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(44).toString();
 	 				Relationship = sheet.getRow(i).getCell(45).toString();
 	 				documentType = sheet.getRow(i).getCell(46).toString();
 	 				Percentageallocation=sheet.getRow(i).getCell(47).toString();
 	 				TrusteeSurname = sheet.getRow(i).getCell(48).toString();
 	 				TrusteeChineseName = sheet.getRow(i).getCell(49).toString();
 	 				TrusteeRelationship = sheet.getRow(i).getCell(50).toString();
 	 				TrusteedocumentType = sheet.getRow(i).getCell(51).toString();
 	 				TrusteeNoOfDocs = sheet.getRow(i).getCell(52).toString();
 	 				
 	 				
 	 				primarybeneficiary("Add primary beneficiary");
 	 				surnamegivenname("surname",Surname);
 	 				surnamegivenname("GivenName",GivenName);
 	 				surnamegivenname("ChineseName",ChineseName);
 	 				relationship(Relationship);
 	 				documenttype(documentType);
 	 				surnamegivenname("Docs",NoOfDocs);
 	 				benificiaryage(BenificiaryAgeAbove18);
 	 				
 	 				trusteesurnamegivenname("surname",TrusteeSurname);
 	 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 	 				trusteerelationship(TrusteeRelationship);
 	 				trusteedocumenttype(TrusteedocumentType);
 	 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 	 				System.out.println("Mish");
 	 				
// 	 				screenshot("testname");
 	 				
 	 				Thread.sleep(2000);
 	 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 	 				
// 	 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 	 				Thread.sleep(2000);
 	 				try {
 	 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 	 					Thread.sleep(2000);
 	 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 	 					Thread.sleep(8000); 
// 	 					DeviceUtils.getQAFDriver().findElement(By.xpath("//div[@class='header']")).click();
 	 					Robot robot = new Robot();
 	 				    // Simulate key Events
 	 					robot.keyPress(KeyEvent.VK_TAB);
 	 				    robot.keyRelease(KeyEvent.VK_TAB);
 						Thread.sleep(3000);
	 	 				} catch (Exception e) {
	 	 					// TODO Auto-generated catch block
	 	 					e.printStackTrace();
	 	 				}
                 }	
 				
                 }  
                 }
	
	@Then("^I add dynamically secondary benificiary based on input sheet testcase \"([^\"]*)\"$")
	public void secondarybeneficiaryaddition(String recId) throws Throwable {
		
		System.out.println("Start Reading Excel....");
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(5); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
//		ExtentReporting ref= new ExtentReporting();
//		ref.startReport("Excel Jason Request");

		///////////////////////xlsx file READ /////////////////////////////////////////
		
		System.out.println("Fetching Data from Excel....");
		
         for(int i=1;i<=rowCount;i++){ 
            
//        	 logger = extent.startTest("testname"+ i);
        	 
        	   System.out.println("################# Executing TC Number: " +i+ "###################");
			try {
				benificiaryrecId = sheet.getRow(i).getCell(0).toString();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				benificiaryrecId=null;
			}
        	   try {
				Surname = sheet.getRow(i).getCell(1).toString();
			} catch (Exception e2) {
				// TODO Auto-generated catch block
				Surname="";
			}
        	   
            if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
            {
				GivenName = sheet.getRow(i).getCell(2).toString();
				ChineseName = sheet.getRow(i).getCell(3).toString();
				NoOfDocs = sheet.getRow(i).getCell(4).toString();
				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(5).toString();
				Relationship = sheet.getRow(i).getCell(6).toString();
				documentType = sheet.getRow(i).getCell(7).toString();
				Percentageallocation=sheet.getRow(i).getCell(8).toString();
				TrusteeSurname = sheet.getRow(i).getCell(9).toString();
				TrusteeChineseName = sheet.getRow(i).getCell(10).toString();
				TrusteeRelationship = sheet.getRow(i).getCell(11).toString();
				TrusteedocumentType = sheet.getRow(i).getCell(12).toString();
				TrusteeNoOfDocs = sheet.getRow(i).getCell(13).toString();
				
				
				secondarybeneficiary("Add secondary beneficiary");
				surnamegivenname("surname",Surname);
				surnamegivenname("GivenName",GivenName);
				surnamegivenname("ChineseName",ChineseName);
				relationship(Relationship);
				documenttype(documentType);
				surnamegivenname("Docs",NoOfDocs);
				benificiaryage(BenificiaryAgeAbove18);
				
				trusteesurnamegivenname("surname",TrusteeSurname);
				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
				trusteerelationship(TrusteeRelationship);
				trusteedocumenttype(TrusteedocumentType);
				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
				System.out.println("Mish");
				
//				screenshot("testname");
				
				Thread.sleep(2000);
				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
				
//				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
				Thread.sleep(2000);
				try {
					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
//					Thread.sleep(2000);
					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
					Thread.sleep(8000);
					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
					
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
                }  


               System.out.println("################# Executing TC for Benificiary 2 ###################");
//         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                
         	   try {
				Surname = sheet.getRow(i).getCell(14).toString();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						Surname="";
					}
         	   
             if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
             {
 				GivenName = sheet.getRow(i).getCell(15).toString();
 				ChineseName = sheet.getRow(i).getCell(16).toString();
 				NoOfDocs = sheet.getRow(i).getCell(17).toString();
 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(18).toString();
 				Relationship = sheet.getRow(i).getCell(19).toString();
 				documentType = sheet.getRow(i).getCell(20).toString();
 				Percentageallocation=sheet.getRow(i).getCell(21).toString();
 				TrusteeSurname = sheet.getRow(i).getCell(22).toString();
 				TrusteeChineseName = sheet.getRow(i).getCell(23).toString();
 				TrusteeRelationship = sheet.getRow(i).getCell(24).toString();
 				TrusteedocumentType = sheet.getRow(i).getCell(25).toString();
 				TrusteeNoOfDocs = sheet.getRow(i).getCell(26).toString();
 				
 				
 				secondarybeneficiary("Add secondary beneficiary");
 				surnamegivenname("surname",Surname);
 				surnamegivenname("GivenName",GivenName);
 				surnamegivenname("ChineseName",ChineseName);
 				relationship(Relationship);
 				documenttype(documentType);
 				surnamegivenname("Docs",NoOfDocs);
 				benificiaryage(BenificiaryAgeAbove18);
 				
 				trusteesurnamegivenname("surname",TrusteeSurname);
 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 				trusteerelationship(TrusteeRelationship);
 				trusteedocumenttype(TrusteedocumentType);
 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 				System.out.println("Mish");
// 				screenshot("testname");
 				Thread.sleep(2000);
 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 				
// 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 				Thread.sleep(2000);
 				try {
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 					Thread.sleep(2000);
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 					Thread.sleep(8000);
 					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
 				} catch (Exception e) {
 					// TODO Auto-generated catch block
 					e.printStackTrace();
 				}
             }
 				
 			  System.out.println("################# Executing TC for Benificiary 3 ###################");
//         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                
         	   try {
				Surname = sheet.getRow(i).getCell(27).toString();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						Surname="";
					}
             if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
             {
 				GivenName = sheet.getRow(i).getCell(28).toString();
 				ChineseName = sheet.getRow(i).getCell(29).toString();
 				NoOfDocs = sheet.getRow(i).getCell(30).toString();
 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(31).toString();
 				Relationship = sheet.getRow(i).getCell(32).toString();
 				documentType = sheet.getRow(i).getCell(33).toString();
 				Percentageallocation=sheet.getRow(i).getCell(34).toString();
 				TrusteeSurname = sheet.getRow(i).getCell(35).toString();
 				TrusteeChineseName = sheet.getRow(i).getCell(36).toString();
 				TrusteeRelationship = sheet.getRow(i).getCell(37).toString();
 				TrusteedocumentType = sheet.getRow(i).getCell(38).toString();
 				TrusteeNoOfDocs = sheet.getRow(i).getCell(39).toString();
 				
 				
 				secondarybeneficiary("Add secondary beneficiary");
 				surnamegivenname("surname",Surname);
 				surnamegivenname("GivenName",GivenName);
 				surnamegivenname("ChineseName",ChineseName);
 				relationship(Relationship);
 				documenttype(documentType);
 				surnamegivenname("Docs",NoOfDocs);
 				benificiaryage(BenificiaryAgeAbove18);
 				
 				trusteesurnamegivenname("surname",TrusteeSurname);
 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 				trusteerelationship(TrusteeRelationship);
 				trusteedocumenttype(TrusteedocumentType);
 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 				System.out.println("Mish");
// 				screenshot("testname");
 				Thread.sleep(2000);
 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 				
// 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 				Thread.sleep(2000);
 				try {
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 					Thread.sleep(2000);
 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 					Thread.sleep(8000); 
 					Robot robot = new Robot();
	 				    // Simulate key Events
	 					robot.keyPress(KeyEvent.VK_TAB);
	 				    robot.keyRelease(KeyEvent.VK_TAB);
						Thread.sleep(3000);
	 				} catch (Exception e) {
	 					// TODO Auto-generated catch block
	 					e.printStackTrace();
	 				}
             }
 				  System.out.println("################# Executing TC for Benificiary 4 ###################");
// 	         	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
 	                
 	         	   try {
 					Surname = sheet.getRow(i).getCell(40).toString();
	 				} catch (Exception e1) {
	 					// TODO Auto-generated catch block
	 					Surname="";
	 				}
                 if((recId.equalsIgnoreCase(benificiaryrecId)) && (!Surname.equals("")))
                 {
 	 				GivenName = sheet.getRow(i).getCell(41).toString();
 	 				ChineseName = sheet.getRow(i).getCell(42).toString();
 	 				NoOfDocs = sheet.getRow(i).getCell(43).toString();
 	 				BenificiaryAgeAbove18 = sheet.getRow(i).getCell(44).toString();
 	 				Relationship = sheet.getRow(i).getCell(45).toString();
 	 				documentType = sheet.getRow(i).getCell(46).toString();
 	 				Percentageallocation=sheet.getRow(i).getCell(47).toString();
 	 				TrusteeSurname = sheet.getRow(i).getCell(48).toString();
 	 				TrusteeChineseName = sheet.getRow(i).getCell(49).toString();
 	 				TrusteeRelationship = sheet.getRow(i).getCell(50).toString();
 	 				TrusteedocumentType = sheet.getRow(i).getCell(51).toString();
 	 				TrusteeNoOfDocs = sheet.getRow(i).getCell(52).toString();
 	 				
 	 				
 	 				secondarybeneficiary("Add secondary beneficiary");
 	 				surnamegivenname("surname",Surname);
 	 				surnamegivenname("GivenName",GivenName);
 	 				surnamegivenname("ChineseName",ChineseName);
 	 				relationship(Relationship);
 	 				documenttype(documentType);
 	 				surnamegivenname("Docs",NoOfDocs);
 	 				benificiaryage(BenificiaryAgeAbove18);
 	 				
 	 				trusteesurnamegivenname("surname",TrusteeSurname);
 	 				trusteesurnamegivenname("ChineseName",TrusteeChineseName);
 	 				trusteerelationship(TrusteeRelationship);
 	 				trusteedocumenttype(TrusteedocumentType);
 	 				trusteesurnamegivenname("Docs",TrusteeNoOfDocs);
 	 				System.out.println("Mish");
// 	 				screenshot("testname");
 	 				Thread.sleep(2000);
 	 				DeviceUtils.getQAFDriver().findElements(By.xpath("//button[@class='basic-button']")).get(1).click();
 	 				
// 	 				DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@class='header']")).click();
 	 				Thread.sleep(2000);
 	 				try {
 	 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-untouched ng-pristine ng-valid']")).get(0).clear();
// 	 					Thread.sleep(2000);
 	 					DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text-allocation ng-pristine ng-valid ng-touched']")).get(0).sendKeys(Percentageallocation);
 	 					Thread.sleep(8000); 
// 	 					DeviceUtils.getQAFDriver().findElement(By.xpath("//div[@class='header']")).click();
 	 					Robot robot = new Robot();
 	 				    // Simulate key Events
 	 					robot.keyPress(KeyEvent.VK_TAB);
 	 				    robot.keyRelease(KeyEvent.VK_TAB);
 						Thread.sleep(3000);
	 	 				} catch (Exception e) {
	 	 					// TODO Auto-generated catch block
	 	 					e.printStackTrace();
	 	 				}
                 }	
 				
                 }  
                 }
	
	
	@Then("^I provide the health information details \"([^\"]*)\"$")
	public void healthinfo(String recId) throws Throwable {
		
		System.out.println("Start Reading Excel....");
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(1); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
//		ExtentReporting ref= new ExtentReporting();
//		ref.startReport("Excel Jason Request");

		///////////////////////xlsx file READ /////////////////////////////////////////
		
		System.out.println("Fetching Data from Excel....");
		
         for(int i=1;i<=rowCount;i++){ 
            
//        	 logger = extent.startTest("testname"+ i);
        	 
        	   System.out.println("################# Executing TC Number: " +i+ "###################");
        	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                if(recId.equalsIgnoreCase(benificiaryrecId))
                {
                	Height = sheet.getRow(i).getCell(1).toString();
                	Weight = sheet.getRow(i).getCell(2).toString();
                	SmokingHabit = sheet.getRow(i).getCell(3).toString();
                	SmokingQuantity = sheet.getRow(i).getCell(4).toString();
                	DrinkingHabit = sheet.getRow(i).getCell(5).toString();
                	DrinkingUnits = sheet.getRow(i).getCell(6).toString();
                	FamilyMedicalHistory = sheet.getRow(i).getCell(7).toString();
                	SiblingMedicalHistory=sheet.getRow(i).getCell(8).toString();
                	InsuranceStatus = sheet.getRow(i).getCell(9).toString();
                	PersonalMedicalHistory = sheet.getRow(i).getCell(10).toString();
                	
                	heightweight(Height,Weight);
//                	dobVHIS(Height,"VHIS.Height");
//                	dobVHIS(Weight,"VHIS.Weight");
                	smokinghabit(SmokingHabit,SmokingQuantity);
                	DrinkingHabit(DrinkingHabit,DrinkingUnits);
                	Familymedicalhistory(FamilyMedicalHistory);
                	Siblingsmedicalhistory(SiblingMedicalHistory);
                	Personalmedicalhistory(PersonalMedicalHistory);
                	InsuranceStatus(InsuranceStatus);
				
				         }        
	}
	}
	
	@Then("^I provide the education and address information details \"([^\"]*)\"$")
	public void educationandaddress(String recId) throws Throwable {
		
		System.out.println("Start Reading Excel....");
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(2); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
//		ExtentReporting ref= new ExtentReporting();
//		ref.startReport("Excel Jason Request");

		///////////////////////xlsx file READ /////////////////////////////////////////
		
		System.out.println("Fetching Data from Excel....");
		
         for(int i=1;i<=rowCount;i++){ 
            
//        	 logger = extent.startTest("testname"+ i);
        	 
        	   System.out.println("################# Executing TC Number: " +i+ "###################");
        	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                if(recId.equalsIgnoreCase(benificiaryrecId))
                {
                	HigherEducation = sheet.getRow(i).getCell(1).toString();
                	EmploymentStatus = sheet.getRow(i).getCell(2).toString();
                	MobileNumber = sheet.getRow(i).getCell(3).toString();
                	EmailAddress = sheet.getRow(i).getCell(4).toString();
                	ConfirmEmailAddress = sheet.getRow(i).getCell(5).toString();
                	Flat = sheet.getRow(i).getCell(6).toString();
                	NameOfBuilding = sheet.getRow(i).getCell(7).toString();
                	StreetNumber=sheet.getRow(i).getCell(8).toString();
                	CorrespondenceAddress = sheet.getRow(i).getCell(9).toString();
                	CorrespondenceFlat = sheet.getRow(i).getCell(10).toString();
                	CorrespondenceBuildingname = sheet.getRow(i).getCell(11).toString();
                	CorrespondenceStreetName = sheet.getRow(i).getCell(12).toString();
                	CorrespondenceLocation = sheet.getRow(i).getCell(13).toString();
                	Languagepreference = sheet.getRow(i).getCell(14).toString();

                	highesteducationlevel(HigherEducation);
                	employmentstatus(EmploymentStatus);
                	clickfirst1("VHIS.Background.Next.click");
                	dobVHIS(MobileNumber,"VHIS.MobileNumber");
                	dobVHIS(EmailAddress,"VHIS.EmailAddress");
                	dobVHIS(ConfirmEmailAddress,"VHIS.ConfirmEmailAddress");
                	dobVHIS(Flat,"VHIS.Flat");
                	dobVHIS(NameOfBuilding,"VHIS.NameOfBuilding");
                	dobVHIS(StreetNumber,"VHIS.StreetNumber");
                	correspondenceaddress(CorrespondenceAddress,CorrespondenceFlat,CorrespondenceBuildingname,CorrespondenceStreetName,CorrespondenceLocation);
                	LanguagePreference(Languagepreference);
       
				
				         }        
	}
	}
	
	@Then("^I provide the payment information details \"([^\"]*)\"$")
	public void payment(String recId) throws Throwable {
		
		System.out.println("Start Reading Excel....");
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(3); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
//		ExtentReporting ref= new ExtentReporting();
//		ref.startReport("Excel Jason Request");

		///////////////////////xlsx file READ /////////////////////////////////////////
		
		System.out.println("Fetching Data from Excel....");
		
         for(int i=1;i<=rowCount;i++){ 
            
//        	 logger = extent.startTest("testname"+ i);
        	 
        	   System.out.println("################# Executing TC Number: " +i+ "###################");
        	   String benificiaryrecId = sheet.getRow(i).getCell(0).toString();
                if(recId.equalsIgnoreCase(benificiaryrecId))
                {
                	FirstName = sheet.getRow(i).getCell(1).toString();
                	LastName = sheet.getRow(i).getCell(2).toString();
                	CardNumber = sheet.getRow(i).getCell(3).toString();
                	CVV = sheet.getRow(i).getCell(4).toString();
                	Month = sheet.getRow(i).getCell(5).toString();
                	Year = sheet.getRow(i).getCell(6).toString();
                	
                	dobVHIS(FirstName,"VHIS.FirstName");
                	dobVHIS(LastName,"VHIS.LastName");
                	dobVHIS(CardNumber,"VHIS.CardNumber");
                	dobVHIS(CVV,"VHIS.CVV");
                	month(Month);
                	year(Year);                	
				
				         }        
	}
	}

	
	@Then("^I click on add beneficiary as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void primarybeneficiary(String benifi) throws InterruptedException {
		
//		benifi ="Add primary beneficiary";
//		WebElement element = driver.findElement(By.id("gbqfd"));
		
		List<WebElement> benificiary= DeviceUtils.getQAFDriver().findElements(By.xpath("//span[@class='ng-star-inserted']"));
		int size= benificiary.size();
		for(int i=0; i<size;i++)
		{
		String whobenificiary= benificiary.get(i).getText();
		System.out.println(whobenificiary);
		waittime(1);
		if(whobenificiary.equalsIgnoreCase(benifi) || whobenificiary.equalsIgnoreCase("Add another primary beneficiary"))
		{
			JavascriptExecutor executor = (JavascriptExecutor)DeviceUtils.getQAFDriver();
			executor.executeScript("arguments[0].click();", benificiary.get(i));
//			benificiary.get(i).click();
			waittime(1);
			break;
			
		}	
		}
	}
	
	@Then("^I click on add secondary beneficiary as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void secondarybeneficiary(String benifi) throws InterruptedException {
		
//		benifi ="Add primary beneficiary";
//		WebElement element = driver.findElement(By.id("gbqfd"));
		
		List<WebElement> benificiary= DeviceUtils.getQAFDriver().findElements(By.xpath("//span[@class='ng-star-inserted']"));
		int size= benificiary.size();
		for(int i=0; i<size;i++)
		{
		String secondarybenificiary= benificiary.get(i).getText();
		System.out.println(secondarybenificiary);
		waittime(1);
		if(secondarybenificiary.equalsIgnoreCase(benifi) || secondarybenificiary.equalsIgnoreCase("Add another secondary beneficiary"))
		{
			JavascriptExecutor executor = (JavascriptExecutor)DeviceUtils.getQAFDriver();
			executor.executeScript("arguments[0].click();", benificiary.get(i));
//			benificiary.get(i).click();
			waittime(1);
			break;
			
		}	
		}
	}
	
	@Then("^I enter benificiary details for \"([^\"]*)\" option and enter detail as \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void surnamegivenname(String benifi,String args) throws InterruptedException {
		
		List<WebElement> names= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text ng-untouched ng-pristine ng-invalid']"));                    
		List<WebElement> chinesenoofdocs= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='input-text ng-untouched ng-pristine ng-valid']"));
		int size= names.size();
		int size1= chinesenoofdocs.size();
		
		switch(benifi.toUpperCase()) {
		
		  case "SURNAME":
			  for(int i=0; i<size;i++)
				{
				  names.get(0).sendKeys(args);
				break;
				}	
		      break;
		      
		  case "GIVENNAME":
				  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[1]/div[2]/app-input-box/div/div/div/input")).sendKeys(args);
		      break;
		  case "CHINESENAME":
			  for(int i=0; i<size1;i++)
				{
				  chinesenoofdocs.get(0).sendKeys(args);
				break;
				}	
		      break;
		  case "DOCS":
				  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[3]/div[2]/app-input-box/div/div/div/input")).sendKeys(args);
		      break;    
		  default:
		    // code block
		}
		
		
	}
	
	@Then("^I enter trustee details for \"([^\"]*)\" option and enter detail as \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void trusteesurnamegivenname(String trustee,String args) throws InterruptedException {
		
		switch(trustee.toUpperCase()) {
		
		  case "SURNAME":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[6]/div[3]/div[1]/app-input-box/div/div/div/input")).sendKeys(args);
		      break; 
		  case "CHINESENAME":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[6]/div[3]/div[2]/app-input-box/div/div/div/input")).sendKeys(args);
		      break;
		  case "DOCS":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[6]/div[5]/div/app-input-box/div/div/div/input")).sendKeys(args);
		      break;    
		  default:
		    // code block
		}
		
		
	}
	
	@Then("^I select current employment status as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void employmentstatus(String employmentstatus) throws InterruptedException {
		
		System.out.println("dfvdfhfghfgd");
		switch(employmentstatus) {
		
		  case "I have a full-time / part-time job":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[9]/div[1]/div/label")).click();
		      break;
		  case "I am a housewife":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[9]/div[2]/div/label")).click();
			  break;
		  case "I am a full-time student":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[10]/div[1]/div/label")).click();
			  break;
		  case "I am retired":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[10]/div[2]/div/label")).click();
			  break;
		  case "I am unemployed":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-edu-occ-info/form/div/div/div/div/div/div[2]/div[11]/div/div/label")).click();
			  waittime(1);
			  break;
		    
		  default:
		    // code block
		}
	}
	
	@Then("^I select correspondence address as \"([^\"]*)\" option and update flat as \"([^\"]*)\" and building name as \"([^\"]*)\" and street name as \"([^\"]*)\" and select location as \"([^\"]*)\" in Voluntary Health Insurance Scheme Product page$")
	public void correspondenceaddress(String correspondenceaddress,String flat,String building,String streetname,String locationname) throws InterruptedException {
		
		System.out.println("dfvdfghfgd");
		switch(correspondenceaddress.toUpperCase()) {
		  case "YES":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[16]/div/div/div[1]/div/label")).click();
			  waittime(1);
		      break;
		  case "NO":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[16]/div/div/div[2]/div/label")).click();
		
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[1]/div/app-input-box/div/div/div/input")).clear();;
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[2]/div/app-input-box/div/div/div/input")).clear();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[3]/div/app-input-box/div/div/div/input")).clear();
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[4]/div/div[2]/div/app-solid-line-auto-complete-input-box/div/input")).clear();
			  
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[1]/div/app-input-box/div/div/div/input")).sendKeys(flat);
			  
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[2]/div/app-input-box/div/div/div/input")).sendKeys(building);
			  
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[3]/div/app-input-box/div/div/div/input")).sendKeys(streetname);
			  
			  
			  WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[17]/div[4]/div/div[2]/div/app-solid-line-auto-complete-input-box/div/input"));
				mySelectElement.click();
				List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@id='mat-autocomplete-2']/mat-option/span"));
				int size= dropdown1.size();
				for(int i=0;i<size;i++)
				{
					String xyz= dropdown1.get(i).getText();
					System.out.println(xyz);
					if(xyz.equalsIgnoreCase(locationname))
					{
						dropdown1.get(i).click();
						break;
					}
					}
			  
			  break;
		  default:
		    // code block
		}
		System.out.println("dfvdfhfghfgd");
	}
	
	@Then("^I select Language preference as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void LanguagePreference(String languagepreference) throws InterruptedException {
		
		System.out.println("dfvdfhfghfgd");
		switch(languagepreference.toUpperCase()) {
		
		  case "ENGLISH":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[21]/div/div/div[1]/div/label")).click();
		      break;
		  case "CHINESE":
			  
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/app-root/app-main/app-vhis-contact-info/form/div/div/div/div/div/div[2]/div[21]/div/div/div[2]/div/label")).click();
			  break;
		  default:
		    // code block
		}
	}
	
	@Then("^I select whether benificiary age is under eighteern or above as \"([^\"]*)\" option in Voluntary Health Insurance Scheme Product page$")
	public void benificiaryage(String benificiaryage) throws InterruptedException {
		
		System.out.println("dfvdfhfghfgd");
		switch(benificiaryage.toUpperCase()) {
		
		  case "YES":
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[5]/div[1]/div/label")).click();
		      break;
		  case "NO":
				
			  DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[5]/div[2]/div/label")).click();
				
			  break;
		  default:
		    // code block
		}
	}
	
	
	
	@Then("^I click on the \"([^\"]*)\" Webelement in Voluntary Health Insurance Scheme Product page$")
	public void clickfirst1(String obj) throws InterruptedException {
	
		waitclick(obj);
		waittime(3);	
	}
	
	@Then("^I click on \"([^\"]*)\" Webelement in WebPage$")
	public void clickm360(String obj) throws Exception {
	
//		dynamicwaitclick(obj);
		//verifyobjectexists(obj);
		Thread.sleep(2000);
		$(obj).click();
		
	}
	
	
	@Then("^I click on the angular object \"([^\"]*)\" Webelement in WebPage$")
	public void clickangularm360(String obj) throws Exception {
	
		dynamicwaitclick(obj);
		//verifyobjectexists(obj);
		
//		$(obj).click();
//		Thread.sleep(2000);
	}
	
	@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and select gender as \"([^\"]*)\" for spouse in WebPage$")
	public void spousedetails(String title,String lastname,String middlename,String firstname,String age,String dateofbirth,String occupation,String gender) throws Exception {
	
		System.out.println("manish");
		
		String btnclick= "//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::mat-select[@aria-label=\"Title\"]";
		iselectdropdown(btnclick ,"M360.PersonalInformation.Nationality.Container",title);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Last name\"]").sendKeys(lastname);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Middle name\"]").sendKeys(middlename);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"First name\"]").sendKeys(firstname);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Age\"]").sendKeys(age);
		Thread.sleep(1000);
		
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Date of Birth (DD/MM/YYYY)\"]").sendKeys(dateofbirth);
		Thread.sleep(1000);

		String occupbtnclick= "//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content//input[@placeholder=\"Occupation \"]";
		$(occupbtnclick).sendKeys(occupation);
		Thread.sleep(1000);
		
		switch(gender.toUpperCase())
		{
		
		case"MALE":
		DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(text(),'Spouse information')]/parent::*/parent::*/following-sibling::*//div[@class='mat-radio-label-content']")).get(0).click();
		break;
		
		case"FEMALE":
			DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(text(),'Spouse information')]/parent::*/parent::*/following-sibling::*//div[@class='mat-radio-label-content']")).get(1).click();
			break;
		}
		
		Thread.sleep(10000);
		
	}
	
	@Then("^I enter \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and select gender as \"([^\"]*)\" for spouse in WebPage$")
	public void childdetails(String title,String lastname,String middlename,String firstname,String age,String dateofbirth,String occupation,String gender) throws Exception {
	
		System.out.println("manish");
		
		String btnclick= "//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::mat-select[@aria-label=\"Title\"]";
		iselectdropdown(btnclick ,"M360.PersonalInformation.Nationality.Container",title);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Last name\"]").sendKeys(lastname);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Middle name\"]").sendKeys(middlename);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"First name\"]").sendKeys(firstname);
		Thread.sleep(1000);
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Age\"]").sendKeys(age);
		Thread.sleep(1000);
		
		$("//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content/child::*//child::input[@placeholder=\"Date of Birth (DD/MM/YYYY)\"]").sendKeys(dateofbirth);
		Thread.sleep(1000);

		String occupbtnclick= "//*[contains(text(),'Spouse information')]/parent::*//parent::mat-card-title/following-sibling::mat-card-content//input[@placeholder=\"Occupation \"]";
		$(occupbtnclick).sendKeys(occupation);
		Thread.sleep(1000);
		
		switch(gender.toUpperCase())
		{
		
		case"MALE":
		DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(text(),'Spouse information')]/parent::*/parent::*/following-sibling::*//div[@class='mat-radio-label-content']")).get(0).click();
		break;
		
		case"FEMALE":
			DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(text(),'Spouse information')]/parent::*/parent::*/following-sibling::*//div[@class='mat-radio-label-content']")).get(1).click();
			break;
		}
		
		Thread.sleep(10000);
		
	}

	
	@Then("^I scroll and select the terms and conditions \"([^\"]*)\" for Webelement in WebPage$")
	public void scrollselect(String obj) throws Exception {
	
		System.out.println("manish");
		dynamicwaitclick(obj);
		waittime(6);	
	}
	
	@Then("^I select voice call consent values \"([^\"]*)\" in WebPage$")
	public void consent(String obj) throws Exception {
	
		consentselectionvoicecall(obj);
		waittime(1);	
	}
	
	@Then("^I select email consent values \"([^\"]*)\" in WebPage$")
	public void consentemail(String obj) throws Exception {
	
		consentselectionemail(obj);
		waittime(1);	
	}
	
	@Then("^I select sms consent values \"([^\"]*)\" in WebPage$")
	public void consentsms(String obj) throws Exception {
	
		consentselectionsms(obj);
		waittime(1);	
	}
	

	@Then("^I wait for some time for Webelement in Voluntary Health Insurance Scheme Product page$")
	public void clickfirst6() throws InterruptedException {
		waittime(4);	
	}
	
	@Then("^I click on the MPI simulator \"([^\"]*)\" Webelement in Voluntary Health Insurance Scheme Product page$")
	public void clickfirst2(String obj) throws InterruptedException {
		waitclick(obj);
		waittime(10);
	}
	
	@Then("^I capture the details in the driver sheet for the test case \"([^\"]*)\"$")
	public void transactioncapture(String testcaseno) throws Exception {
		
	
		System.out.println("Getting the insurance details from UI");	
		List<WebElement> benificiary= DeviceUtils.getQAFDriver().findElements(By.xpath("//div[@class='row table-row-padding']/div[@class='col-12 col-md-8 field-value']"));
		
		  int size= benificiary.size();
		  
			for(int j=0; j<1;j++)
			{
			Policyno = benificiary.get(0).getText();
			TransactionNo = benificiary.get(1).getText();
			TransactionDate = benificiary.get(2).getText();
			MerchantID = benificiary.get(3).getText();
			MerchantName = benificiary.get(4).getText();
			PurchaserName = benificiary.get(5).getText();
			TransactionAmount = benificiary.get(6).getText();
			MerchantOnlineAddress = benificiary.get(7).getText();
			MerchantContactNo = benificiary.get(8).getText();
			DescriptionOfGoodsService = benificiary.get(9).getText();
			TransactionType = benificiary.get(10).getText();
			AuthorizationCode = benificiary.get(11).getText();
			}


		System.out.println("Start Reading Excel....");
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(6); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);
		
		System.out.println("Fetching Data from Excel....");

       for(int i=1;i<=rowCount;i++){ 
    	   
    	   String recId = sheet.getRow(i).getCell(0).toString();

    	   
        if(recId.equalsIgnoreCase(testcaseno))
        { 
        	 
		  System.out.println("################# Getting the insurance details from UI: " +i+ "###################");
		  OutputStream os = new FileOutputStream("./src/main/resources/data/VHISDirectSelling.xls");
		  Row r = sheet.getRow(i); 

		  Cell PolicyNumber = r.getCell(4); 
		  PolicyNumber = r.createCell(4);
		  PolicyNumber.setCellValue(Policyno);
		  
		  Cell TransactionNumber = r.getCell(5); 
		  TransactionNumber = r.createCell(5);
		  TransactionNumber.setCellValue(TransactionNo);
		  
		  Cell Transaction_Date = r.getCell(6); 
		  Transaction_Date = r.createCell(6);
		  Transaction_Date.setCellValue(TransactionDate);
		  
		  Cell Merchant_ID = r.getCell(7); 
		  Merchant_ID = r.createCell(7);
		  Merchant_ID.setCellValue(MerchantID);
		  
		  Cell Merchant_Name = r.getCell(8); 
		  Merchant_Name = r.createCell(8);
		  Merchant_Name.setCellValue(MerchantName);
		  
		  Cell Purchaser_Name = r.getCell(9); 
		  Purchaser_Name = r.createCell(9);
		  Purchaser_Name.setCellValue(PurchaserName);
		  
		  Cell Transaction_Amount = r.getCell(10); 
		  Transaction_Amount = r.createCell(10);
		  Transaction_Amount.setCellValue(TransactionAmount);
		  
		  Cell Merchant_OnlineAddress = r.getCell(11); 
		  Merchant_OnlineAddress = r.createCell(11);
		  Merchant_OnlineAddress.setCellValue(MerchantOnlineAddress);
		  
		  Cell Merchant_ContactNo = r.getCell(12); 
		  Merchant_ContactNo = r.createCell(12);
		  Merchant_ContactNo.setCellValue(MerchantContactNo);
		  
		  Cell Description_OfGoodsService = r.getCell(13); 
		  Description_OfGoodsService = r.createCell(13);
		  Description_OfGoodsService.setCellValue(DescriptionOfGoodsService);
		  
		  Cell Transaction_Type = r.getCell(14); 
		  Transaction_Type = r.createCell(14);
		  Transaction_Type.setCellValue(TransactionType);
		  
		  Cell Authorization_Code = r.getCell(15); 
		  Authorization_Code = r.createCell(15);
		  Authorization_Code.setCellValue(AuthorizationCode);

		  workbook.write(os);
		  
        }
       }
	}
	
	@Then("^I validate the details in the CSMS based on the testcase number \"([^\"]*)\"$")
	public void CSMSValidation(String testcaseno) throws Throwable {
		
		File file = new File("./src/main/resources/data/VHISDirectSelling.xls");
		FileInputStream inputStream = new FileInputStream(file);
		
		///////////////////////xlsx file Object /////////////////////////////////////////
		
		System.out.println("Creating Excel Object....");
		@SuppressWarnings("resource")
		HSSFWorkbook workbook = new HSSFWorkbook(inputStream);
		HSSFSheet sheet = workbook.getSheetAt(6); 
		
		///////////////////////xlsx file ROW Count /////////////////////////////////////////
		
		System.out.println("Fetching Row Column Count....");
		Row row = sheet.getRow(0);
		int rowCount = sheet.getLastRowNum();
		System.out.println("Row Count :- " + rowCount);
		int colCount = row.getLastCellNum();
		System.out.println("Column Count :- " + colCount);

	
	System.out.println("Fetching Data from Excel....");
	
     for(int i=1;i<=rowCount;i++){ 
        
    	   String recId = sheet.getRow(i).getCell(0).toString();
    	   
        if(recId.equalsIgnoreCase(testcaseno))
        {
			url = sheet.getRow(i).getCell(1).toString();
			Userid = sheet.getRow(i).getCell(2).toString();
			Password = sheet.getRow(i).getCell(3).toString();
			PolicyNo = sheet.getRow(i).getCell(4).toString();
		
			System.out.println("Launch the CSMS Browser");
			Thread.sleep(2000);
			// arg1 = "https://test.salesforce.com/";

			DeviceUtils.getQAFDriver().get(url);
			Thread.sleep(2000);
			DeviceUtils.getQAFDriver().manage().window().maximize();
			Thread.sleep(2000);
			iLoginWithCSMSUserIdAsAgentAndPassword(Userid, Password);
			inputpolicy(PolicyNo);
			Robot robot = null;
			 
		        try {
		            robot = new Robot();
		        } catch (AWTException e) {
		            e.printStackTrace();
		        }
			
			robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(250);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	    	Thread.sleep(950);
	    	
	    	DeviceUtils.getQAFDriver().switchTo().frame(0).findElement(By.xpath("//a[contains(@href,'csms_main.jsp?action=idm_cs003_01_plus_minus')]")).click();
	    	Thread.sleep(450);
	    	JavascriptExecutor executor = (JavascriptExecutor)DeviceUtils.getQAFDriver();
			executor.executeScript("arguments[0].click();", DeviceUtils.getQAFDriver().findElement(By.xpath("//div[@id='title1']/table/tbody/tr/td[2]/a")));
//			benificiary.get(i).click();
			Thread.sleep(2000);
//	    	DeviceUtils.getQAFDriver().switchTo().frame(0).findElement(By.xpath("//a[@href='csms_main.jsp?action=csm_customer_search']")).click()
//	    	Thread.sleep(450);
	    	DeviceUtils.getQAFDriver().findElement(By.xpath("//a[@href='csms_main.jsp?action=nb_workbench']")).click();
	    	Thread.sleep(450);
	    	SwitchTabandClosenewfunc(DeviceUtils.getQAFDriver(), "NB Workbench",PolicyNo);
	    	Thread.sleep(650);
	    	
//	    	DeviceUtils.getQAFDriver().close();
			
        }	
        }
	}
	
	 		

	
//	@Then("^I click on the \"([^\"]*)\" Webelement in Voluntary Health Insurance Scheme Product page$")
//	public void healthnextclick(String obj) throws InterruptedException {
//		
//	Thread.sleep(3000);	
//	new QAFExtendedWebElement(obj).click();
//	Thread.sleep(000);
//		
//	}
	
	
	@Then("^I upload documents \"([^\"]*)\" for Voluntary Health Insurance Scheme Product page$")
	
	public void uploadFileWithRobotupload(String imagePath) throws Exception {
		Reusablefunction obj= new Reusablefunction();
		obj.uploadFileWithRobot(imagePath);
    
}


	@Then("^I click on the \"([^\"]*)\" button in CDM page$")
	public void clickbutton2(String button) throws InterruptedException {
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		new QAFExtendedWebElement(button).click();
		Thread.sleep(2000);
	}

	@Then("^we maximize the window$")
	public void maximize() throws InterruptedException {
		DeviceUtils.getQAFDriver().manage().window().maximize();
		Thread.sleep(2000);
	}
	
	@And("^I click on pop up button to save finally$")
	public void handlepopup() throws InterruptedException {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		try {
			DeviceUtils.getQAFDriver().switchTo().alert().accept();
		} catch (Exception e) {
			System.out.println(e);
		}

		Thread.sleep(2000);
//		if (new QAFExtendedWebElement("txt.CSMS.CompleteStatus").getText().contains("Save Completed")) {
//			Assert.assertTrue("Execution Completed", true);
//		} else {
//			Assert.assertTrue("Execution Completed", false);
//		}

		Thread.sleep(2000);
	}

	@Then("^I navigate to contact data maintenance page to update details$")
	public void innavigate() {
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		new QAFExtendedWebElement("link.CSMS.ContactDataMaintenance").click();
		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}

	@And("^I select the address language as \"([^\"]*)\"$")
	public void iselectLang(String lang) throws InterruptedException {

		if (!lang.isEmpty() && lang != null) {
			language = lang;
		} else {
			language = "English";
		}
		SwitchTabandClose(DeviceUtils.getQAFDriver(), "Contact Data Maintenance", false, true);
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		String currentLang = new QAFExtendedWebElement("radio.CSMS.Lang").getAttribute("value");
		if (lang.equalsIgnoreCase("ENGLISH") && currentLang.equals("C")) {
			new QAFExtendedWebElement("radio.CSMS.ELang").click();
		} else if (lang.equalsIgnoreCase("CHINESE") && currentLang.equals("E")) {
			new QAFExtendedWebElement("radio.CSMS.CLang").click();
		}
		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@When("^I select address No \"([^\"]*)\"$")
	public void iselectAddressNo(String AddrsNo) throws Exception {
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (AddrsNo != null) {
			if (!AddrsNo.isEmpty()) {
				selectdropdown("//*[@id=\"addr_nr\"]", AddrsNo);
			}
		}
		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I select residence \"([^\"]*)\"$")
	public void iselectresidence(String residence) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (residence != null) {
			if (!residence.isEmpty()) {
				newselectdropdown(residence);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I select relationship to you as \"([^\"]*)\"$")
	public void relationship(String relationship) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (relationship != null) {
			if (!relationship.isEmpty()) {
				relationshipselectdropdown(relationship);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I click on the dropdown \"([^\"]*)\" using the container locator \"([^\"]*)\" and select value \"([^\"]*)\"$")
	public void iselectdropdown(String btnclick ,String containerid,String value ) throws Exception {
		
		System.out.println("Masfghfh");
		WebElement mySelectElement = $(btnclick);
		((JavascriptExecutor)DeviceUtils.getQAFDriver()).executeScript("arguments[0].scrollIntoView(true);",mySelectElement);
		Thread.sleep(1000);
		mySelectElement.click();
		Thread.sleep(1000);
		
		String containerxpath = fetchxpathfrompropertyfile(containerid,"M360.loc");
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath(containerxpath));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.contains(value))
			{
				JavascriptExecutor executor = (JavascriptExecutor)DeviceUtils.getQAFDriver();
				executor.executeScript("arguments[0].click();", dropdown1.get(i));
//				dropdown1.get(i).click();
				break;
			}
			}
	}


	
	
	
	
	
	@When("^I click on the dropdown \"([^\"]*)\" using the container locator \"([^\"]*)\" and select value \"([^\"]*)\"$")
	public void iselectdropdown1(String btnclick ,String containerid,String value ) throws Exception {
		
		System.out.println("Masfghfh");
		WebElement mySelectElement = $(btnclick);
		Thread.sleep(2000);
		mySelectElement.click();
		String containerxpath = fetchxpathfrompropertyfile(containerid,"M360.loc");
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath(containerxpath));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(value))
			{
				JavascriptExecutor executor = (JavascriptExecutor)DeviceUtils.getQAFDriver();
				executor.executeScript("arguments[0].click();", dropdown1.get(i));
//				dropdown1.get(i).click();
				break;
			}
			}
	}

	
	
	
	
	
	
	
		
	
	@When("^I select month as \"([^\"]*)\"$")
	public void month(String month) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		waittime(1);
		if (month != null) {
			if (!month.isEmpty()) {
				monthdropdown(month);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I select year as \"([^\"]*)\"$")
	public void year(String year) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		waittime(2);
		if (year != null) {
			if (!year.isEmpty()) {
				yeardropdown(year);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@Then("^I click on disclaimer in the payment settings$")
	public void paymentdisclaimer() throws Exception {
		waittime(2);
		disclaimer();
			}

	
	@When("^I select document type as \"([^\"]*)\"$")
	public void documenttype(String documenttype) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (documenttype != null) {
			if (!documenttype.isEmpty()) {
				documenttypeselectdropdown(documenttype);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I select trustee relationship to you as \"([^\"]*)\"$")
	public void trusteerelationship(String trusteerelationship) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (trusteerelationship != null) {
			if (!trusteerelationship.isEmpty()) {
				trusteerelationshipselectdropdown(trusteerelationship);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	
	@When("^I select trustee document type as \"([^\"]*)\"$")
	public void trusteedocumenttype(String trusteedocumenttype) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (trusteedocumenttype != null) {
			if (!trusteedocumenttype.isEmpty()) {
				trusteedocumenttypeselectdropdown(trusteedocumenttype);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}
	

	
	@When("^I select nationality \"([^\"]*)\"$")
	public void nationality(String nationality) throws Exception {
//		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (nationality != null) {
			if (!nationality.isEmpty()) {
				new1selectdropdown(nationality);
			}
		}
		
//		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}

	@Then("^I update \"([^\"]*)\" Flat_floor_buliding \"([^\"]*)\" , street \"([^\"]*)\" , district \"([^\"]*)\" and country \"([^\"]*)\" details$")
	public void flatdetails(String lang, String flat, String street, String district, String country)
			throws InterruptedException {
		boolean Flag = true;
		boolean FlagCh = true;
		// Switch window

		DeviceUtils.getQAFDriver().manage().window().maximize();

		SwitchTabandClose(DeviceUtils.getQAFDriver(), "Contact Data Maintenance", false, true);
		DeviceUtils.getQAFDriver().switchTo().frame(0);

		boolean CurrentLang = DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@name='addr_lang' and @value='E']"))
				.isSelected();

		if (CurrentLang) {
			lang = "English";
		} else {
			lang = "Chinese";
		}

		if (lang.equalsIgnoreCase("English")) {

			for (int i = 1; i <= 10; i++) {
				if (Flag) {
					try {
						if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@name='c_addr_line1_" + i + "']"))
								.isPresent()) {
							if (flat != null && !flat.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line1_" + i + "']", flat, retainExistingValue);
							}
							if (street != null && !street.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line2_" + i + "']", street, retainExistingValue);
							}
							if (district != null && !district.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line3_" + i + "']", district,
										retainExistingValue);
							}
							if (country != null && !country.isEmpty()) {
								retainExistingValue("//*[@name='addr_residential_code_" + i + "input']", country,
										retainExistingValue);
							}
							Flag = false;
						}
					} catch (Exception e) {
					}
				} else {
					break;
				}
			}
		}

		if (lang.equalsIgnoreCase("Chinese")) {
			for (int i = 1; i <= 10; i++) {
				if (FlagCh) {
					try {
						if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@name='c_addr_line2_" + i + "']"))
								.isPresent()) {
							if (country != null) {
								if (!country.isEmpty()) {
									if (DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@name='c_addr_line2_" + i + "']")).isPresent()) {
										selectdropdown("//*[@id='addrtemplate_C" + i
												+ "']/td[1]/table/tbody/tr[1]/td[2]/select", country);
									}
								}
							}

							if (district != null && !district.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line2_" + i + "']", district,
										retainExistingValue);
							}
							if (street != null && !street.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line3_" + i + "']", street, retainExistingValue);
							}
							if (flat != null && !flat.isEmpty()) {
								retainExistingValue("//*[@name='c_addr_line4_" + i + "']", flat, retainExistingValue);
							}
							Flag = false;
						}
					} catch (Exception e) {

					}

				} else {
					break;
				}
			}
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@And("^I select invalid signal \"([^\"]*)\"$")
	public void iinvalidSignal(String Signal) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);
		boolean Flag = true;

		for (int i = 1; i <= 10; i++) {
			if (Flag) {
				try {
					if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@name='addr_invalid_signal_" + i + "']"))
							.isPresent()) {
						if (Signal.equalsIgnoreCase("Yes")) {
							DeviceUtils.getQAFDriver()
									.findElement(By.xpath("//*[@name='addr_invalid_signal_" + i + "' and @value='Y']"))
									.click();
						} else if (Signal.equalsIgnoreCase("No")) {
							DeviceUtils.getQAFDriver()
									.findElement(By.xpath("//*[@name='addr_invalid_signal_" + i + "' and @value='N']"))
									.click();
						}
						Flag = false;
					}
				} catch (Exception e) {

				}
			} else {
				break;
			}
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@Then("^I update residential country \"([^\"]*)\" , phone \"([^\"]*)\" and invalidsignal \"([^\"]*)\"$")
	public void iUpdateResidentialCountry(String country, String Phone, String invalidSignal) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (country != null && !country.isEmpty()) {
			retainExistingValue("dropdown.CSMS.residentialCountry", country, retainExistingValue);
		}

		if (Phone != null && !Phone.isEmpty()) {
			retainExistingValue("input.CSMS.residentialPhone", Phone, retainExistingValue);
		}

		if (invalidSignal.equalsIgnoreCase("Yes")) {
			new QAFExtendedWebElement("radio.CSMS.ResidSignalY").click();
		} else if (invalidSignal.equalsIgnoreCase("No")) {
			new QAFExtendedWebElement("radio.CSMS.ResidSignalN").click();
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();
	}

	@Then("^I update mobile country \"([^\"]*)\" , phone \"([^\"]*)\" , invalidsignal \"([^\"]*)\" and mobileSamecontact \"([^\"]*)\"$")
	public void iUpdatemobileCountry(String country, String Phone, String invalidSignal, String sameContact) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);

		if (country != null && !country.isEmpty()) {
			retainExistingValue("dropdown.CSMS.mobileCountry", country, retainExistingValue);
		}

		if (Phone != null && !Phone.isEmpty()) {
			retainExistingValue("input.CSMS.mobilePhone", Phone, retainExistingValue);
		}

		if (invalidSignal.equalsIgnoreCase("Yes")) {
			new QAFExtendedWebElement("radio.CSMS.MobileSignalY").click();
		} else if (invalidSignal.equalsIgnoreCase("No")) {
			new QAFExtendedWebElement("radio.CSMS.MobileSignalN").click();
		}

		if (sameContact.equalsIgnoreCase("Yes")) {
			if (new QAFExtendedWebElement("radio.CSMS.MobileSameContY").isEnabled()) {
				new QAFExtendedWebElement("radio.CSMS.MobileSameContY").click();
			}
		} else if (sameContact.equalsIgnoreCase("No")) {
			if (new QAFExtendedWebElement("radio.CSMS.MobileSameContN").isEnabled()) {
				new QAFExtendedWebElement("radio.CSMS.MobileSameContN").click();
			}
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@Then("^I update office country \"([^\"]*)\" , phone \"([^\"]*)\" , ext \"([^\"]*)\" and invalidsignal \"([^\"]*)\"$")
	public void iUpdateofficeCountryTest(String country, String Phone, String Phonext, String invalidSignal) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (country != null && !country.isEmpty()) {
			retainExistingValue("dropdown.CSMS.officeCountry", country, retainExistingValue);
		}

		if (Phone != null && !Phone.isEmpty()) {
			retainExistingValue("input.CSMS.officePhone", Phone, retainExistingValue);
		}

		if (Phonext != null) {
			if (!Phonext.isEmpty()) {
				retainExistingValue("input.CSMS.officePhoneext", Phonext, retainExistingValue);
			}
		}

		if (invalidSignal.equalsIgnoreCase("Yes")) {
			new QAFExtendedWebElement("radio.CSMS.OfficeSignalY").click();
		} else if (invalidSignal.equalsIgnoreCase("No")) {
			new QAFExtendedWebElement("radio.CSMS.OfficeSignalN").click();
		}
		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@Then("^I update fax country \"([^\"]*)\" , phone \"([^\"]*)\" and invalidsignal \"([^\"]*)\"$")
	public void iUpdatefaxCountry(String country, String Phone, String invalidSignal) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (country != null && !country.isEmpty()) {
			retainExistingValue("dropdown.CSMS.FaxCountry", country, retainExistingValue);
		}

		if (Phone != null && !Phone.isEmpty()) {
			retainExistingValue("input.CSMS.FaxPhone", Phone, retainExistingValue);
		}

		if (invalidSignal.equalsIgnoreCase("Yes")) {
			new QAFExtendedWebElement("radio.CSMS.FaxSignalY").click();
		} else if (invalidSignal.equalsIgnoreCase("No")) {
			new QAFExtendedWebElement("radio.CSMS.FaxSignalN").click();
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@Then("^I update email address \"([^\"]*)\" , emailsignal \"([^\"]*)\" and emailSamecontact \"([^\"]*)\"$")
	public void iUpdateemailAddrs(String address, String signal, String sameContact) {

		DeviceUtils.getQAFDriver().switchTo().frame(0);
		if (address != null && !address.isEmpty()) {
			retainExistingValue("input.CSMS.emailAddrs", address, retainExistingValue);
		}

		if (signal.equalsIgnoreCase("Yes")) {
			new QAFExtendedWebElement("radio.CSMS.EmailSignalY").click();
		} else if (signal.equalsIgnoreCase("No")) {
			new QAFExtendedWebElement("radio.CSMS.EmailSignalN").click();
		}

		if (sameContact.equalsIgnoreCase("Yes")) {
			if (new QAFExtendedWebElement("radio.CSMS.EmailSameContY").isEnabled()) {
				new QAFExtendedWebElement("radio.CSMS.EmailSameContY").click();
			}
		} else if (sameContact.equalsIgnoreCase("No")) {
			if (new QAFExtendedWebElement("radio.CSMS.EmailSameContN").isEnabled()) {
				new QAFExtendedWebElement("radio.CSMS.EmailSameContN").click();
			}
		}
		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	@Then("^I update change reason \"([^\"]*)\" and language preference \"([^\"]*)\"$")
	public void changereasonandlang(String changereason, String langPreference) {
		DeviceUtils.getQAFDriver().switchTo().frame(0);
		boolean flag = true;
		boolean flagCH = true;
		boolean multipleAddress = true;

		String CurrentLang = DeviceUtils.getQAFDriver()
				.findElement(By.xpath("//*[@name='language_preference']/following::font[1]")).getText();
		String EnglishXpath = "";
		String ChineseXpath = "";

		if (CurrentLang.equalsIgnoreCase("English")) {
			EnglishXpath = "//*[@name='language_preference' and @value = '01']";
			ChineseXpath = "//*[@name='language_preference' and @value = '02']";
			language = "English";
		} else if (CurrentLang.equalsIgnoreCase("Chinese")) {
			EnglishXpath = "//*[@name='language_preference' and @value = '02']";
			ChineseXpath = "//*[@name='language_preference' and @value = '01']";
			language = "Chinese";
		}

		if (langPreference.equalsIgnoreCase("ENGLISH")) {
			new QAFExtendedWebElement(EnglishXpath).click();
		} else if (langPreference.equalsIgnoreCase("CHINESE")) {
			new QAFExtendedWebElement(ChineseXpath).click();
		}

		// Multiple address
		try {
			if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[contains(@style, 'display: inline;')]"))
					.isPresent()) {
				System.out.print("Multiple address present");
				multipleAddress = true;
			}
		} catch (Exception e) {
			if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[contains(@style, 'display:inline')]"))
					.isPresent()) {
				System.out.print("Multiple address not present");
				multipleAddress = false;
			}
		}

		if (language.equalsIgnoreCase("English")) {
			for (int i = 1; i <= 10; i++) {
				if (flag) {
					try {
						if (multipleAddress) {
							if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
									+ "' and contains(@style, 'display: inline;')]/td/input[1]")).isEnabled()) {
								if (changereason.equalsIgnoreCase("Contact Change")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_E" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[1]"))
											.click();
								} else if (changereason.equalsIgnoreCase("Contact Correction")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_E" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[2]"))
											.click();
								} else if (changereason.equalsIgnoreCase("NB app")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_E" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[3]"))
											.click();
								} else if (changereason.equalsIgnoreCase("Internal Request")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_E" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[4]"))
											.click();
								}
								flag = false;

							}
						} else {
							if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
									+ "' and contains(@style, 'display:inline')]/td/input[1]")).isEnabled()) {
								if (changereason.equalsIgnoreCase("Contact Change")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
											+ "' and contains(@style, 'display:inline')]/td/input[1]")).click();
								} else if (changereason.equalsIgnoreCase("Contact Correction")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
											+ "' and contains(@style, 'display:inline')]/td/input[2]")).click();
								} else if (changereason.equalsIgnoreCase("NB app")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
											+ "' and contains(@style, 'display:inline')]/td/input[3]")).click();
								} else if (changereason.equalsIgnoreCase("Internal Request")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_E" + i
											+ "' and contains(@style, 'display:inline')]/td/input[4]")).click();
								}
								flag = false;
							}
						}
					} catch (Exception e) {

					}
				} else {
					break;
				}
			}
		}
		if (language.equalsIgnoreCase("Chinese")) {
			for (int i = 1; i <= 10; i++) {
				if (flagCH) {
					try {
						if (multipleAddress) {
							if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
									+ "' and contains(@style, 'display: inline;')]/td/input[1]")).isEnabled()) {
								if (changereason.equalsIgnoreCase("Contact Change")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_C" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[1]"))
											.click();
								} else if (changereason.equalsIgnoreCase("Contact Correction")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_C" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[2]"))
											.click();
								} else if (changereason.equalsIgnoreCase("NB app")) {

									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_C" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[3]"))
											.click();
								} else if (changereason.equalsIgnoreCase("Internal Request")) {
									DeviceUtils.getQAFDriver()
											.findElement(By.xpath("//*[@id='addrchgreason_C" + i
													+ "' and contains(@style, 'display: inline;')]/td/input[4]"))
											.click();
								}
								flagCH = false;
							}
						} else {
							if (DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
									+ "' and contains(@style, 'display:inline')]/td/input[1]")).isEnabled()) {
								if (changereason.equalsIgnoreCase("Contact Change")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
											+ "' and contains(@style, 'display:inline')]/td/input[1]")).click();
								} else if (changereason.equalsIgnoreCase("Contact Correction")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
											+ "' and contains(@style, 'display:inline')]/td/input[2]")).click();
								} else if (changereason.equalsIgnoreCase("NB app")) {

									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
											+ "' and contains(@style, 'display:inline')]/td/input[3]")).click();
								} else if (changereason.equalsIgnoreCase("Internal Request")) {
									DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='addrchgreason_C" + i
											+ "' and contains(@style, 'display:inline')]/td/input[4]")).click();
								}
								flagCH = false;
							}
						}
					} catch (Exception e) {
					}

				} else {
					break;
				}
			}
		}

		DeviceUtils.getQAFDriver().switchTo().defaultContent();

	}

	/*
	 * @Then("^I Compare input data for MCN \"([^\"]*)\" and transaction date \"([^\"]*)\" againts database$"
	 * ) public void compareData(String MCN, String tnxDate) throws ParseException {
	 * 
	 * List<List<String>> outputData = getCDMData(MCN, changeDateFormat(tnxDate));
	 * System.out.println(outputData);
	 * 
	 * }
	 */

	public void retainExistingValue(String object, String Value, boolean retainValue) {

		if (retainValue) {
			new QAFExtendedWebElement(object).sendKeys(Value);
		} else {
			new QAFExtendedWebElement(object).clear();
			new QAFExtendedWebElement(object).sendKeys(Value);
		}

	}

}
