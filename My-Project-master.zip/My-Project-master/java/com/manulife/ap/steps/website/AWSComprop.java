package com.manulife.ap.steps.website;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Reporter;

import com.manulife.ap.Reusablefunction;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.DeviceUtils;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class AWSComprop extends Reusablefunction {

	/**
	 * 
	 * @param arg1
	 * @throws Throwable Launches AWS webpage in chrome browser for the requested
	 *                   URL Developed : Karthik Dhanapal
	 */
	@Given("^I launch AWS in chrome \"([^\"]*)\"$")
	public void i_launch_AWS_in_chrome(String arg1) throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		// arg1 = "https://test.salesforce.com/";
		DeviceUtils.getQAFDriver().get(arg1);

//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"username\"]")
//				.sendKeys("krishna_k_kundan7@manulife.com.ccsit02");
//
//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"password\"]").sendKeys("password1$");
//
//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"Login\"]").click();
//		Thread.sleep(6000);
//		List<WebElement> allElementsqw = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@data-key='close']/preceding::div[2]"));
//		int elementsize = allElementsqw.size();
//		
		// For loop negative iteration
//		for (int i = 0; i < elementsize; i++) {
//			// close the final tab
//			try {
//
////
////			allElementsqw.get(i).isEnabled();
//			//	allElementsqw.get(i).click();
//				
//				
//				
//				String getclosetitle = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@data-key='close']/ancestor::button")).get(i).getAttribute("title");
//				
//				
//				
//				
//				
//				DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(text(),'"+ getclosetitle + "')]/ancestor::button")).get(i).click();
//				DeviceUtils.getQAFDriver().navigate().refresh();
//				// DeviceUtils.getQAFDriver().findElementsByTagName(getuseVAl);
//
//			} catch (Exception e) {
//				System.out.print(e);
//			}

//			WebElement elemen2 = (new WebDriverWait(DeviceUtils.getQAFDriver(), 50))
//					.until(ExpectedConditions.elementToBeClickable(
//							By.xpath("//span[contains(@class,'itemTitle') and contains(text(),'Search')]")));

		// allElementsqw =
		// DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@data-key='close']"));

		// }

//		}
//		allElementsqw = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@data-key='close']"));

//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"username\"]")
//				.sendKeys("krishna_k_kundan7@manulife.com.ccsit02");
//
//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"password\"]").sendKeys("password1$");
//
//		DeviceUtils.getQAFDriver().findElementByXPath("//*[@id=\"Login\"]").click();
//		Thread.sleep(6000);
//		// get the list of close tab is opened
//		//@data-key='close' and 
//		List<WebElement> allElementsqw = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@data-key='close']"));
//		
//
//		
//		int arraySize = allElementsqw.size();
//		System.out.println(arraySize);
//		// For loop negative iteration
//		for (int i = 0; i <= arraySize-1; i++) {
//		//	Thread.sleep(5000);
//			System.out.println(i);
//			// close the final tab
//			WebElement allElement =  allElementsqw.get(i);
//			
//			String getid = allElement.getAttribute("id");
//			System.out.println(getid);
//			if(getid.equals("")) {
//				System.out.println(getid);
//			}else {
//				DeviceUtils.getQAFDriver().findElementById(getid).click();
//			}

		// Thread.sleep(5000);
		// }

	}

	/**
	 * Login function for AWS System
	 * 
	 * @param arg1 - Username
	 * @param arg2 - Password
	 * @throws Throwable
	 * 
	 */
	@When("^I login with user id as \"([^\"]*)\" agent and Password \"([^\"]*)\"$")
	public void i_login_with_user_id_as_agent_and_Password(String arg1, String arg2) throws Throwable {

		new QAFExtendedWebElement("lnk.aws.login").click();

		
		new QAFExtendedWebElement("input.aws.username").sendKeys(arg1);


		new QAFExtendedWebElement("input.CSMS.password").sendKeys(arg2);
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new QAFExtendedWebElement("btn.aws.Login").click();
	}

	/**
	 * Verify the object is loaded for the requested page
	 * 
	 * @param arg1 - page object - XPATH
	 * @throws Throwable
	 */
	@When("^I verify \"([^\"]*)\" page is displayed$")
	public void i_verify_page_is_displayed(String arg1) throws Throwable {

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			if (DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@id='go_btn']")).size() != 0) {
				new QAFExtendedWebElement("btn.aws.GO").click();
			} else {
				System.out.println("Element is Absent");
			}
		} catch (Exception e) {

		}
		try {
			DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
			new QAFExtendedWebElement("lnk.aws.English").click();
		} catch (Exception e) {

		}
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	@When("^i select customer type as \"([^\"]*)\", Surname as \"([^\"]*)\" , Givenname as \"([^\"]*)\"$")
	public void i_select_customer_type_as_Surname_as_Givenname_as(String arg1, String arg2, String arg3)
			throws Throwable {

		new QAFExtendedWebElement("txt.aws.Surname").sendKeys(arg2);
		new QAFExtendedWebElement("txt.aws.Givenname").sendKeys(arg3);
		// new QAFExtendedWebElement("btn.aws.eProposal.New").sendKeys(arg3);
	}

	@When("^I enter Surname \"([^\"]*)\", givenname \"([^\"]*)\", sex \"([^\"]*)\" , proposalage \"([^\"]*)\" and smokerstatus \"([^\"]*)\"$")
	public void i_enter_Surname_givenname_sex_proposalage_and_smokerstatus(String arg1, String arg2, String arg3,
			String arg4, String arg5) throws Throwable {

		new QAFExtendedWebElement("txt.aws.Surname").clear();
		new QAFExtendedWebElement("txt.aws.Givenname").clear();

		new QAFExtendedWebElement("txt.aws.Surname").sendKeys(arg1);
		new QAFExtendedWebElement("txt.aws.Givenname").sendKeys(arg2);

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		if (arg3.equalsIgnoreCase("M")) {
			clickRadioButton("//*[@name='primary_sex']", "0");
		} else if (arg3.equalsIgnoreCase("F")) {
			clickRadioButton("//*[@name='primary_sex']", "1");
		}

		new QAFExtendedWebElement("txt.aws.Age").clear();
		new QAFExtendedWebElement("txt.aws.Age").sendKeys(arg4);

//		if (arg5.equals("Standard")) {
//			arg5 = "2";
//		} else {
//			arg5 = "1";
//		}

		selectdropdown("//*[@name='primary_non_smoker']", arg5);

	}

	@When("^I navigate to basic plan$")
	public void i_navigate_to_basic_plan() throws Throwable {
		new QAFExtendedWebElement("lnk.aws.basicplan").click();
	}

	@When("^I Select plan type as \"([^\"]*)\" and basic plan as \"([^\"]*)\"$")
	public void i_Select_plan_type_as_and_basic_plan_as(String arg1, String arg2) throws Throwable {

		selectdropdown("//*[@name='basic_plan']", arg2);

	}

	@When("^I Select income payment option \"([^\"]*)\"$")
	public void i_Select_incomepaymentoption(String arg1) throws Throwable {

		if (arg1.equals("Leave on Deposit")) {
			new QAFExtendedWebElement("radio.aws.income_option_LeaveonDeposit").click();
		} else if (arg1.equals("Payout Monthly")) {
			new QAFExtendedWebElement("radio.aws.income_option_PayoutMonthly").click();
		}

	}

	@When("^I Enter value Plan Options for ManuGuard \"([^\"]*)\"$")
	public void i_planoptionsManuGuard(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='coverage_class']", arg1);
		} catch (Exception e) {

		}

	}

	@When("^I Enter value major_medical Options for ManuGuard \"([^\"]*)\"$")
	public void i_Select_campaignManuGuard(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='major_medical']", arg1);
		} catch (Exception e) {

		}
	}

	@When("^I Enter value Plan Options \"([^\"]*)\"$")
	public void i_planoptions(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='coverage_class']", arg1);
		} catch (Exception e) {

		}

	}

	@When("^I Enter value campaign Options \"([^\"]*)\"$")
	public void i_Select_campaign(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='campaign_code']", arg1);
		} catch (Exception e) {

		}
	}

	@When("^I Enter value Plan Options for ManuMaster_Shine \"([^\"]*)\"$")
	public void i_planoptionsManuMaster_Shine(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='coverage_class']", arg1);
		} catch (Exception e) {

		}

	}

	@When("^I Enter value shine Options for ManuMaster_Shine \"([^\"]*)\"$")
	public void i_Select_Shine(String arg1) throws Throwable {
		try {
			if (!arg1.isEmpty() & arg1 != "")
				selectdropdown("//*[@name='major_medical']", arg1);
		} catch (Exception e) {

		}
	}

	@Then("^I Enter value for Nationalamount curreny as \"([^\"]*)\" and amount as \"([^\"]*)\"$")
	public void i_Enter_value_for_Nationalamount_curreny_as_and_amount_as(String arg1, String arg2) throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		if (arg1 != null) {
			if (!arg1.isEmpty()) {
				selectdropdown("//*[@name='face_amount_currency']", arg1);
			}
			if (!arg2.isEmpty()) {
				if (new QAFExtendedWebElement("txt.aws.NotionalAmt").isPresent()) {
					new QAFExtendedWebElement("txt.aws.NotionalAmt").clear();
					new QAFExtendedWebElement("txt.aws.NotionalAmt").sendKeys(arg2);
				}
			}
		}
	}

	@Then("^I Enter value Initial top up as \"([^\"]*)\"$")
	public void i_Enter_value_Initial_top_up_as(String arg1) throws Throwable {
		try {
			if (arg1 != null) {
				if (!arg1.isEmpty()) {
					new QAFExtendedWebElement("txt.aws.intialtopup").clear();
					new QAFExtendedWebElement("txt.aws.intialtopup").sendKeys(arg1);
				}
			}
		} catch (Exception e) {

		}
	}

	@Then("^I Enter value Basic premium as \"([^\"]*)\" , payment mode as \"([^\"]*)\" , death Benefit as \"([^\"]*)\"$")
	public void i_Enter_value_Basic_premium_as_payment_mode_as_death_Benefit_as(String arg1, String arg2, String arg3)
			throws Throwable {

		try {
			if (arg1 != null) {
				if (!arg1.isEmpty()) {
					new QAFExtendedWebElement("txt.aws.BasicPremium").clear();
					new QAFExtendedWebElement("txt.aws.BasicPremium").sendKeys(arg1);
				}
			}
		} catch (Exception e) {

		}
		try {
			if (arg2 != null) {
				if (!arg2.isEmpty()) {
					selectdropdown("//*[@name='payment_mode1']", arg2);

				}
			}
		} catch (Exception e) {

		}

		try {
			if (arg3 != null) {
				if (!arg3.isEmpty()) {
					selectdropdown("//*[@name='db_option']", arg3);
				}
			}
		} catch (Exception e) {

		}
	}

	@When("^I Navigate to e-proposal screen to create proposal$")
	public void i_Navigate_to_e_proposal_screen_to_create_proposal() throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		new QAFExtendedWebElement("lnk.aws.Sales&Service").click();
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// DeviceUtils.getQAFDriver().findElements(By.xpath("//li[2]//*[contains(text(),'eProposals')][1]"));
		WebElement mouseAction = DeviceUtils.getQAFDriver()
				.findElementByXPath("//*[contains(text(),'Sales And Service')][1]");

		Actions createact = new Actions(DeviceUtils.getQAFDriver());
		createact.moveToElement(mouseAction).build().perform();

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new QAFExtendedWebElement("lnk.aws.eProposal").click();

	}

	@Then("^I check plan option as Change DB to Level at age is \"([^\"]*)\" and age as \"([^\"]*)\"$")
	public void i_check_plan_option_as_Change_DB_to_Level_at_age_is_and_age_as(String arg1, String arg2)
			throws Throwable {

		if (arg1.equalsIgnoreCase("ON")) {
			clickRadioButton("//*[@name='checkbox_change_db_age_ind']", "0");
			new QAFExtendedWebElement("txt.aws.ChangeDBAge").sendKeys(arg2);
		}
	}

	@Then("^I check plan option as Inflation Protector Option is \"([^\"]*)\"$")
	public void i_check_plan_option_as_Inflation_Protector_Option_is(String arg1) throws Throwable {
		if (arg1.equalsIgnoreCase("ON")) {
			clickRadioButton("//*[@name='checkbox_ipo']", "0");
		}
	}

	@SuppressWarnings("unused")
	@Then("^I click on the \"([^\"]*)\" button$")
	public void i_click_on_the_button(String arg1) throws Throwable {

		try {
			DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			// Store the current window handle
			String winHandleBefore = DeviceUtils.getQAFDriver().getWindowHandle();
			String winHandleBeforetitle = DeviceUtils.getQAFDriver().getTitle();
			// Perform the click operation that opens new window
			if (winHandleBeforetitle.equals("AWS Home")) {
				DeviceUtils.getQAFDriver().close();
			}

			// Switch to new window opened
			for (String winHandle : DeviceUtils.getQAFDriver().getWindowHandles()) {
				DeviceUtils.getQAFDriver().switchTo().window(winHandle);
			}

			DeviceUtils.getQAFDriver().manage().window().maximize();

			// ChromeOptions options = new ChromeOptions();
			// options.addArguments("--start-maximized");
			// DeviceUtils.getQAFDriver() = new ChromeDriver( options );

			new QAFExtendedWebElement(arg1).click();
			DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			try {
				DeviceUtils.getQAFDriver().switchTo().alert().accept();
			} catch (Exception e) {
				System.out.println(e);
			}
		} catch (Exception e) {
		}

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

	}

	@Then("^I wait for \"([^\"]*)\" page is displayed$")
	public void i_wait_for_page_is_displayed(String arg1) throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	}

	@Then("^I check cash assistance benefit \"([^\"]*)\" with protectionamoun \"([^\"]*)\" and with IPO \"([^\"]*)\"$")
	public void i_check_cash_assistance_benefit_with_protectionamoun_and_with_IPO(String arg1, String arg2, String arg3)
			throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CA475']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_CA475").sendKeys(arg2);
			}

			if (arg3.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='rider_ipo_CA475']", "0");
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Outpatient Benefit \"([^\"]*)\"$")
	public void i_check_Outpatient_Benefit(String arg1) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_OB70']", "0");
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check ManuGuard Medical Benefit Non hk \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_ManuGuard_Medical_Benefit_Non_hk_with_option_and_option(String arg1, int arg2, String arg3,
			int arg4, String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_HN99']", "0");
				selectdropdown("//*[@name='coverage_class_HN99']", arg3);
				selectdropdown("//*[@name='major_medical_HN99']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check ManuGuard Medical Benefit \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_ManuGuard_Medical_Benefit_with_option_and_option(String arg1, int arg2, String arg3, int arg4,
			String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_HB99']", "0");
				selectdropdown("//*[@name='coverage_class_HB99']", arg3);
				selectdropdown("//*[@name='major_medical_HB99']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check ManuMaster Healthcare Benefit \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_ManuMaster_Healthcare_Benefit_with_option_and_option(String arg1, int arg2, String arg3,
			int arg4, String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_HQ99']", "0");
				selectdropdown("//*[@name='coverage_class_HQ99']", arg3);
				selectdropdown("//*[@name='major_medical_HQ99']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check ManuShine Healthcare Benefit \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_ManuShine_Healthcare_Benefit_with_option_and_option(String arg1, int arg2, String arg3,
			int arg4, String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_HR99']", "0");
				selectdropdown("//*[@name='coverage_class_HR99']", arg3);
				selectdropdown("//*[@name='major_medical_HR99']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Cancer Treatment Benefit \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_Cancer_Treatment_Benefit_with_option_and_option(String arg1, int arg2, String arg3, int arg4,
			String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CD599']", "0");
				selectdropdown("//*[@name='coverage_class_CD599']", arg3);
				selectdropdown("//*[@name='major_medical_CD599']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Cancer Treatment Benefit non HK \"([^\"]*)\" with option(\\d+) \"([^\"]*)\" and option(\\d+) \"([^\"]*)\"$")
	public void i_check_Cancer_Treatment_Benefit_non_HK_with_option_and_option(String arg1, int arg2, String arg3,
			int arg4, String arg5) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CF599']", "0");
				selectdropdown("//*[@name='coverage_class_CF599']", arg3);
				selectdropdown("//*[@name='major_medical_CF599']", arg5);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Hospital Income Benefit \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_Hospital_Income_Benefit_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_HI']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_HI").sendKeys(arg2);
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check ManuTerm Benefit ten \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_ManuTerm_Benefit_ten_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_TR10']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_TR10").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check ManuTerm Benefit twenty \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_ManuTerm_Benefit_twenty_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_TR20']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_TR20").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Premium Waiver Benefit \"([^\"]*)\"$")
	public void i_check_Premium_Waiver_Benefit(String arg1) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_PWB']", "0");
			}
		} catch (Exception e) {
		}
	}

	@Then("^I navigate to supplementary benefit page$")
	public void i_navigate_to_supplementary_benefit_page() throws Throwable {

		Reporter.log("I navigate to supplementary benefit page");

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		if (new QAFExtendedWebElement("lnk.aws.supplementbenefit").getAttribute("class")
				.equals("green_button2_disabled")) {
			System.out.println("supplementary benefit page disabled");
		} else {
			new QAFExtendedWebElement("lnk.aws.supplementbenefit").click();
		}

	}

	@Then("^I navigate to split case page$")
	public void I_navigate_to_split_case_page() throws Throwable {

		Reporter.log("I navigate to split case page");

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		try {
			if (new QAFExtendedWebElement("lnk.aws.btnSplitCase").getAttribute("class")
					.equals("green_button2_disabled")) {
				System.out.println("split case page disabled");
			} else {
				new QAFExtendedWebElement("lnk.aws.btnSplitCase").click();
			}
		} catch (Exception e) {
		}
	}

	@Then("^I wait for file to download$")
	public void i_wait_for_file_to_download() throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		// DeviceUtils.getQAFDriver().close();
	}

	@Then("^I check Cancer Guard Protection Benefit \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_Cancer_Guard_Protection_Benefit_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CV99']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_CV99").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Early Stage Critical Illness Benefit \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_Early_Stage_Critical_Illness_Benefit_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CE75']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_CE75").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Major Disease Benefit \"([^\"]*)\" with protectionamoun \"([^\"]*)\" and with IPO \"([^\"]*)\"$")
	public void i_check_Major_Disease_Benefit_with_protectionamoun_and_with_IPO(String arg1, String arg2, String arg3)
			throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_MD499']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_MD499").sendKeys(arg2);
			}

			if (arg3.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='rider_ipo_MD499']", "0");
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Premier Life Critical Illness Benefit \"([^\"]*)\" with protectionamoun \"([^\"]*)\" and with IPO \"([^\"]*)\"$")
	public void i_check_Premier_Life_Critical_Illness_Benefit_with_protectionamoun_and_with_IPO(String arg1,
			String arg2, String arg3) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CIB']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_CIB").sendKeys(arg2);
			}

			if (arg3.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='rider_ipo_CIB']", "0");
			}
		} catch (Exception e) {

		}
	}

	@Then("^I check Accidental Death Benefit \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_Accidental_Death_Benefit_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_ADB']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_ADB").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Premier Life Critical Illness Benefit \"([^\"]*)\" with protectionamoun \"([^\"]*)\" and with occupation \"([^\"]*)\"$")
	public void i_check_Premier_Life_Critical_Illness_Benefit_with_protectionamoun_and_with_occupation(String arg1,
			String arg2, String arg3) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_AK75']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_AK75").clear();
				new QAFExtendedWebElement("txt.aws.face_amount_AK75").sendKeys(arg2);
				selectdropdown("//*[@name='occupation_class_AK75']", arg3);
			}
		} catch (Exception e) {
		}

	}

	@Then("^I check Medical Indemnity \"([^\"]*)\" with amount \"([^\"]*)\"$")
	public void i_check_Medical_Indemnity_with_amount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_AJ75']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_AJ75").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Payor Benefit Benefit \"([^\"]*)\" with age \"([^\"]*)\"$")
	public void i_check_Payor_Benefit_Benefit_with_age(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_PB']", "0");
				new QAFExtendedWebElement("txt.aws.payor_age_PB").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Child Care Benefit \"([^\"]*)\" with age \"([^\"]*)\"$")
	public void i_check_Child_Care_Benefit_with_age(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_CCB']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_CCB").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Premium Income Benefit \"([^\"]*)\" ith protectionamoun \"([^\"]*)\" and with occupation \"([^\"]*)\" and PremiumIncome_Benefit \"([^\"]*)\"$")
	public void i_check_Premium_Income_Benefit_ith_protectionamoun_and_with_occupation_and_PremiumIncome_Benefit(
			String arg1, String arg2, String arg3, String arg4) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_PIB']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_PIB").sendKeys(arg2);
				selectdropdown("//*[@name='benefit_period_PIB']", arg4);
				selectdropdown("//*[@name='occupation_class_PIB']", arg3);

			}
		} catch (Exception e) {
		}
	}

	@SuppressWarnings("rawtypes")
	@Then("^I click on the English option button$")
	public void i_click_on_the_English_option_button() throws Throwable {
		List oRadioButton = DeviceUtils.getQAFDriver().findElements(By.name("lang"));
		((WebElement) oRadioButton.get(1)).click();
	}

	@Then("^I check Premier Ladys Benefit \"([^\"]*)\" with protectionamount \"([^\"]*)\"$")
	public void i_check_Premier_Ladys_Benefit_with_protectionamount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_MYPLB']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_MYPLB").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I check Maternity Benefit \"([^\"]*)\" with protectionamount \"([^\"]*)\"$")
	public void i_check_Maternity_Benefit_with_protectionamount(String arg1, String arg2) throws Throwable {
		try {
			if (arg1.equalsIgnoreCase("ON")) {
				clickRadioButton("//*[@name='check_box_MX']", "0");
				new QAFExtendedWebElement("txt.aws.face_amount_MX").sendKeys(arg2);
			}
		} catch (Exception e) {
		}
	}

	@Then("^I retrieve value from DB and store proposal number in text file for surname \"([^\"]*)\" and givename \"([^\"]*)\" for test case id \"([^\"]*)\"$")
	public void i_retrieve_value_from_DB_and_store_proposal_number_in_text_file(String surName, String givenName,
			String testCaseId) throws Throwable {

		String proposalNumber = getProposalNumber(surName, givenName);

		if (proposalNumber != null) {
			if (proposalNumber.equals("") || proposalNumber.isEmpty()) {
				proposalNumber = "Data Not created";
			}
		}
		createtxtfile(testCaseId + "==" + proposalNumber + "==", System.getProperty("user.dir").toString());

		// DeviceUtils.getQAFDriver().close();
	}

	@Then("^I enter advisor code2 \"([^\"]*)\" and advisor code3 \"([^\"]*)\"$")
	public void I_enter_advisor_code(String arg1, String arg2) throws Throwable {
		try {
			new QAFExtendedWebElement("txt.aws.agt_code_2").clear();
			new QAFExtendedWebElement("txt.aws.agt_code_2").sendKeys(arg1);
			new QAFExtendedWebElement("txt.aws.agt_code_3").clear();
			new QAFExtendedWebElement("txt.aws.agt_code_3").sendKeys(arg2);
		} catch (Exception e) {
		}
	}

	// DeviceUtils.getQAFDriver().switchTo().alert().accept();
}
