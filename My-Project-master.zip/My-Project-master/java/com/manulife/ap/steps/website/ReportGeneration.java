package com.manulife.ap.steps.website;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.manulife.ap.Reusablefunction;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.quantum.utils.DeviceUtils;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

@QAFTestStepProvider
public class ReportGeneration extends Reusablefunction {

	@Then("^I Navigate to production overview screen to get data$")
	public void navigatetoproduction() throws Throwable {
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		new QAFExtendedWebElement("lnk.aws.MyAdministration").click();
		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);

		// DeviceUtils.getQAFDriver().findElements(By.xpath("//li[2]//*[contains(text(),'eProposals')][1]"));
		WebElement mouseAction = DeviceUtils.getQAFDriver()
				.findElementByXPath("//*[contains(text(),'My Administration')][1]");

		Actions createact = new Actions(DeviceUtils.getQAFDriver());
		createact.moveToElement(mouseAction).build().perform();

		DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		new QAFExtendedWebElement("lnk.aws.productionOverview").click();

	}

	@SuppressWarnings("unused")
	@When("^I retrieve data from the production overview table$")
	public void retrivedatafromreport() throws Throwable {

		List<String> tableDataValue = new ArrayList<String>();
		
		List<WebElement> rows = DeviceUtils.getQAFDriver()
				.findElementsByXPath("//*[@id='monthlyReportTable']/tbody/tr");

		// Initialize a new array list to store the text
		List<String> tableData = new ArrayList<String>();
		String rowValue = null;
		
		// For each row, get the column data and store into the tableData object
		for (int i = 0; i < rows.size(); i++) {
			// Since you also have some span tags inside (and maybe something else)
			// we first get
			// WebElement e ;

			for (WebElement e : rows) {
				tableData.add(e.getText());
				System.out.println(e.getText());
			}

			String[] Test = tableData.get(i).split(" ");
			DeviceUtils.getQAFDriver().findElementByPartialLinkText(Test[0]).click();

			DeviceUtils.getQAFDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			List<WebElement> rowsNext = DeviceUtils.getQAFDriver().findElementsByXPath("//*[@id='result_body']/tr");
			List<WebElement> rowsNextinside = rowsNext.get(0).findElements(By.xpath("td"));
		

			

			for (int j = 0; j < rowsNext.size(); j++) {
				rowsNextinside = rowsNext.get(j).findElements(By.xpath("td"));
				for (WebElement eNextinside : rowsNextinside) {
					rowValue = rowValue + "==" + eNextinside.getText();
					System.out.println(rowValue);
				}
				tableDataValue.add(rowValue);
			}

//		for (WebElement eNext : rowsNext) {	
//			
//			//rowsNextinside = rowsNext.get(0).findElements(By.xpath("td"));
//			//System.out.println(eNext.getText());
//			for (WebElement eNextinside : rowsNextinside) {
//				
//				rowValue = rowValue + "==" +eNextinside.getText();
//				System.out.println(rowValue);
//			}
//			tableDataValue.add(rowValue);
//		}

			//navigatetoproduction();

			storeDatainExcel("AgentCode", tableData, tableDataValue);
			
		}
		
		
		
	}

}
