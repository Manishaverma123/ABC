/**
 * 
 */
package com.manulife.ap.steps.website;


import com.manulife.ap.steps.website.pages.GooglePage;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.quantum.utils.DeviceUtils;

/**
 * @author kulin.sitwala
 *
 */
@QAFTestStepProvider
public class GoogleSearchSampleStepsDef {

	/**
	 * This step will Launch the google website.
	 */
	@QAFTestStep(description = "I launch google website")
	public void launchGoogleSample() {
		DeviceUtils.getQAFDriver().get("http://www.google.com");
	}

	/**
	 * This step will search the parameter string in the google search.
	 */
	@QAFTestStep(description = "I search {0} in google search")
	public void searchGoogle(String searchText) {
		GooglePage googlePage = new GooglePage();
		googlePage.searchGoogle(searchText);
	}

	/**
	 * This step will verify the text of the first link on the google result screen.
	 */
	@QAFTestStep(description = "I verify the {0} text should be present in the first link")
	public void verifyGoogleResultLink(String linkText) {
		GooglePage googlePage = new GooglePage();
		googlePage.verifyGoogleResult(linkText);
	}

}
