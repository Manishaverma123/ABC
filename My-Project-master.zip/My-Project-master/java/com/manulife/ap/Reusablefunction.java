package com.manulife.ap;

import java.awt.AWTException;
import java.awt.Dimension;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TreeMap;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Picture;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.util.IOUtils;
import org.hamcrest.Matchers;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.manulife.ap.listener.ListenerTest;
import com.qmetry.qaf.automation.ws.RestWSTestCase;
import com.quantum.utils.DeviceUtils;

import cucumber.api.java.en.When;
import gherkin.formatter.model.Result;

/*
 * This java class is created to store reusable components 
 */

public class Reusablefunction extends RestWSTestCase{

	// Creating instance for java property file
	static Properties properties = Settings.getInstance();
	

	public static File imageFolderPath= new File(System.getProperty("user.dir")+"\\src\\main\\resources\\temporaryscreenshots\\");
	static Date now = new java.util.Date();
	static Timestamp current = new java.sql.Timestamp(now.getTime());
	static String timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(current);
	
	public static String outputPath= System.getProperty("user.dir")+"\\src\\main\\resources\\OutputScreenshotPath\\";
	public static ArrayList<String> ListOfImages= new ArrayList<String>();
	/**
	 * This function change the date format for JSON Input Parameter Date format -
	 * 16-May-2018 - String Output Parameter Date format - 16-May-2018 - String
	 * 
	 * @param sourcedate - input date format from external - dd-MMM-yy
	 * @return change the format of the date - dd-MMM-yyyy
	 * @throws ParseException Developed by Karthik Dhanapal
	 */

	public String changeDateFormat(String sourcedate) throws ParseException {
		String dateReq2 = "";
		if (!sourcedate.isEmpty()) {
			SimpleDateFormat sourceDateFormat = new SimpleDateFormat("dd-MMM-yy");
			Date date = sourceDateFormat.parse(sourcedate);
			SimpleDateFormat targetDateFormat = new SimpleDateFormat("dd-MM-yyyy");
			String dateReq = targetDateFormat.format(date);
			SimpleDateFormat sourceDateFormat2 = new SimpleDateFormat("dd-MM-yyyy");
			Date date2 = sourceDateFormat2.parse(dateReq);
			//SimpleDateFormat targetDateFormat2 = new SimpleDateFormat("dd-MMM-yyyy");
			//dateReq2 = targetDateFormat2.format(date2);
		}
		return dateReq2;
	}

/**
 * 
 * @param driver
 * @param browserTitle
 * @param closewindow
 * @param newWindowClose
 * @throws InterruptedException
 * @author Karthik Dhanapal
 */

	public void SwitchTabandClose(WebDriver driver, String browserTitle, boolean closewindow, boolean newWindowClose)
			throws InterruptedException {

		Thread.sleep(3000);
		Set<String> windows = driver.getWindowHandles();
		String mainwindow = driver.getWindowHandle();
		String newWindow = "";
		String newWindowsearch = "";
		
		for (String handle : windows) {
			driver.switchTo().window(handle);
			newWindow = handle;
			System.out.println("switched to " + driver.getTitle() + "  Window");
			String pagetitle = driver.getTitle();
			
			if (pagetitle.equalsIgnoreCase("Customer Search")) {
				newWindowsearch = handle;
			}
			
			if (pagetitle.equalsIgnoreCase(browserTitle)) {
				if (closewindow) {
					Thread.sleep(2000);
					driver.close();
					System.out.println("Closed the  '" + pagetitle + "' Tab now ...");
				}
			}
		}

		if (newWindowClose) {
			driver.switchTo().window(mainwindow);
		} else {
			driver.switchTo().window(newWindowsearch);
		}
	}
	
     public void uploadFileWithRobot(String imageName) throws InterruptedException {
		
//        StringSelection stringSelection = new StringSelection(imagePath);
    	 StringSelection stringSelection = new StringSelection(System.getProperty("user.dir")+"\\src\\"+imageName);
    	 System.out.println(System.getProperty("user.dir")+"\\src\\"+imageName);
        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
        clipboard.setContents(stringSelection, null);
 
        Robot robot = null;
 
        try {
            robot = new Robot();
        } catch (AWTException e) {
            e.printStackTrace();
        }
 
        robot.delay(350);
//        robot.keyPress(KeyEvent.VK_ENTER);
//        robot.keyRelease(KeyEvent.VK_ENTER);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.delay(350);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.delay(250);
        robot.keyRelease(KeyEvent.VK_ENTER);
        Thread.sleep(11000);
        System.out.println("dfvdfhfghfgd");
    
      }
     
     
    
	
	public void SwitchTabandClosenewfunc(WebDriver driver, String browserTitle, String PolicyNo)
			throws InterruptedException {

		Thread.sleep(3000);
		Set<String> windows = driver.getWindowHandles();
		String mainwindow = driver.getWindowHandle();
		String newWindow = "";
		for (String handle : windows) {
			driver.switchTo().window(handle);
			newWindow = handle;
			System.out.println("switched to " + driver.getTitle() + "  Window");
			String pagetitle = driver.getTitle();
			if (pagetitle.equalsIgnoreCase(browserTitle)) {
					Thread.sleep(1000);
					DeviceUtils.getQAFDriver().manage().window().maximize();
					Thread.sleep(1000);
					DeviceUtils.getQAFDriver().switchTo().frame(0).findElements(By.xpath("//form[@name='PolicyInputForm']/p/input[@class='type1']")).get(0).sendKeys(PolicyNo);
			    	Thread.sleep(1000);
			    	DeviceUtils.getQAFDriver().findElements(By.xpath("//form[@name='PolicyInputForm']/p/a/img")).get(0).click();
			    	Thread.sleep(2000);
//					driver.close();
					System.out.println("Closed the  '" + pagetitle + "' Tab now ...");
			}
		}
	}
	
	/**
	 * This function takes snapshot of the driver
	 * 
	 *Developed by Manish Bhagat
	 */
	
	public static void takeSnapShot(String testname) throws Exception{

        //Convert web driver object to TakeScreenshot
		String testannotationname= ListenerTest.testcasename;
		String directory= System.getProperty("user.dir")+"\\src\\main\\resources\\screenshots\\";

		File theDir = new File(directory+testannotationname+"_"+timeStamp);

		// if the directory does not exist, create it
		if (!theDir.exists()) {
		    System.out.println("creating directory: " + theDir.getName());
		    System.out.println("directory path: " + theDir.getAbsolutePath());
		    
		    boolean result = false;

		    try{
		        theDir.mkdir();
		        result = true;
		    } 
		    catch(SecurityException se){
		        //handle it
		    }        
		    if(result) {    
		        System.out.println("DIR created");  
		    }
		}
		 
//		String fileEntry= System.getProperty("user.dir")+"\\src\\main\\resources\\screenshots";
//		System.out.println(fileEntry);
		
		//using robot class
//		Robot robot= null;
//		robot= new Robot();
//		Toolkit toolkit= Toolkit.getDefaultToolkit();
//		Dimension dim= toolkit.getScreenSize();
//		BufferedImage i= null;
//		i= robot.createScreenCapture(new Rectangle(0,0,dim.width,dim.height));
//		File output= new File(fileEntry+ "testname" +System.currentTimeMillis()+".jpg");
//		ImageIO.write(i, "jpg", output);
	
		//using driver
        TakesScreenshot scrShot =((TakesScreenshot)DeviceUtils.getQAFDriver());
//        Call getScreenshotAs method to create image file
                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
//                Copy file at destination             
//                FileUtils.copyFile(SrcFile, new File("\\"+fileEntry+ testname +System.currentTimeMillis()+".jpg"));
                FileUtils.copyFile(SrcFile, new File(theDir.getAbsolutePath()+"\\"+ testname +"_"+ System.currentTimeMillis()+".jpg"));
                
//                FileUtils.copyFile(SrcFile, DestFile);
    }
	
	
	/**
	 * This function takes snapshot of the window
	 * 
	 *Developed by Manish Bhagat
	 */
	
	public static void takewindowSnapShot(String testname) throws Exception{

        //Convert web driver object to TakeScreenshot
 
		String fileEntry= System.getProperty("user.dir")+"\\src\\main\\resources\\temporaryscreenshots\\";
		System.out.println(fileEntry);
		
		//using robot class
		Robot robot= null;
		robot= new Robot();
		Toolkit toolkit= Toolkit.getDefaultToolkit();
		Dimension dim= toolkit.getScreenSize();
		BufferedImage i= null;
		i= robot.createScreenCapture(new Rectangle(0,0,dim.width,dim.height));
		File output= new File(fileEntry+ "testname" +System.currentTimeMillis()+".jpg");
		ImageIO.write(i, "jpg", output);
	
//		//using driver
//        TakesScreenshot scrShot =((TakesScreenshot)DeviceUtils.getQAFDriver());
////        Call getScreenshotAs method to create image file
//                File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
////                Copy file at destination             
//                FileUtils.copyFile(SrcFile, new File(fileEntry+"\\"+ "testname" + "_"+System.currentTimeMillis()+".jpg"));
		
		// Load the document
//		Workbook workbook=new Workbook();
//		workbook.open("FinancialKPI.xlsx");
//		workbook.save("FinancialKPI.pdf", SaveFileFormat.Pdf);
                
    }
	
	
	public static void storeSnapShot() throws Exception{

        //Convert web driver object to TakeScreenshot
		String fileWithPath= System.getProperty("user.dir")+"\\src\\main\\resources\\screenshots\\";
		System.out.println(fileWithPath);
		File folder = new File(fileWithPath);
		File[] listOfFiles = folder.listFiles();

		for (File file : listOfFiles) {
		    if (file.isFile()) {
		        System.out.println(file.getName());
		    }
		}

    }
	
	public static void GroupScreenshots1(String tc) throws Exception{

		Groupscreenshots(tc,imageFolderPath);
       }
	
	
	public static void Groupscreenshots(String tc,final File folder) throws Exception{

	   try {
		   for(final File fileEntry: folder.listFiles()) {
			   if(fileEntry.isDirectory()) {
				   Groupscreenshots(tc,fileEntry);
			   }else {
				   ListOfImages.add(fileEntry.getAbsolutePath());
			         }
		   }
	   }catch(Exception e){
	    e.printStackTrace();
		 }
       writeExcel(tc,ListOfImages.subList(0, ListOfImages.size()));
       Delete(imageFolderPath);
       }
 
    public static void writeExcel(String docName, List<String> imageSubList) {
    	
    	System.out.println("entered");
    	int height1=0;
    	int img1=0;
    	String screenshotfilename= outputPath+ docName+ "_"+ timeStamp +".xls";
    	System.out.println(screenshotfilename);
    	int height;
    	try {
    		Workbook wb= new HSSFWorkbook();
    		Sheet sheet= wb.createSheet();
    		for(int i=0; i<imageSubList.size();i++)
    		{
    			
    			String filePath= imageSubList.get(i);
    			InputStream is= new FileInputStream(filePath);
    			byte[] byte1= IOUtils.toByteArray(is);
    			int pictureIdx= wb.addPicture(byte1, Workbook.PICTURE_TYPE_JPEG);
    			is.close();
    			CreationHelper helper= wb.getCreationHelper();
    			
    			Drawing drawing= sheet.createDrawingPatriarch();
    			
    			ClientAnchor anchor= helper.createClientAnchor();
    			
    			File file= new File(filePath);
    			BufferedImage image= null;
    			
    			try {
    				image= ImageIO.read(file);
    			}catch(IOException e) {
    				e.printStackTrace();	
    		}
    			if(i==0) {
    				anchor.setCol1(1);
    				anchor.setRow1(img1);
    				img1= image.getHeight()/20 +5;
    			}
    			else if (i==1) {
    			anchor.setCol1(1);
    			anchor.setRow1(img1);
    			height1= img1+ (image.getHeight()/20 +5);
    			
    			}else {
    				anchor.setCol1(1);
    				anchor.setRow1(height1);
    				height= image.getHeight()/20;
    				height1 = height1+ height+5;
    			}
    			Picture pict= drawing.createPicture(anchor, pictureIdx);
    			pict.resize();
    		}
    		
    		if(wb instanceof HSSFWorkbook)
    			screenshotfilename += "x";
    		FileOutputStream fileOut= new FileOutputStream(screenshotfilename);
    		wb.write(fileOut);
    		fileOut.close();
    	}catch (Exception e) {
    		e.printStackTrace();
    	}	
    	
    }

    
    public static void Delete(final File folder)
    {
    	
    try {
    	for(final File fileEntry: folder.listFiles()) {
    		if(fileEntry.isDirectory()) {
    			Delete(fileEntry);
    		}else {
    			ListOfImages.remove(fileEntry.delete());
    		}
    	}
    		
    }catch(Exception e) {
    	e.printStackTrace();
    }
    	
    	
    }
	
	/**
	 * This function create connection to backend ORACLE databse
	 * 
	 * @return estalished connection is returned Developed by Karthik Dhanapal
	 */
	public static Connection setUpDBConnection() {
		Connection con = null;
		// Connection string for oracle DB connectivity
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con = java.sql.DriverManager.getConnection(
					"jdbc:oracle:thin:@" + properties.getProperty("DEVHOST") + ":"
							+ properties.getProperty("DEVDBName"),
					properties.getProperty("DEVDBUserName"), properties.getProperty("DEVDBPassword"));
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return con;

	}

	/**
	 * This function retrieve all records (META DATA) from the query result
	 * 
	 * @param proposalNumber
	 * @return Developed by Karthik Dhanapal
	 */
	public List<List<String>> GetproposalDBRecord(String proposalNumber) {
		Connection con = null;
		ArrayList<String> inner;
		List<List<String>> outer = new ArrayList<>();
		try {
			con = setUpDBConnection();
			// step3 create the statement object
			Statement stmt = con.createStatement();
			// step4 execute query
			ResultSet rs = stmt.executeQuery(
					"DECLARE return_code varchar2(10); BEGIN CSMS_ENABLE_ROLE('clcw',RETURN_CODE); IF return_code<>'0' THEN raise_application_error(-20001, 'Invalid return code ('||return_code||') in CSMS_ENABLE_ROLE'); END IF; END;");

			String proposalQuery = "SELECT * FROM VW_PROP_DETAILS_IFPNB_TB WHERE PSNO = '" + proposalNumber
					+ "' ORDER BY SEQ_NO";

			rs = stmt.executeQuery(proposalQuery);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			while (rs.next()) {
				inner = new ArrayList<String>();
				for (int i = 1; i <= columnsNumber; i++) {
					inner.add(rs.getString(i));
				}
				outer.add(inner);
			}
			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("No value");
		}
		return outer;
	}

	public List<List<String>> GethealthSummaryDBRecord(String proposalNumber) {
		Connection con = null;
		ArrayList<String> inner;
		List<List<String>> outer = new ArrayList<>();
		try {
			con = setUpDBConnection();
			// step3 create the statement object
			Statement stmt = con.createStatement();
			// step4 execute query
			ResultSet rs = stmt.executeQuery(
					"DECLARE return_code varchar2(10); BEGIN CSMS_ENABLE_ROLE('clcw',RETURN_CODE); IF return_code<>'0' THEN raise_application_error(-20001, 'Invalid return code ('||return_code||') in CSMS_ENABLE_ROLE'); END IF; END;");

			String proposalQuery = "SELECT * FROM VW_PROP_DETAILS_IFPNB_TB WHERE PSNO = '" + proposalNumber
					+ "' ORDER BY SEQ_NO";

			rs = stmt.executeQuery(proposalQuery);
			ResultSetMetaData rsmd = rs.getMetaData();
			int columnsNumber = rsmd.getColumnCount();
			while (rs.next()) {
				inner = new ArrayList<String>();
				for (int i = 1; i <= columnsNumber; i++) {
					inner.add(rs.getString(i));
				}
				outer.add(inner);
			}
			// step5 close the connection object
			con.close();

		} catch (Exception e) {
			System.out.println(e);
			System.out.println("No value");
		}
		return outer;
	}
	
	
	
	
	
	public static String convertDate(String dbdate){
		String[] datesplit= dbdate.split(" ");
		String date= datesplit[0];
		String[] datesplitdb= date.split("-");
		
		String yyyy= datesplitdb[0];
		String mm=datesplitdb[1];
		String dd=datesplitdb[2];
		String strDate = dd+"-"+ mm+ "-" +yyyy;
		return strDate;
	}

	public String getProposalNumber(String surName, String givenNAme) {
		String proposalNumber = "";
		Connection con = null;
		try {
			con = setUpDBConnection();
			// step3 create the statement object
			Statement stmt = con.createStatement();
			// step4 execute query
			ResultSet rs = stmt.executeQuery(
					"DECLARE return_code varchar2(10); BEGIN CSMS_ENABLE_ROLE('clcw',RETURN_CODE); IF return_code<>'0' THEN raise_application_error(-20001, 'Invalid return code ('||return_code||') in CSMS_ENABLE_ROLE'); END IF; END;");

			String proposalQuery = "select PSNO from VW_PROP_DETAILS_IFPNB_TB where ins_surname = '" + surName
					+ "' and ins_givenname = '" + givenNAme + "'ORDER BY PSNO";

			rs = stmt.executeQuery(proposalQuery);
			while (rs.next())
				proposalNumber = rs.getString(1);
			// step5 close the connection object
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		return proposalNumber;

	}

	

	@SuppressWarnings("rawtypes")
	public void clickRadioButton(String objectLocator, String optionIndex) {
		WebElement element = DeviceUtils.getQAFDriver().findElement(By.xpath(objectLocator));
		try {
			if (!element.isSelected()) {
				JavascriptExecutor executor = (JavascriptExecutor) DeviceUtils.getQAFDriver();
				executor.executeScript("arguments[" + optionIndex + "].click();", element);
			}
		} catch (Exception e) {
			System.out.println(e);
			List oRadioButton = DeviceUtils.getQAFDriver().findElementsByXPath(objectLocator);
			((WebElement) oRadioButton.get(Integer.parseInt(optionIndex))).click();

		}

	}

	public void selectdropdown(String objectref, String val) {
		System.out.println("Manish");
		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath(objectref));
		Select dropdown = new Select(mySelectElement);
		dropdown.selectByVisibleText(val);
	}
	
	public void newselectdropdown(String val) throws Exception {
		System.out.println("Masfghfh");
		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("//input[@class='autocomplete-input fix-input-size ng-untouched ng-pristine ng-invalid']"));
		mySelectElement.click();
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@id='mat-autocomplete-0']/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(val))
			{
				dropdown1.get(i).click();
				break;
			}
			}
	}
	
	public void relationshipselectdropdown(String val) throws Exception {
		System.out.println("Mafh");
//		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[2]/div[2]/app-solid-line-auto-complete-input-box/div/input"));
		List<WebElement> mySelectElement = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='autocomplete-span-arrow ng-invalid ng-dirty ng-touched']"));
		int size1= mySelectElement.size();
		for(int i=0;i<size1;i++)
		{
		
			mySelectElement.get(0).click();
			break;
	
		}
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(@id,'mat-autocomplete-')]/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(val))
			{
				dropdown1.get(i).click();
				break;
			}
			}
		System.out.println("Mafh");
	}
	
	public void monthdropdown(String val) throws Exception {
		
		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='expiration_month_list']"));
		Select dropdown = new Select(mySelectElement);
		dropdown.selectByVisibleText(val);
		
	}
	
	public void yeardropdown(String val) throws Exception {
		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("//*[@id='expiration_year_list']"));
		Select dropdown = new Select(mySelectElement);
		dropdown.selectByVisibleText(val);
	}
	
	public void disclaimer() throws Exception {
		System.out.println("Mafh");
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='disclaimer']"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
				dropdown1.get(i).click();
				Thread.sleep(2000);
			}
			}
	
	public void documenttypeselectdropdown(String documenttype) throws Exception {
		System.out.println("Mah");
		List<WebElement> mySelectElement = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='autocomplete-span-arrow ng-invalid ng-dirty ng-touched']"));
		int size1= mySelectElement.size();
		for(int i=0;i<size1;i++)
		{
			mySelectElement.get(1).click();
			break;
	
		}
//		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("/html/body/ngb-modal-window/div/div/app-vhis-beneficiary-personal/div[2]/form/div[3]/div[1]/app-solid-line-auto-complete-input-box/div/input"));
//		mySelectElement.click();
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(@id,'mat-autocomplete-')]/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(documenttype))
			{
				dropdown1.get(i).click();
				break;
			}
			}
	}
	
	public void trusteerelationshipselectdropdown(String val) throws Exception {
		
		System.out.println("Mfh");
		List<WebElement> mySelectElement = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='autocomplete-input ng-untouched ng-pristine ng-invalid']"));
		int size1= mySelectElement.size();                                                              
		for(int i=0;i<size1;i++)
		{
			mySelectElement.get(0).click();
			break;
	
		}
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(@id,'mat-autocomplete-')]/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(val))
			{
				dropdown1.get(i).click();
				break;
			}
			}
		System.out.println("Masfh");
	}
	
	public void trusteedocumenttypeselectdropdown(String documenttype) throws Exception {
		System.out.println("Masfh");
		
		List<WebElement> mySelectElement = DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@class='autocomplete-input ng-untouched ng-pristine ng-valid']"));
		int size1= mySelectElement.size();
		for(int i=0;i<size1;i++)
		{
			mySelectElement.get(0).click();
			break;
	
		}
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[contains(@id,'mat-autocomplete-')]/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(documenttype))
			{
				dropdown1.get(i).click();
				break;
			}
			}
	}
	
	
	
	public void new1selectdropdown(String val) throws Exception {
		System.out.println("Masfhfh");
		WebElement mySelectElement = DeviceUtils.getQAFDriver().findElement(By.xpath("//input[@class='autocomplete-input fix-input-size ng-untouched ng-pristine ng-invalid']"));
		mySelectElement.click();
		List<WebElement> dropdown1= DeviceUtils.getQAFDriver().findElements(By.xpath("//*[@id='mat-autocomplete-1']/mat-option/span"));
		int size= dropdown1.size();
		for(int i=0;i<size;i++)
		{
			String xyz= dropdown1.get(i).getText();
			System.out.println(xyz);
			if(xyz.equalsIgnoreCase(val))
			{
				dropdown1.get(i).click();
				break;
			}
			}
	}

	public void createtxtfile(String data, String filepath) {
		try {
			FileWriter fw = new FileWriter(filepath + "/proposalmapping.txt", true); // the true will append the new
			fw.write(data + "\n");// appends the string to the file
			fw.close();
		} catch (IOException ioe) {
			System.err.println("IOException: " + ioe.getMessage());
		}
	}

	@When("^user access excel from data folder sheet$")
	public void user_access_excel_from_data_folder_sheet() throws Throwable {

		String filePath = System.getProperty("user.dir") + "\\src\\main\\resources\\data";
		readExcel(filePath, "testcaseinput_EB.xls", "TCOE");
	}

	public void readExcel(String filePath, String fileName, String sheetName) throws IOException {

		// Create an object of File class to open xlsx file
		File file = new File(filePath + "\\" + fileName);

		// Create an object of FileInputStream class to read excel file
		FileInputStream inputStream = new FileInputStream(file);
		Workbook guru99Workbook = null;

		// Find the file extension by splitting file name in substring and getting only
		// extension name
		String fileExtensionName = fileName.substring(fileName.indexOf("."));

		// Check condition if the file is xlsx file
		if (fileExtensionName.equals(".xlsx")) {

			// If it is xlsx file then create object of XSSFWorkbook class
			guru99Workbook = new HSSFWorkbook(inputStream);

		}

		// Check condition if the file is xls file
		else if (fileExtensionName.equals(".xls")) {

			// If it is xls file then create object of XSSFWorkbook class
			guru99Workbook = new HSSFWorkbook(inputStream);

		}

		// Read sheet inside the workbook by its name
		Sheet guru99Sheet = guru99Workbook.getSheet(sheetName);

		// Find number of rows in excel file
		int rowCount = guru99Sheet.getLastRowNum() - guru99Sheet.getFirstRowNum();

		// Create a loop over all the rows of excel file to read it
		for (int i = 0; i < rowCount + 1; i++) {

			Row row = guru99Sheet.getRow(i);
			// Create a loop to print cell values in a row

			for (int j = 0; j < row.getLastCellNum(); j++) {
				// Print Excel data in console
				System.out.print(row.getCell(j) + "  ");
			}

			System.out.println();

		}

	}

//	@SuppressWarnings("unused")
//	private String getCellValueAsString(XSSFCell cell, FormulaEvaluator formulaEvaluator) throws Exception {
//		if (cell == null || cell.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
//			return "";
//		} else {
//			if (formulaEvaluator.evaluate(cell).getCellType() == HSSFCell.CELL_TYPE_ERROR) {
//				throw new Exception("Error in formula within this cell! " + "Error code: " + cell.getErrorCellValue());
//			}
//
//			DataFormatter dataFormatter = new DataFormatter();
//			return dataFormatter.formatCellValue(formulaEvaluator.evaluateInCell(cell));
//		}
//	}

	/**
	 * 
	 */
	public static Connection connectAzureDB() {
		// Connect to database
//		String hostName = "azugessqlprodeas.database.secure.windows.net";
//		String dbName = "dev-hk-crm-azure-db";
//		String user = "u914006e7b2f";
//		String password = "K0GJIVmhvQGX9+e+2duSdKbpliEWI11IKlD7bgPJj7zdy6oCycuwWQ==";
//		String url = String.format(
//				"jdbc:sqlserver://%s:14376;database=%s;user=%s;password=%s;encrypt=true;hostNameInCertificate=*.database.secure.windows.net;loginTimeout=200;",
//				hostName, dbName, user, password);

		String hostName = properties.getProperty("hostName");
		String dbName = properties.getProperty("dbName");
		String user = properties.getProperty("user");
		String password = properties.getProperty("password");
		String url = String.format(
				"jdbc:sqlserver://%s:14376;database=%s;user=%s;password=%s;encrypt=true;hostNameInCertificate=*.database.secure.windows.net;loginTimeout=200;",
				hostName, dbName, user, password);

		Connection conAzure = null;

		try {
			conAzure = DriverManager.getConnection(url);
			String schema = conAzure.getSchema();
			System.out.println("Successful connection - Schema: " + schema);
			System.out.println("Query data example:");
			System.out.println("=========================================");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return conAzure;
	}

	public List<List<String>> getClouddata(String tableName) {
		Connection conAzure = null;
		ArrayList<String> inner;
		List<List<String>> outer = new ArrayList<>();
		conAzure = connectAzureDB();

		String selectSql = "select * from " + tableName;

		try (Statement statement = conAzure.createStatement();
				ResultSet resultSet = statement.executeQuery(selectSql)) {
			ResultSetMetaData rsmd = resultSet.getMetaData();

			int columnsNumber = rsmd.getColumnCount();
			while (resultSet.next()) {
				inner = new ArrayList<String>();
				for (int i = 1; i <= columnsNumber; i++) {
					inner.add(resultSet.getString(i));
				}
				outer.add(inner);
			}
			conAzure.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return outer;
	}

	@SuppressWarnings("rawtypes")
	public void storeDatainExcel(String sheetName, List tableHeader, List tableContent) {

		// Blank workbook
		HSSFWorkbook workbook = new HSSFWorkbook();

		// Create a blank sheet
		HSSFSheet sheet = workbook.createSheet(sheetName);

		// This data needs to be written (Object[])
		Map<String, Object[]> data = new TreeMap<String, Object[]>();

		for (int k = 0; k < tableContent.size(); k++) {

			data.put(Integer.toString(k), new Object[] {});

		}

		data.put("1", new Object[] { "ID", "NAME", "LASTNAME" });
		data.put("2", new Object[] { 1, "Amit", "Shukla" });
		data.put("3", new Object[] { 2, "Lokesh", "Gupta" });
		data.put("4", new Object[] { 3, "John", "Adwards" });
		data.put("5", new Object[] { 4, "Brian", "Schultz" });

		// Iterate over data and write to sheet
		Set<String> keyset = data.keySet();
		int rownum = 0;
		for (String key : keyset) {
			Row row = sheet.createRow(rownum++);
			Object[] objArr = data.get(key);
			int cellnum = 0;
			for (Object obj : objArr) {
				Cell cell = row.createCell(cellnum++);
				if (obj instanceof String)
					cell.setCellValue((String) obj);
				else if (obj instanceof Integer)
					cell.setCellValue((Integer) obj);
			}
		}
		try {
			// Write the workbook in file system
			FileOutputStream out = new FileOutputStream(new File("howtodoinjava_demo.xlsx"));
			workbook.write(out);
			out.close();
			System.out.println("howtodoinjava_demo.xlsx written successfully on disk.");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
