package com.manulife.ap;

public class PCResponse {
	private String returnCode;
	private String returnMessage;
	private String  transactionReferenceNumber;
	public String getReturnCode() {
		return returnCode;
	}
	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}
	public String getReturnMessage() {
		return returnMessage;
	}
	public void setReturnMessage(String returnMessage) {
		this.returnMessage = returnMessage;
	}
	public String getTransactionReferenceNumber() {
		return transactionReferenceNumber;
	}
	public void setTransactionReferenceNumber(String transactionReferenceNumber) {
		this.transactionReferenceNumber = transactionReferenceNumber;
	}
	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("PCResponse [returnCode=").append(returnCode).append(", returnMessage=").append(returnMessage)
				.append(", transactionReferenceNumber=").append(transactionReferenceNumber).append("]");
		return builder.toString();
	}
	
}
