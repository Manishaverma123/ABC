package com.manulife.ap.listener;

import org.openqa.selenium.Capabilities;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebDriverCommandAdapter;

public class ProxyListener extends QAFWebDriverCommandAdapter {
    @Override
   public void beforeInitialize(Capabilities desiredCapabilities) {
 //      super.beforeInitialize(desiredCapabilities);
//       System.getProperties().put("http.proxyHost", "10.129.255.41");
//       System.getProperties().put("http.proxyPort", "80");
//       System.getProperties().put("https.proxyHost", "10.129.255.41");
//       System.getProperties().put("https.proxyPort","80");
   }
}
