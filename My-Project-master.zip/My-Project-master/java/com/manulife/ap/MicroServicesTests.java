/*************************************************************************
 * Manulife Financial Service CONFIDENTIAL

 * 
 *  All Rights Reserved.
 * 
 * NOTICE:  All information contained herein is, and remains
 * the property of Manulife Financial Services,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Manulife Financial Services
 * and its suppliers and may be covered by patents in process, 
 * and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Manulife Financial Services.
 */
package com.manulife.ap;

import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.QAFTestStepProvider;
import com.qmetry.qaf.automation.ws.RestWSTestCase;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

import org.hamcrest.Matchers;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Assert;
import com.sun.jersey.api.client.ClientResponse.Status;
//import javax.json.Json;
//import javax.json.stream.JsonGenerator;

@SuppressWarnings("unused")
@QAFTestStepProvider
public class MicroServicesTests extends RestWSTestCase {

	// Create object for class Reusable function to access
	Reusablefunction accessResuablefunction = new Reusablefunction();

	// Create object for JAVA property file
	static Properties properties = Settings.getInstance();

	// public static Map<String, String> data = new HashMap<String, String>();

	// public variable for JSONArray
	public static JSONArray jsonArrayOutput;

	// public variable for JSON output
	public static String jsonWithValue;

	// public variable to store accessToken
	public static String accessToken = "";

	// variable to store header information from JSON output
	JSONObject reader;

	// variable to store JSONKey information from JSON output
	JSONObject parentObject;

	/**
	 * This below method hit the end point url with authorization token METHOD :
	 * POST HEADER INFO - Content-Type : application/json INPUT PARAMETERS :
	 * accessToken; jsonWithValue ; endpointURL DEVELOPED BY : KARTHIK DHANANAPAL *
	 */
	@When("^user request for end point url \"([^\"]*)\" and call method \"([^\"]*)\"$")
	public void user_request_for_end_point_url(String endpointURL, String callMethod) throws Throwable {

		switch (callMethod.toUpperCase()) {

		case "POST":
			if (!accessToken.isEmpty()) {
				getWebResource(endpointURL).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + accessToken).post(jsonWithValue);
			} else {
				getWebResource(endpointURL).header("Content-Type", "application/json").post(jsonWithValue);
			}
			break;
		case "DELETE":
			if (!accessToken.isEmpty()) {
				getWebResource(endpointURL).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + accessToken).delete();
			} else {
				getWebResource(endpointURL).header("Content-Type", "application/json").delete();
			}
			break;
		case "GET":
			if (!accessToken.isEmpty()) {
				getWebResource(endpointURL).header("Content-Type", "application/json").header("Authorization",
						"Bearer " + accessToken);
			} else {
				getWebResource(endpointURL).header("Content-Type", "application/json");
			}
			break;
		case "PUT":
			if (!accessToken.isEmpty()) {
				getWebResource(endpointURL).header("Content-Type", "application/json")
						.header("Authorization", "Bearer " + accessToken).put(jsonWithValue);
			} else {
				getWebResource(endpointURL).header("Content-Type", "application/json").put(jsonWithValue);
			}
			break;

		}
		// verify response
		verifyThat("Response Status", getResponse().getStatus(), Matchers.equalTo(Status.OK));
//For future references
//		getWebResource(
//		"https://pc-calc-request-service-msand-v50.apps.eas.pcf.manulife.com/api/triggerIfpnbPcCalculation")
//				.header("Content-Type", "application/json").post(new Gson().toJson(platform));

	}

	/**
	 * This below method get authorization token from end point and store in public
	 * variable accessToken. METHOD : POST HEADER INFO - Content-Type :
	 * application/json INPUT PARAMETERS : client_idValue ; client_secretValue ;
	 * grant_typeValue - NOTE : Input parameter assigned in DataQueries.property
	 * file DEVELOPED BY : KARTHIK DHANANAPAL *
	 */
	@When("^user request get access token for end point url \"([^\"]*)\" with body configuration \"([^\"]*)\"$")
	public void user_request_token_for_end_point_url(String endpointURL, String serviceName) throws Throwable {

		String jsonWithAccessValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("client_idValue", properties.getProperty("authorizationTokenInputParameter1"))
				.replace("client_secretValue", properties.getProperty("authorizationTokenInputParameter2"))
				.replace("grant_typeValue", properties.getProperty("authorizationTokenInputParameter3"));

		getWebResource(endpointURL).header("Content-Type", "application/json").post(jsonWithAccessValue);
		accessToken = (String) new JSONObject(getResponse().getMessageBody().toString()).get("token");

	}

	/**
	 * This below method calls the end point for the service mentioned. METHOD :
	 * POST HEADER INFO - Content-Type : application/json INPUT PARAMETERS :
	 * client_idValue ; client_secretValue ; grant_typeValue - NOTE : Input
	 * parameter assigned in DataQueries.property file DEVELOPED BY : KARTHIK
	 * DHANANAPAL *
	 */
	@When("^user request for end point url \"([^\"]*)\" with body configuration \"([^\"]*)\"$")
	public String userrequest_for_end_point_url(String endpointURL, String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName);

		// getWebResource(endpointURL).header("Content-Type",
		// "application/json").post(jsonWithValue);
		// accessToken = (String) new
		// JSONObject(getResponse().getMessageBody().toString()).get("token");
		return jsonWithValue;
	}

	@When("^user creates JSON Body with policynumber \"([^\"]*)\" proposalnumber \"([^\"]*)\" and scandate \"([^\"]*)\" for IFNB calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_policynumber_and_proposalnumber(String Policyno, String ProposalRefno,
			String scanDate, String serviceName) throws ParseException {
		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName).replace("policyNumberValue", Policyno)
				.replace("proposalNumberValue", ProposalRefno)
				.replace("scanDateValue", accessResuablefunction.changeDateFormat(scanDate));

		return jsonWithValue;

	}
	
	@When("^user reads the data \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" and \"([^\"]*)\" for ContactData Maintenance and validates the same from database$")
	 public void getTestDatafrominputsheet(String Userid,String TnxDate,String MCN,String AddressLanguage,String AddressNo,String Flat,String StreetNo,String District,String Zone,String InvalidSignal,String ResidentialCountry,String ResidentialPhone,String Residentialinvalid,String MobileCountry,String MobilePhone,String MobileInvalid,String MobileSameContact,String OfficeCountry,String OfficePhone,String OfficePhoneext,String OfficeInvalid,String FaxCountry,String FaxPhone,String FaxInvalid,String EmailAddress,String EmailInvalid,String EmailSameContact,String ChangeReason,String LanguagePreference) throws Exception{

		Reusablefunction obj= new Reusablefunction();
//	obj.fetchdatafromexcel(Userid,TnxDate,MCN,AddressLanguage,AddressNo,Flat,StreetNo,District,Zone,InvalidSignal,ResidentialCountry,ResidentialPhone,Residentialinvalid,MobileCountry,MobilePhone,MobileInvalid,MobileSameContact,OfficeCountry,OfficePhone,OfficePhoneext,OfficeInvalid,FaxCountry,FaxPhone,FaxInvalid,EmailAddress,EmailInvalid,EmailSameContact,ChangeReason,LanguagePreference);

  }
	
	public  List<ArrayList> getTestDataContactDataMaintenance(String mcn,String transactiondate) throws NullPointerException, ParseException{

		ConnectAzureDB ref= new ConnectAzureDB();
        List<ArrayList> testData= ref.getTestDataContactDataMaintenance(mcn,transactiondate);
        System.out.println("Data from  table");
        System.out.println(testData);
        return testData;
    }
	
	public  List<ArrayList> getTestDataContactDataMaintenancecontact(String mcn,String transactiondate,String reason_code) throws NullPointerException, ParseException{

		ConnectAzureDB ref= new ConnectAzureDB();
        List<ArrayList> testData= ref.getTestDataContactDataMaintenancecontact(mcn,transactiondate,reason_code);
        System.out.println("Data from  table");
        System.out.println(testData);
        return testData;
    }
	
	public  List<ArrayList> getTestDataContactDataMaintenanceaddress(String mcn,String transactiondate,String reason_code) throws NullPointerException, ParseException{

		ConnectAzureDB ref= new ConnectAzureDB();
        List<ArrayList> testData= ref.getTestDataContactDataMaintenanceaddress(mcn,transactiondate,reason_code);
        System.out.println("Data from  table");
        System.out.println(testData);
        return testData;
    }

	/**
	 * This below method create input JSON for IFPNB calculation service and return
	 * input JSON String. OUTPUT PARAMETER : jsonWithValue* DEVELOPED BY KARTHIK
	 * DHANAPAL
	 */
	@When("^user creates JSON Body with businessCategory \"([^\"]*)\", paymentIndicator \"([^\"]*)\" , policyNumber \"([^\"]*)\" ,proposalNumber \"([^\"]*)\" ,scanDate \"([^\"]*)\" ,submissionChannel \"([^\"]*)\" ,submitType \"([^\"]*)\" ,sysCode \"([^\"]*)\" for IFNB calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_businessCategory_paymentIndicator_policyNumber_proposalNumber_scanDate_submissionChannel_submitType_sysCode_for_IFNB_calculator_service(
			String businessCategoryValue, String paymentIndicatorValue, String policyNumberValue,
			String proposalNumberValue, String scanDateValue, String submissionChannelValue, String submitTypeValue,
			String sysCodeValue, String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)

				// .replace("lobValue", lobValue)
				.replace("businessCategoryValue", businessCategoryValue)
				.replace("paymentIndicatorValue", paymentIndicatorValue).replace("policyNumberValue", policyNumberValue)
				.replace("proposalNumberValue", proposalNumberValue)
				.replace("scanDateValue", accessResuablefunction.changeDateFormat(scanDateValue))
				.replace("submissionChannelValue", submissionChannelValue).replace("submitTypeValue", submitTypeValue)
				.replace("sysCodeValue", sysCodeValue);

		return jsonWithValue;
	}

	@When("^user creates JSON Body with agentCode \"([^\"]*)\" and Split percentange \"([^\"]*)\" for EB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_agentCode_and_Split_percentange_for_EB_Calculator_service(
			String agentCode, String splitPercentage, String serviceName) throws Throwable {
		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName).replace("agentCodeValue", agentCode)
				.replace("splitPercentageValue", String.valueOf(splitPercentage));

		return jsonWithValue;
	}

	/**
	 * This below method create input JSON for EB service and return input JSON
	 * String. OUTPUT PARAMETER : jsonWithValue* DEVELOPED BY KARTHIK DHANAPAL
	 */

	@When("^user creates JSON Body with agentCode(\\d+)_input \"([^\"]*)\" ,splitPercentage(\\d+) \"([^\"]*)\" ,agentCode(\\d+)_input \"([^\"]*)\" ,splitPercentage(\\d+) \"([^\"]*)\" ,appInDate \"([^\"]*)\" , appInKey \"([^\"]*)\" ,businessCategory \"([^\"]*)\" ,certificateNum \"([^\"]*)\" ,contractNum \"([^\"]*)\" ,paymentIndicator \"([^\"]*)\" ,proposalInsuredName \"([^\"]*)\" ,proposalOwnerName \"([^\"]*)\" ,subGroupNum \"([^\"]*)\" ,submissionChannel \"([^\"]*)\" ,submitSalesKey \"([^\"]*)\" ,submitType \"([^\"]*)\" ,sysCode \"([^\"]*)\" for EB calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_agentCode_splitPercentage_agentCode_splitPercentage_appInKey_businessCategory_certificateNum_contractNum_paymentIndicator_proposalInsuredName_proposalOwnerName_subGroupNum_submissionChannel_submitSalesKey_submitType_sysCode_for_EB_calculator_service(
			int arg1, String agentCode1Value, int arg3, String splitPercentage1Value, int arg5, String agentCode2Value,
			int arg7, String splitPercentage2Value, String appInDateValue, String appInKeyValue,
			String businessCategoryValue, String certificateNumValue, String contractNumValue,
			String paymentIndicatorValue, String proposalInsuredNameValue, String proposalOwnerNameValue,
			String subGroupNumValue, String submissionChannelValue, String submitSalesKeyValue, String submitTypeValue,
			String sysCodeValue, String serviceName) throws Throwable {

		if (splitPercentage2Value == null) {
			splitPercentage2Value = "0";
		} else if (splitPercentage2Value.isEmpty()) {
			splitPercentage2Value = "0";
		}

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("agentCode1Value", agentCode1Value).replace("splitPercentage1Value", splitPercentage1Value)
				.replace("agentCode2Value", agentCode2Value).replace("splitPercentage2Value", splitPercentage2Value)
				.replace("appInDateValue", "1-Jun-2018").replace("appInKeyValue", appInKeyValue)
				.replace("businessCategoryValue", businessCategoryValue)
				.replace("certificateNumValue", certificateNumValue).replace("contractNumValue", contractNumValue)
				.replace("paymentIndicatorValue", paymentIndicatorValue)
				.replace("proposalInsuredNameValue", proposalInsuredNameValue)
				.replace("proposalOwnerNameValue", proposalOwnerNameValue).replace("subGroupNumValue", subGroupNumValue)
				.replace("submissionChannelValue", submissionChannelValue)
				.replace("submitSalesKeyValue", submitSalesKeyValue).replace("submitSalesKeyValue", submitSalesKeyValue)
				.replace("submitTypeValue", submitTypeValue).replace("sysCodeValue", sysCodeValue);

		JSONObject objectsfrom = new JSONObject(jsonWithValue);
		JSONArray objectsfromArray = objectsfrom.getJSONArray("agentSplitList");

		if (agentCode2Value.isEmpty() || agentCode2Value.equals("")) {
			objectsfromArray.remove(1);
		}

		jsonWithValue = objectsfrom.toString();

		return jsonWithValue;
	}

	/**
	 * This below method read the REST service output for the mentioned JSON Array
	 * and inner JSON Object comparison for String Datatype INPUT PARAMETERS
	 * VARIABLE: expectedOutput jsonObjecttag; jsonObjectKey; arrayIntiation;
	 * jsonArrayKey ; jsonObjectKey ; OUPUT PARAMETER VARIABLE: expectedOutput file
	 * DEVELOPED BY : KARTHIK DHANANAPAL *
	 */
	@Then("^user validate the response from JSON output \"([^\"]*)\" at \"([^\"]*)\" in JSONObjectName \"([^\"]*)\" '(\\d+)' JSON Array \"([^\"]*)\" \\(String Datatype\\)$")
	public void user_validate_the_response_from_JSON_output_at_in_JSONObjectName_JSON_Array_String_Datatype(
			String expectedOutput, String jsonObjecttag, String jsonObjectKey, int arrayIntiation, String jsonArrayKey)
			throws Throwable {
		// Read the header of JSON output
		readHeader(jsonObjectKey, jsonArrayKey);

		// Compare the length of output array with JSONArray(arrayIntiation)
		if (jsonArrayOutput.length() >= arrayIntiation) {
			JSONObject jsonObject = jsonArrayOutput.getJSONObject(arrayIntiation - 1);

			// Get the expected jsonObject from the parent output
			String jsonOutput = jsonObject.getString(String.valueOf(jsonObjecttag));

			// Compare the expected output from excel Vs JSON output
			if (expectedOutput.equals(jsonOutput)) {
				Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
						+ " Actual output - " + jsonOutput, true);
			} else {
				Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
						+ " Actual output - " + jsonOutput, false);
			}
		}
	}

	/**
	 * This below method read the REST service output for the mentioned JSON Array
	 * and inner JSON Object comparison for Double Datatype INPUT PARAMETERS
	 * VARIABLE: expectedOutput jsonObjecttag; jsonObjectKey; arrayIntiation;
	 * jsonArrayKey ; jsonObjectKey ; OUPUT PARAMETER VARIABLE: expectedOutput file
	 * DEVELOPED BY : KARTHIK DHANANAPAL *
	 */
	@Then("^user validate the response from JSON output \"([^\"]*)\" at \"([^\"]*)\" in JSONObjectName \"([^\"]*)\" '(\\d+)' JSON Array \"([^\"]*)\" \\(Double Datatype\\)$")
	public void user_validate_the_response_from_JSON_output_at_JSONObjectName_JSON_Array_int_Datatype(
			String expectedOutput, String jsonObjecttag, String jsonObjectKey, int arrayIntiation, String jsonArrayKey)
			throws Throwable {
		// Read the header of JSON output
		readHeader(jsonObjectKey, jsonArrayKey);

		// Compare the length of output array with JSONArray(arrayIntiation)
		if (jsonArrayOutput.length() >= arrayIntiation) {
			JSONObject jsonObject = jsonArrayOutput.getJSONObject(arrayIntiation - 1);

			// Get the expected jsonObject from the parent output
			Double jsonOutput = jsonObject.getDouble(jsonObjecttag);

			// Compare the expected output from excel Vs JSON output
			if (Double.parseDouble(expectedOutput) == jsonOutput) {
				Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
						+ " Actual output - " + jsonOutput, true);
			} else {
				Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
						+ " Actual output - " + jsonOutput, false);
			}
		}
	}

	@When("^user creates JSON Body with currencyCode \"([^\"]*)\" , faceAmount \"([^\"]*)\" , planCode \"([^\"]*)\" , scanDate \"([^\"]*)\" and versionNumber \"([^\"]*)\" for IFBNB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_currencyCode_faceAmount_planCode_scanDate_and_versionNumber_for_IFBNB_Calculator_service(
			String currencyCodeValue, String faceAmountValue, String planCodeValue, String scanDate,
			String versionNumberValue, String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("currencyCodeValue", currencyCodeValue).replace("faceAmountValue", faceAmountValue)
				.replace("planCodeValue", planCodeValue)
				.replace("scanDateValue", accessResuablefunction.changeDateFormat(scanDate))
				.replace("versionNumberValue", versionNumberValue);

		return jsonWithValue;

	}

	@When("^user creates JSON Body with currencyCode \"([^\"]*)\" and planCode \"([^\"]*)\" for IFBNB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_currencyCode_and_planCode_for_IFBNB_Calculator_service(
			String currencyCodeValue, String planCodeValue, String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("currencyCodeValue", currencyCodeValue).replace("planCodeValue", planCodeValue);

		return jsonWithValue;

	}

	@When("^user creates JSON Body with currencyCode \"([^\"]*)\" , planCode \"([^\"]*)\" and schemeCode \"([^\"]*)\" for IFBNB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_currencyCode_planCode_and_schemeCode_for_IFBNB_Calculator_service(
			String currencyCodeValue, String planCodeValue, String schemeCodeValue, String serviceName)
			throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("currencyCodeValue", currencyCodeValue).replace("planCodeValue", planCodeValue)
				.replace("schemeCodeValue", schemeCodeValue);

		return jsonWithValue;
	}

	@When("^user creates JSON Body with currencyCode \"([^\"]*)\" , planCode \"([^\"]*)\" and versNo \"([^\"]*)\" for IFBNB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_currencyCode_planCode_and_versNo_for_IFBNB_Calculator_service(
			String currencyCodeValue, String planCodeValue, String versNoValue, String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("currencyCodeValue", currencyCodeValue).replace("planCodeValue", planCodeValue)
				.replace("schemeCodeValue", versNoValue);

		return jsonWithValue;
	}

	/**
	 * This below method create input JSON for proposal service and return input
	 * JSON String. OUTPUT PARAMETER : jsonWithValue* DEVELOPED BY KARTHIK DHANAPAL
	 */
	@When("^user creates JSON Body with \"([^\"]*)\" \"([^\"]*)\" for proposal service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_for_IFBNB_Calculator_service(String jsonBodyKey, String proposalNoValue,
			String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName).replace("proposalNoValue",
				proposalNoValue);

		return jsonWithValue;
	}

	/**
	 * This below method read the REST service output and read output value for
	 * mentioned JSONObject compare expected output. INPUT PARAMETERS *
	 * VARIABLE:jsonObjecttag ; jsonObjectKey ; OUPUT PARAMETER VARIABLE:
	 * expectedOutput file DEVELOPED BY : KARTHIK DHANANAPAL *
	 */
	@Then("^user validate the response from JSON output \"([^\"]*)\" at \"([^\"]*)\" in JSONObjectName \"([^\"]*)\" \\(String Datatype\\)$")
	public void user_validate_the_response_from_JSON_output_at_in_JSONObjectName_String_Datatype(String expectedOutput,
			String jsonObjecttag, String jsonObjectKey) throws Throwable {

		// Pass the jsonObjectKey information from JSON output and get the parent
		// information
		readHeader(jsonObjectKey, "");

		// Get the expected jsonObject from the parent output
		String jsonOutput = parentObject.getString(jsonObjecttag);

		// Compare the expected output from excel Vs JSON output
		if (expectedOutput.equals(jsonOutput)) {
			System.out.println(expectedOutput + " ==== " + jsonOutput);
			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
					+ " Actual output - " + jsonOutput, true);
		} else {
			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
					+ " Actual output - " + jsonOutput, false);
		}

	}

	@Then("^user fetch record from oracle DB from the same proposal number for validation \"([^\"]*)\"$")
	public void user_fetch_record_from_oracle_DB_from_the_same_proposal_number_for_validation(String arg1)
			throws Throwable {
		// accessResuablefunction.GetproposalDBRecord(arg1);
		if (accessResuablefunction.GetproposalDBRecord(arg1).size() != 0) {
			assertTrue("Record found for the requested Proposal Number - " + arg1 + " in Database", true);
		} else {
			assertTrue("Record not found for the requested Proposal Number - " + arg1 + " in Database", false);
		}
	}

	@Then("^i validate the output response from service with database records for proposal number \"([^\"]*)\"$")
	public void i_validate_the_output_response_from_service_with_database_records_for_proposal_number(String arg1)
			throws Throwable {

		List<List<String>> getProposalDBRecord = new ArrayList<>();
		String[][] proposalDBRecord = null;
		String[][] proposalService = null;
		String dbrecordPropsalSingleRecord;
		String proposalServiceSingleRecord;
		int i = 0, j = 0, k = 0, l = 0;
		List<String> dbrecord;
		getProposalDBRecord = accessResuablefunction.GetproposalDBRecord(arg1);
		getProposalDBRecord.size();
		getProposalDBRecord.get(0).size();

		proposalDBRecord = new String[getProposalDBRecord.size()][getProposalDBRecord.get(0).size()];

		for (i = 0; i <= getProposalDBRecord.size() - 1; i++) {
			dbrecord = getProposalDBRecord.get(i);
			for (j = 0; j <= getProposalDBRecord.get(i).size() - 1; j++) {
				System.out.println(dbrecord.get(j));
				proposalDBRecord[i][j] = dbrecord.get(j);
			}
		}

		reader = new JSONObject(getResponse().getMessageBody().toString());
		JSONArray proposal = reader.getJSONArray("proposalList");
		proposalService = new String[proposal.length()][proposal.getJSONObject(0).length()];

		for (l = 0; l <= proposal.length() - 1; l++) {
			JSONObject proposalArrayService = proposal.getJSONObject(l);
			// for (k = 0; k <= proposal.getJSONObject(l).length() - 1; k++) {
			// proposalService[l][k] =
			// proposalArrayService.getString(getProposalKey(Integer.toString(k)));
			proposalService[l][0] = proposalArrayService.getString("proposalNo");
			proposalService[l][1] = proposalArrayService.getString("printDate");
			proposalService[l][2] = proposalArrayService.getString("proposalAge");
			proposalService[l][3] = proposalArrayService.getString("planCurrency");
			proposalService[l][4] = proposalArrayService.getString("paymentMode");
			proposalService[l][5] = proposalArrayService.getString("agentCode1");
			try {
				proposalService[l][6] = proposalArrayService.getString("agentCode2");
			} catch (Exception e) {
				proposalService[l][6] = null;
			}
			try {
				proposalService[l][7] = proposalArrayService.getString("agentCode3");
			} catch (Exception e) {
				proposalService[l][7] = null;
			}
			proposalService[l][8] = proposalArrayService.getString("branchCode");
			proposalService[l][9] = proposalArrayService.getString("insSurName");
			proposalService[l][10] = proposalArrayService.getString("insGivenName");
			proposalService[l][11] = proposalArrayService.getString("polSurName");
			proposalService[l][12] = proposalArrayService.getString("polGivenName");
			proposalService[l][13] = proposalArrayService.getString("seqNo");
			proposalService[l][14] = proposalArrayService.getString("planCode");
			try {
				proposalService[l][15] = proposalArrayService.getString("schemeCode");
			} catch (Exception e) {
				proposalService[l][15] = null;
			}
			proposalService[l][16] = proposalArrayService.getString("faceAmt");
			proposalService[l][17] = proposalArrayService.getString("premiumType");
			proposalService[l][18] = proposalArrayService.getString("modalPremium");
			// }
		}

		for (int m = 0; m <= proposal.length() - 1; m++) {
			for (int n = 0; n <= proposal.getJSONObject(0).length() - 1; n++) {

				if (proposalDBRecord[m][n] != null) {
					dbrecordPropsalSingleRecord = proposalDBRecord[m][n];
				} else {
					dbrecordPropsalSingleRecord = "NULL";
				}

				if (proposalService[m][n] != null) {
					proposalServiceSingleRecord = proposalDBRecord[m][n];
				} else {
					proposalServiceSingleRecord = "NULL";
				}

				if (dbrecordPropsalSingleRecord.equals(proposalServiceSingleRecord)) {
					assertTrue("DB Record  " + dbrecordPropsalSingleRecord + "  matched with micro service output "
							+ proposalServiceSingleRecord, true);
				} else {
					assertTrue("DB Record  " + dbrecordPropsalSingleRecord + "  not matched with micro service output "
							+ proposalServiceSingleRecord, false);
				}
			}
		}

	}

	@When("^user creates JSON Body with submitDate \"([^\"]*)\" ,policyNumber \"([^\"]*)\" ,modalPremium \"([^\"]*)\" ,paymentMode \"([^\"]*)\" ,basePlanCode \"([^\"]*)\" ,basePlanTrancheID \"([^\"]*)\" ,coveragePlanCode \"([^\"]*)\" ,coveragePlanTrancheID \"([^\"]*)\" ,isBasicPlan \"([^\"]*)\" ,agentCode \"([^\"]*)\" ,agentSplitPct \"([^\"]*)\" ,appInDate \"([^\"]*)\" ,submitAPE \"([^\"]*)\" ,submitPC \"([^\"]*)\" ,currency \"([^\"]*)\" ,submissionChanel \"([^\"]*)\" ,distributionChannel \"([^\"]*)\" ,lob \"([^\"]*)\" ,submitType \"([^\"]*)\" ,systemCode \"([^\"]*)\" ,policyOwnerName \"([^\"]*)\" ,insuredOwnerName \"([^\"]*)\" for NBWB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_submitDate_policyNumber_modalPremium_paymentMode_basePlanCode_basePlanTrancheID_coveragePlanCode_coveragePlanTrancheID_isBasicPlan_agentCode_agentSplitPct_appInDate_submitAPE_submitPC_currency_submissionChanel_distributionChannel_lob_submitType_systemCode_policyOwnerName_insuredOwnerName_for_NBWB_Calculator_service(
			String submitDateValue, String policyNumberValue, String modalPremiumValue, String paymentModeValue,
			String basePlanCodeValue, String basePlanTrancheIDValue, String coveragePlanCodeValue,
			String coveragePlanTrancheIDValue, String isBasicPlanValue, String agentCodeValue,
			String agentSplitPctValue, String appInDateValue, String submitAPEValue, String submitPCValue,
			String currencyValue, String submissionChanelValue, String distributionChannelValue, String lobValue,
			String submitTypeValue, String systemCodeValue, String policyOwnerNameValue, String insuredOwnerNameValue,
			String serviceName) throws Throwable {

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("submitDateValue", submitDateValue).replace("policyNumberValue", policyNumberValue)
				.replace("modalPremiumValue", modalPremiumValue).replace("paymentModeValue", paymentModeValue)
				.replace("basePlanCodeValue", basePlanCodeValue)
				.replace("basePlanTrancheIDValue", basePlanTrancheIDValue)
				.replace("coveragePlanCodeValue", coveragePlanCodeValue)
				.replace("coveragePlanTrancheIDValue", coveragePlanTrancheIDValue)
				.replace("isBasicPlanValue", isBasicPlanValue).replace("agentCodeValue", agentCodeValue)
				.replace("agentSplitPctValue", agentSplitPctValue).replace("appInDateValue", appInDateValue)
				.replace("submitAPEValue", submitAPEValue).replace("submitPCValue", submitPCValue)
				.replace("currencyValue", currencyValue).replace("submissionChanelValue", submissionChanelValue)
				.replace("distributionChannelValue", distributionChannelValue).replace("lobValue", lobValue)
				.replace("submitTypeValue", submitTypeValue).replace("systemCodeValue", systemCodeValue)
				.replace("policyOwnerNameValue", policyOwnerNameValue)
				.replace("insuredOwnerNameValue", insuredOwnerNameValue);

		return jsonWithValue;
	}

	/**
	 * This below method create input JSON for Topup Calculator service and return
	 * input JSON String. OUTPUT PARAMETER : jsonWithValue* DEVELOPED BY KARTHIK
	 * DHANAPAL
	 */
	@When("^user creates JSON Body with agentCode(\\d+) \"([^\"]*)\" ,agentSplitPercent(\\d+) \"([^\"]*)\" ,agentCode(\\d+) \"([^\"]*)\" ,agentSplitPercent(\\d+) \"([^\"]*)\" ,agentCode(\\d+) \"([^\"]*)\" ,agentSplitPercent(\\d+) \"([^\"]*)\" ,appInDate \"([^\"]*)\" ,basePlanCode \"([^\"]*)\" ,basePlanVersionNumber \"([^\"]*)\" ,batchKeyNo \"([^\"]*)\" ,branchCode \"([^\"]*)\" ,cashierPaymentDate \"([^\"]*)\" ,distributionChannel \"([^\"]*)\" ,insuredgivenName \"([^\"]*)\" ,insuredSurName \"([^\"]*)\" ,lob \"([^\"]*)\" ,policyCurrency \"([^\"]*)\" ,policyNumber \"([^\"]*)\" ,policyOwnerGivenName \"([^\"]*)\" ,policyOwnerSurName \"([^\"]*)\" ,proposalAge \"([^\"]*)\" ,submissionChannel \"([^\"]*)\" ,submitDate \"([^\"]*)\" ,submitType \"([^\"]*)\" ,SubscriptionAmount \"([^\"]*)\" ,systemCode \"([^\"]*)\" for Topup calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_agentCode_agentSplitPercent_agentCode_agentSplitPercent_agentCode_agentSplitPercent_appInDate_basePlanCode_basePlanVersionNumber_batchKeyNo_branchCode_cashierPaymentDate_distributionChannel_insuredgivenName_insuredSurName_lob_policyCurrency_policyNumber_policyOwnerGivenName_policyOwnerSurName_proposalAge_submissionChannel_submitDate_submitType_SubscriptionAmount_systemCode_for_IFNB_calculator_service(
			int arg1, String agentCode1Value, int arg3, String agentSplitPercent1Value, int arg5,
			String agentCode2Value, int arg7, String agentSplitPercent2Value, int arg9, String agentCode3Value,
			int arg11, String agentSplitPercent3Value, String appInDateValue, String basePlanCodeValue,
			String basePlanVersionNumberValue, String batchKeyNoValue, String branchCodeValue,
			String cashierPaymentDateValue, String distributionChannelValue, String insuredgivenNameValue,
			String insuredSurNameValue, String lobValue, String policyCurrencyValue, String policyNumberValue,
			String policyOwnerGivenNameValue, String policyOwnerSurNameValue, String proposalAgeValue,
			String submissionChannelValue, String submitDateValue, String submitTypeValue,
			String subscriptionAmountValue, String systemCodeValue, String serviceName) throws Throwable {

		if (agentSplitPercent2Value == null) {
			agentSplitPercent2Value = "0";
		} else if (agentSplitPercent2Value.isEmpty()) {
			agentSplitPercent2Value = "0";
		}

		if (agentSplitPercent3Value == null) {
			agentSplitPercent3Value = "0";
		} else if (agentSplitPercent3Value.isEmpty()) {
			agentSplitPercent3Value = "0";
		}

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("agentCode1Value", agentCode1Value).replace("agentSplitPercent1Value", agentSplitPercent1Value)
				.replace("agentCode2Value", agentCode2Value).replace("agentSplitPercent2Value", agentSplitPercent2Value)
				.replace("agentCode3Value", agentCode3Value).replace("agentSplitPercent3Value", agentSplitPercent3Value)
				.replace("appInDateValue", accessResuablefunction.changeDateFormat(appInDateValue))
				.replace("basePlanCodeValue", basePlanCodeValue)
				.replace("basePlanVersionNumberValue", basePlanVersionNumberValue)
				.replace("batchKeyNoValue", batchKeyNoValue).replace("branchCodeValue", branchCodeValue)
				.replace("cashierPaymentDateValue", accessResuablefunction.changeDateFormat(cashierPaymentDateValue))
				.replace("distributionChannelValue", distributionChannelValue)
				.replace("insuredgivenNameValue", insuredgivenNameValue)
				.replace("insuredSurNameValue", insuredSurNameValue).replace("lobValue", lobValue)
				.replace("policyCurrencyValue", policyCurrencyValue).replace("policyNumberValue", policyNumberValue)
				.replace("policyOwnerGivenNameValue", policyOwnerGivenNameValue)
				.replace("policyOwnerSurNameValue", policyOwnerSurNameValue)
				.replace("proposalAgeValue", proposalAgeValue).replace("submissionChannelValue", submissionChannelValue)
				.replace("submitDateValue", accessResuablefunction.changeDateFormat(submitDateValue))
				.replace("submitTypeValue", submitTypeValue).replace("subscriptionAmountValue", subscriptionAmountValue)
				.replace("systemCodeValue", systemCodeValue);

		JSONObject objectsfrom = new JSONObject(jsonWithValue);
		JSONArray objectsfromArray = objectsfrom.getJSONArray("agentSplitDetail");

		if (agentCode3Value.isEmpty()) {
			objectsfromArray.remove(2);
		}
		if (agentCode2Value.isEmpty()) {
			objectsfromArray.remove(1);
		}

		jsonWithValue = objectsfrom.toString();

		return jsonWithValue;
	}

	/**
	 * This below method create input JSON for NBWB Calculator service and return
	 * input JSON String. OUTPUT PARAMETER : jsonWithValue* DEVELOPED BY KARTHIK
	 * DHANAPAL
	 */

	@When("^user creates JSON Body with agentCode(\\d+)_input \"([^\"]*)\" ,agentSplitPercent(\\d+) \"([^\"]*)\" ,appInDate(\\d+) \"([^\"]*)\" ,basePlanCode(\\d+) \"([^\"]*)\" ,basePlanTrancheID(\\d+) \"([^\"]*)\" ,coveragePlanCode(\\d+) \"([^\"]*)\" ,coveragePlanTrancheID(\\d+) \"([^\"]*)\" ,currency(\\d+) \"([^\"]*)\" ,distributionChannel(\\d+) \"([^\"]*)\" ,insuredOwnerName(\\d+) \"([^\"]*)\" ,isBasicPlan(\\d+) \"([^\"]*)\" ,lob(\\d+) \"([^\"]*)\" ,modalPremium(\\d+) \"([^\"]*)\" ,paymentMode(\\d+) \"([^\"]*)\" ,policyNumber(\\d+) \"([^\"]*)\" ,policyOwnerName(\\d+) \"([^\"]*)\" ,submissionChanel(\\d+) \"([^\"]*)\" ,submitAPE(\\d+) \"([^\"]*)\" ,submitCaseCount(\\d+) \"([^\"]*)\" ,submitDate(\\d+) \"([^\"]*)\" ,submitPC(\\d+) \"([^\"]*)\" ,submitType(\\d+) \"([^\"]*)\" ,systemCode(\\d+) \"([^\"]*)\" ,agentCode(\\d+)_input \"([^\"]*)\" ,agentSplitPercent(\\d+) \"([^\"]*)\" ,appInDate(\\d+) \"([^\"]*)\" ,basePlanCode(\\d+) \"([^\"]*)\" ,basePlanTrancheID(\\d+) \"([^\"]*)\" ,coveragePlanCode(\\d+) \"([^\"]*)\" ,coveragePlanTrancheID(\\d+) \"([^\"]*)\" ,currency(\\d+) \"([^\"]*)\" ,distributionChannel(\\d+) \"([^\"]*)\" ,insuredOwnerName(\\d+) \"([^\"]*)\" ,isBasicPlan(\\d+) \"([^\"]*)\" ,lob(\\d+) \"([^\"]*)\" ,modalPremium(\\d+) \"([^\"]*)\" ,paymentMode(\\d+) \"([^\"]*)\" ,policyNumber(\\d+) \"([^\"]*)\" ,policyOwnerName(\\d+) \"([^\"]*)\" ,submissionChanel(\\d+) \"([^\"]*)\" ,submitAPE(\\d+) \"([^\"]*)\" ,submitCaseCount(\\d+) \"([^\"]*)\" ,submitDate(\\d+) \"([^\"]*)\" ,submitPC(\\d+) \"([^\"]*)\" ,submitType(\\d+) \"([^\"]*)\" ,systemCode(\\d+) \"([^\"]*)\" for NBWB Calculator service \"([^\"]*)\"$")
	public String user_creates_JSON_Body_with_agentCode__input_agentSplitPercent_appInDate_basePlanCode_basePlanTrancheID_coveragePlanCode_coveragePlanTrancheID_currency_distributionChannel_insuredOwnerName_isBasicPlan_lob_modalPremium_paymentMode_policyNumber_policyOwnerName_submissionChanel_submitAPE_submitCaseCount_submitDate_submitPC_submitType_systemCode_agentCode__input_agentSplitPercent_appInDate_basePlanCode_basePlanTrancheID_coveragePlanCode_coveragePlanTrancheID_currency_distributionChannel_insuredOwnerName_isBasicPlan_lob_modalPremium_paymentMode_policyNumber_policyOwnerName_submissionChanel_submitAPE_submitCaseCount_submitDate_submitPC_submitType_systemCode_for_NBWB_Calculator_service(
			int arg1, String agentCode1_inputValue, int arg3, String agentSplitPercent1Value, int arg5,
			String appInDate1Value, int arg7, String basePlanCode1Value, int arg9, String basePlanTrancheID1Value,
			int arg11, String coveragePlanCode1Value, int arg13, String coveragePlanTrancheID1Value, int arg15,
			String currency1Value, int arg17, String distributionChannel1Value, int arg19,
			String insuredOwnerName1Value, int arg21, String isBasicPlan1Value, int arg23, String lob1Value, int arg25,
			String modalPremium1Value, int arg27, String paymentMode1Value, int arg29, String policyNumber1Value,
			int arg31, String policyOwnerName1Value, int arg33, String submissionChanel1Value, int arg35,
			String submitAPE1Value, int arg37, String submitCaseCount1Value, int arg39, String submitDate1Value,
			int arg41, String submitPC1Value, int arg43, String submitType1Value, int arg45, String systemCode1Value,
			int arg2, String agentCode2_inputValue, int arg311, String agentSplitPercent2Value, int arg51,
			String appInDate2Value, int arg71, String basePlanCode2Value, int arg91, String basePlanTrancheID2Value,
			int arg22, String coveragePlanCode2Value, int arg231, String coveragePlanTrancheID2Value, int arg251,
			String currency2Value, int arg271, String distributionChannel2Value, int arg291,
			String insuredOwnerName2Value, int arg221, String isBasicPlan2Value, int arg2311, String lob2Value,
			int arg2511, String modalPremium2Value, int arg2711, String paymentMode2Value, int arg2911,
			String policyNumber2Value, int arg32, String policyOwnerName2Value, int arg331,
			String submissionChanel2Value, int arg351, String submitAPE2Value, int arg371, String submitCaseCount2Value,
			int arg391, String submitDate2Value, int arg42, String submitPC2Value, int arg431, String submitType2Value,
			int arg451, String systemCode2Value, String serviceName) throws Throwable {

		if (agentCode2_inputValue == null) {
			agentCode2_inputValue = "0";
		} else if (agentSplitPercent2Value.isEmpty()) {
			agentCode2_inputValue = "0";
		}

		jsonWithValue = ConfigurationManager.getBundle().getString(serviceName)
				.replace("agentCode1_inputValue", agentCode1_inputValue)
				.replace("agentSplitPercent1Value", agentSplitPercent1Value)
				.replace("appInDate1Value", accessResuablefunction.changeDateFormat(appInDate1Value))
				.replace("basePlanCode1Value", basePlanCode1Value)
				.replace("basePlanTrancheID1Value", basePlanTrancheID1Value)
				.replace("coveragePlanCode1Value", coveragePlanCode1Value)
				.replace("coveragePlanTrancheID1Value", coveragePlanTrancheID1Value)
				.replace("currency1Value", currency1Value)
				.replace("distributionChannel1Value", distributionChannel1Value)
				.replace("insuredOwnerName1Value", insuredOwnerName1Value)
				.replace("isBasicPlan1Value", isBasicPlan1Value).replace("lob1Value", lob1Value)
				.replace("modalPremium1Value", modalPremium1Value).replace("paymentMode1Value", paymentMode1Value)
				.replace("policyNumber1Value", policyNumber1Value)
				.replace("policyOwnerName1Value", policyOwnerName1Value)
				.replace("submissionChanel1Value", submissionChanel1Value).replace("submitAPE1Value", submitAPE1Value)
				.replace("submitCaseCount1Value", submitCaseCount1Value)
				.replace("submitDate1Value", accessResuablefunction.changeDateFormat(submitDate1Value))
				.replace("submitPC1Value", submitPC1Value).replace("submitType1Value", submitType1Value)
				.replace("systemCode1Value", systemCode1Value).replace("agentCode2_inputValue", agentCode2_inputValue)
				.replace("agentSplitPercent2Value", agentSplitPercent2Value)
				.replace("appInDate2Value", accessResuablefunction.changeDateFormat(appInDate2Value))
				.replace("basePlanCode2Value", basePlanCode2Value)
				.replace("basePlanTrancheID2Value", basePlanTrancheID2Value)
				.replace("coveragePlanCode2Value", coveragePlanCode2Value)
				.replace("coveragePlanTrancheID2Value", coveragePlanTrancheID2Value)
				.replace("currency2Value", currency2Value)
				.replace("distributionChannel2Value", distributionChannel2Value)
				.replace("insuredOwnerName2Value", insuredOwnerName2Value)
				.replace("isBasicPlan2Value", isBasicPlan2Value).replace("lob2Value", lob2Value)
				.replace("modalPremium2Value", modalPremium2Value).replace("paymentMode2Value", paymentMode2Value)
				.replace("policyNumber2Value", policyNumber2Value)
				.replace("policyOwnerName2Value", policyOwnerName2Value)
				.replace("submissionChanel2Value", submissionChanel2Value).replace("submitAPE2Value", submitAPE2Value)
				.replace("submitCaseCount2Value", submitCaseCount2Value)
				.replace("submitDate2Value", accessResuablefunction.changeDateFormat(submitDate2Value))
				.replace("submitPC2Value", submitPC2Value).replace("submitType2Value", submitType2Value)
				.replace("systemCode2Value", systemCode2Value);

		JSONObject objectsfrom = new JSONObject(jsonWithValue);
		JSONArray objectsfromArray = objectsfrom.getJSONArray("exceptionalCases");

		if (agentCode2_inputValue.equals("0")) {
			objectsfromArray.remove(1);
		}

		jsonWithValue = objectsfrom.toString();

		return jsonWithValue;
	}

	
	@QAFTestStep(description="user creates JSON Body with email {0} , reasonCode {1} , userId {2} for update email invalid sig service {3}")
	public String usercreateJSON(String email, String reasonCode, String userId, String ServiceName) {
		jsonWithValue = ConfigurationManager.getBundle().getString(ServiceName)

				// .replace("lobValue", lobValue)
				.replace("emailValue", email)
				.replace("reasonCodeValue", reasonCode)
				.replace("userIdValue", userId);

		return jsonWithValue;
		
		
	}
	
	
	/**
	 * This below method connects to Azure DB and get all value from the mentioned
	 * table name and compared input with output. INPUT PARAMETER : tableName,
	 * automation input * DEVELOPED BY KARTHIK DHANAPAL
	 */

	@And("^user validates data the between azure table \"([^\"]*)\" with automation input \"([^\"]*)\"$")
	public void uservalidates_data_the_between_azure_table(String arg1, String arg2) throws Throwable {
		// Declaring JSON Object as null
		JSONObject json = null;

		// Declare List datatype for azure output from cloud DB
		List<List<String>> gettableData = new ArrayList<>();

		// get service name as input and JSON as input
		String automationInput = ConfigurationManager.getBundle().getString(arg2);

		// Add JSON Array Name
		String jsonArrayName = arg1.replace("[ratingschema].[", "").replace("]_rates", "").replace("]", "");
		// jsonArrayName[0] = jsonArrayName[0].replace(".[", "").replace("]_rates", "");

		// Adding JSON array name to input, since DEV. array is not standardized
		automationInput = "{ " + jsonArrayName + ": " + automationInput + " }";

		// Read the json data as object
		JSONObject reader = new JSONObject(automationInput);

		// Split input JSON Array
		JSONArray values = reader.getJSONArray(jsonArrayName);

		// Declare new array for JSON input
		String[] getJSONObjectVal = new String[values.length()];

		// Declare new array for output from Azure
		String[] getAzureTblVal = new String[values.length()];

		for (int i = 0; i < values.length(); i++) {
			// Get data from the JSON Array
			JSONObject jsonValuefrmArray = values.getJSONObject(i);
			for (String key : jsonValuefrmArray.keySet()) {
				// Storing JSON array in Array
				getJSONObjectVal[i] = getJSONObjectVal[i] + "-" + jsonValuefrmArray.getString(key);

			}
			System.out.println(getJSONObjectVal[i].replace("null-", ""));

		}

		// Connecting to Azure DB and get data
		gettableData = accessResuablefunction.getClouddata(arg1);

		for (int j = 0; j < gettableData.size(); j++) {
			// Storing Azure DB data in Array
			getAzureTblVal[j] = gettableData.get(j).toString().replace(", ", "-").trim();
			System.out.println(getAzureTblVal[j]);

		}

		// Comparing JSON input Vs Azure Output
		for (int l = 0; l < values.length(); l++) {
			String inputJSONVal = getJSONObjectVal[l].replace("null-", "");
			String outputCloudVal = getAzureTblVal[l].toString().replace("[", "").replace("]", "").trim();
			if (inputJSONVal.equals(outputCloudVal)) {
				System.out.println("Passed");
				Assert.assertTrue(
						"JSON input - " + inputJSONVal + "  matched with Azure cloud output - " + outputCloudVal, true);
			} else {
				System.out.println("Failed");
				// System.out.println("input --" + inputJSONVal + " == output--" +
				// outputCloudVal);
				Assert.assertTrue(
						"JSON input - " + inputJSONVal + "  matched with Azure cloud output - " + outputCloudVal,
						false);
			}
		}

		// String testfirstArray = gettableData.get(1);
		System.out.println("End of the script");
	}

	// This function read JSON output Array based on the parent and child JSON
	// Object
	// Input Parameter JSON parent object key; JSON child Array object key - String
	// Output Parameter - public variable parent Object & Coverage detail as Array
	public void readHeader(String jsonObjectKey, String jsonArrayKey) {

		// Read the JSON output and convert to string datatype
		reader = new JSONObject(getResponse().getMessageBody().toString());

		// Read the input JSONObject
		if (jsonObjectKey.equals("")) {
			jsonArrayOutput = reader.getJSONArray(jsonArrayKey);
		} else if (!jsonArrayKey.equals("")) {
			parentObject = reader.getJSONObject(jsonObjectKey);
			jsonArrayOutput = parentObject.getJSONArray(jsonArrayKey);
		} else if (jsonArrayKey.equals("")) {
			parentObject = reader.getJSONObject(jsonObjectKey);
		}

	}

	// Save the output file
//	private void createJSON(JSONObject reader) {
//		File directoryOfProduct = new File(env);
//		String ReaderString;
//		if (directoryOfProduct.exists()) {
//			try (FileWriter file = new FileWriter(outputJsonPath)) {
//				ReaderString = reader.toString();
//				file.write(ReaderString);
//				file.flush();
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		} else {
//			new File(directoryOfProduct.toString()).mkdirs();
//			try (FileWriter file = new FileWriter(outputJsonPath)) {
//				ReaderString = reader.toString();
//				file.flush();
//				Writer out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(outputJsonPath), "UTF-8"));
//				try {
//					out.write(reader.toString()); // Setting
//				} finally {
//					out.close();
//				}
//
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
//	}

//	// Read JSON file output
//	@SuppressWarnings("null")
//	public void readOutputvalue(String obj) {
//
//		JSONObject reader = new JSONObject(obj);
//
//		// Get value for return code and return message from JSON object
//		Object returnCode = reader.get("returnCode");
//		Object returnMessage = reader.get("returnMessage");
//
//		// declaration and instantiation
//		String agentCode[] = new String[2];
//		String submittedPc[] = new String[2];
//		String submittedApe[] = new String[2];
//		String submittedCaseCount[] = new String[2];
//		String planCode[] = new String[2];
//		String basicPlan[] = new String[2];
//		String planVersNum[] = new String[2];
//		String agentSplitPct[] = new String[2];
//
//		// Getting array value from JSON output
//		JSONObject parentObject = reader.getJSONObject("pcCase");
//		JSONArray coveragedetails = parentObject.getJSONArray("pcList");
//
//		// loop array
//		for (int i = 0; i < coveragedetails.length(); i++) {
//			JSONObject jsonObject = coveragedetails.getJSONObject(i);
//			agentCode[i] = jsonObject.getString("agentCode");
//			submittedPc[i] = jsonObject.getString("submittedPc");
//			submittedApe[i] = jsonObject.getString("submittedApe");
//			submittedCaseCount[i] = jsonObject.getString("submittedCaseCount");
//			planCode[i] = jsonObject.getString("planCode");
//			basicPlan[i] = jsonObject.getString("basicPlan");
//			planVersNum[i] = jsonObject.getString("planVersNum");
//			agentSplitPct[i] = jsonObject.getString("agentSplitPct");
//			System.out.println(agentCode[i]);
//		}
//
//	}

//	@Then("^user validate the response from JSON output \"([^\"]*)\" at \"([^\"]*)\" in '(\\d+)' JSON Array object\\(String Datatype\\)$")
//	public void user_validate_the_response_from_JSON_output_at_in_JSON_Array_object_String_Datatype(
//			String expectedOutput, String jsonObjecttag, int arrayIntiation) throws Throwable {
//		createJSONObjArray();
//		JSONObject jsonObject = coveragedetails.getJSONObject(arrayIntiation - 1);
//		String jsonOutput = jsonObject.getString(String.valueOf(jsonObjecttag));
//		if (expectedOutput.equals(jsonOutput)) {
//			System.out.println(expectedOutput + " ==== " + jsonOutput);
//			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
//					+ " Actual output - " + jsonOutput, true);
//		} else {
//			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
//					+ " Actual output - " + jsonOutput, false);
//		}
//	}
//
//	@Then("^user validate the response from JSON output \"([^\"]*)\" at \"([^\"]*)\" in '(\\d+)' JSON Array object\\(Double Datatype\\)$")
//	public void user_validate_the_response_from_JSON_output_at_in_JSON_Array_object_int_Datatype(String expectedOutput,
//			String jsonObjecttag, int arrayIntiation) throws Throwable {
//		createJSONObjArray();
//		JSONObject jsonObject = coveragedetails.getJSONObject(arrayIntiation - 1);
//		String jsonOutput = String.valueOf(jsonObject.getInt(jsonObjecttag));
//
//		if (expectedOutput.equals(jsonOutput)) {
//			System.out.println(expectedOutput + " ==== " + jsonOutput);
//			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
//					+ " Actual output - " + jsonOutput, true);
//		} else {
//			Assert.assertTrue("JSON Output tag " + jsonObjecttag + " Expected output - " + expectedOutput
//					+ " Actual output - " + jsonOutput, false);
//		}
//	}
}
