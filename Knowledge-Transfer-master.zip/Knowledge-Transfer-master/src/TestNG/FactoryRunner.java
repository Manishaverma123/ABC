package TestNG;

import org.testng.annotations.Factory;
import org.testng.annotations.Test;

public class FactoryRunner {


    @Factory
    public Object[] FactoryMethod()
    {
        return new Object[]{new Factory1Test(), new Factory2Test()};
    }
}
