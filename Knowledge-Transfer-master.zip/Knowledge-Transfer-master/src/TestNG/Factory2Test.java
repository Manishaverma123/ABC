package TestNG;

import org.testng.annotations.Test;

public class Factory2Test {

    @Test(enabled=false)
    public void FactoryMethod2()
    {
        System.out.println("Factory Method 2");
    }
}
