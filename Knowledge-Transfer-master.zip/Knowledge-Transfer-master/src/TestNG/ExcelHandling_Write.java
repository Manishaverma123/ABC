package TestNG;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

public class ExcelHandling_Write {

    public static void main(String[] args) throws Exception {

        File src = new File("C:\\Users\\Vikram K Dutta\\Desktop\\Test.xls");
        FileInputStream fis = new FileInputStream(src);
        HSSFWorkbook wb = new HSSFWorkbook(fis);
        HSSFSheet sheet1 = wb.getSheetAt(0);

        int rowcount = sheet1.getLastRowNum() + 1;

        System.out.println("Total number of rows" + rowcount);

        for (int i = 0; i < rowcount; i++) {

            sheet1.getRow(i).createCell(2).setCellValue("Pass");
//            System.out.println("Test Result is" + data0);


        }
        FileOutputStream fout= new FileOutputStream(src);
        wb.write(fout);
        wb.close();

    }
}
