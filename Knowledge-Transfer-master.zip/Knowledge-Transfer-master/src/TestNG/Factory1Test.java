package TestNG;

import org.testng.annotations.Test;

public class Factory1Test {

    @Test
    public void FactoryMethod1()
    {

        System.out.println("Factory Method 1");
    }
}
