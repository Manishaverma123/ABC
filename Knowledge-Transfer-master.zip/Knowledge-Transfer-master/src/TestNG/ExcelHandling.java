package TestNG;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExcelHandling {

    public static void main(String[] args) throws Exception {

        File src = new File("C:\\Users\\Vikram K Dutta\\Desktop\\TestData.xls");
        FileInputStream fis = new FileInputStream(src);
        HSSFWorkbook wb = new HSSFWorkbook(fis);
        HSSFSheet sheet1 = wb.getSheetAt(0);

        int rowcount = sheet1.getLastRowNum() + 1;

        System.out.println("Total number of rows" + rowcount);

        for (int i = 0; i < rowcount; i++) {

            String data0 = sheet1.getRow(i).getCell(1).getStringCellValue();
            System.out.println("Test Data from Excel is" + data0);



        }
        wb.close();

    }

}
