package TestNG;

import org.testng.annotations.*;

public class TestNGBasics {


    //PreConditions Annotations @Before
    @BeforeSuite
    public void setupMethod() {
        System.out.println("Set up the system properties");
    }

    @BeforeTest
    public void launchBrowser() {
        System.out.println("Launch chrome Browser");
    }

    @BeforeClass
    public void login() {
        System.out.println("Login method");
    }

    @BeforeMethod
    public void enterURL() {
        System.out.println("Enter url");
    }


    //TestCases
    @Test
    public void googleTitleTest() {
        System.out.println("Google Title Test");
    }

    @Test
    public void SearchText() {
        System.out.println("Search Text");
    }

    //Post Conditions Annotations
    @AfterMethod
    public void logOut() {
        System.out.println("LogOut from test");
    }

    @AfterTest
    public void deleteCookies() {
        System.out.println("Delete all cookies");
    }

    @AfterClass
    public void closeAllBrowser() {
        System.out.println("close all browser");
    }

    @AfterSuite
    public void generateReport() {
        System.out.println("Generate Test NG report");
    }


}
