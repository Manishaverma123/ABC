package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class ParameterTest {

    WebDriver driver;

    @Test(priority=1)
    @Parameters({"url","emailId"})
    public void yahooLoginTest(String url, String emailId) throws Exception{

        System.setProperty("webdriver.chrome.driver","C:\\Users\\Vikram K Dutta\\Desktop\\JavaSeleniumTraining\\src\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get(url);
        driver.findElement(By.xpath("//*[@id=\"login-username\"]")).clear();
        driver.findElement(By.xpath("//*[@id=\"login-username\"]")).sendKeys(emailId);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"login-signin\"]")).click();
        Thread.sleep(4000);
        driver.close();

    }

    @Test(priority=2)
    @Parameters({"url","emailId"})
    public void yahooLoginTest1(String url, String emailId) throws Exception{

        System.setProperty("webdriver.chrome.driver","C:\\Users\\Vikram K Dutta\\Desktop\\JavaSeleniumTraining\\src\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get(url);
        driver.findElement(By.xpath("//*[@id=\"login-username\"]")).clear();
        driver.findElement(By.xpath("//*[@id=\"login-username\"]")).sendKeys(emailId);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@id=\"login-signin\"]")).click();
        Thread.sleep(4000);
        driver.close();

    }


}
