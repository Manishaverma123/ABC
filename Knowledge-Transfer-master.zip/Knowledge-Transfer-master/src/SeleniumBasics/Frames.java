package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Frames {

    public static void main(String [] args) throws Exception
    {

//        IFrame is a web page which is embedded in another web page or an HTML document embedded inside another HTML document.
//        The IFrame is often used to insert content from another source, such as an advertisement, into a Web page.

            System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver=new ChromeDriver();//navigates to the Browser

        // Maximize browser
        driver.manage().window().maximize();

        // Open browser
        driver.get("http://demo.automationtesting.in/Frames.html");

//        WebElement frameobj= driver.findElement(By.xpath("/html/body/section/div/div/div/input"));
//        frameobj.sendKeys("Selenium");

        driver.switchTo().frame("SingleFrame");
        WebElement frameobj1= driver.findElement(By.xpath("/html/body/section/div/div/div/input"));
        frameobj1.sendKeys("Selenium");

        driver.switchTo().defaultContent();

        Thread.sleep(4000);


    }








}
