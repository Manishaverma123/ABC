package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;

public class RadioButton {

    public static void main(String [] args) throws Exception {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();//navigates to the Browser

        // Maximize browser
        driver.manage().window().maximize();

        // Open browser
        driver.get("http://demo.automationtesting.in/Register.html");


        Thread.sleep(4000);

//        WebElement checkbox1= driver.findElement(By.xpath("//input[@id=\"checkbox1\"]"));
//        checkbox1.click();

        List<WebElement> radiobutton = driver.findElements(By.xpath("//input[contains(@id,'checkbox')]"));

        int size= radiobutton.size();

        for(int i=0;i<size;i++)
        {
            radiobutton.get(i).click();
        }
        driver.close();

    }


}
