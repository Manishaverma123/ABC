package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class ExplicitWait {

    public static void main (String [] args)
    {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
        driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
//        driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
        driver.get("http://demo.automationtesting.in/Register.html");

        WebDriverWait wait=new WebDriverWait(driver, 20);

        WebElement button=  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"imagesrc\"]")));

        button.click();

        driver.close();

    }



}
