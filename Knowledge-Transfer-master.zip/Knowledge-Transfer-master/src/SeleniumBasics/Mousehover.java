package SeleniumBasics;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class Mousehover {

    public static void main(String [] args) throws Exception
    {

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver=new ChromeDriver();//navigates to the Browser

        // Maximize browser
        driver.manage().window().maximize();

        // Open browser
        driver.get("http://demo.automationtesting.in/Register.html");


            Thread.sleep(4000);

        WebElement mousehoverobj= driver.findElement(By.xpath("//*[@id=\"header\"]/nav/div/div[2]/ul/li[4]/a"));

        Actions action= new Actions(driver);
        action.moveToElement(mousehoverobj).perform();

        Thread.sleep(4000);

        driver.findElement(By.xpath("//*[@id=\"header\"]/nav/div/div[2]/ul/li[4]/ul/li[3]/a")).click();

            Thread.sleep(4000);

    }

}
