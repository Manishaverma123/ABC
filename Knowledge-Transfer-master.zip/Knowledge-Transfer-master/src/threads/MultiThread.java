package threads;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultiThread extends Thread{

    @Override
    public void run() {


        System.out.println("thread 1 is running...");

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver=new ChromeDriver();//navigates to the Browser

        // Maximize browser
        driver.manage().window().maximize();

        // Open browser
        driver.get("http://demo.automationtesting.in/Register.html");

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    public static void main(String[] args)
    {

        MultiThread t= new MultiThread();
        t.start();
        MultiThread1 t1= new MultiThread1();
        t1.start();
        MultiThread2 t2= new MultiThread2();
        t2.start();


//        MultiThread t= new MultiThread();
//        t.run();
//        MultiThread1 t1= new MultiThread1();
//        t1.run();
//        MultiThread2 t2= new MultiThread2();
//        t2.run();

    }
}
