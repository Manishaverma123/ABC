package threads;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class MultiThread2 extends Thread{

    @Override
    public void run() {
        System.out.println("thread 3 is running...");

        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Vikram K Dutta\\Desktop\\Training\\chromedriver.exe");

        WebDriver driver=new ChromeDriver();//navigates to the Browser

        // Maximize browser
        driver.manage().window().maximize();

        // Open browser
        driver.get("http://demo.automationtesting.in/Register.html");

        try {
            Thread.sleep(4000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
