package com.quantum.listeners;
import com.manulife.ap.steps.common.*;

import java.io.File;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.IAlterSuiteListener;
import org.testng.ISuite;
import org.testng.ISuiteListener;
import org.testng.xml.XmlSuite;

public class TestNGListener implements ISuiteListener,IAlterSuiteListener {
     

	
	
    @Override
    public void alter(List<XmlSuite> suites) {
    	
    	try {
			Iopticore();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	   	
    	csvFileReader csv= new csvFileReader();
    	    	List<String> arr =csv.returnTestCase(); 
    	    	csv.DeleteFile();	
    	//Data Read
        for(XmlSuite suite:suites) {
        	
			for(int i =0;i<arr.size();i++){
				String name = "@"+(arr.get(i));
            suite.addIncludedGroup(name);
			}
        }
    }
    
    public void readDataFromNotepad(){
    	
    }

	@Override
	public void onStart(ISuite suite) {
		// TODO Auto-generated method stub
		//runVbs();
	}

	@Override
	public void onFinish(ISuite suite) {
		// TODO Auto-generated method stub
		
	}
	
	public void Iopticore() throws InterruptedException{	
//		<parameter name="chrome.additional.capabilities" value="{'chromeOptions':{'useAutomationExtension':false}}"/>
		String path = System.getProperty("user.dir");	
		String downloadFilepath = path+"/src/main/resources/RBT_OUTPUT/";
		System.out.println(downloadFilepath);
		HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
		chromePrefs.put("profile.default_content_settings.popups", 0);
		chromePrefs.put("download.default_directory", downloadFilepath);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("useAutomationExtension", false);
			options.setExperimentalOption("prefs", chromePrefs);
			
			
			File fileObject1 = new File(downloadFilepath);
			boolean fileCanRead1 = fileObject1.canRead();
			boolean fileCanWrite1 = fileObject1.canWrite();
			boolean fileCanExecute1 = fileObject1.canExecute();
			
			fileObject1.setReadable(true);
			fileObject1.setWritable(true);
			fileObject1.setExecutable(true);
			
			
			File fileObject = new File(path + "/src/main/resources/chromedriver_mac64/chromedriver");
			
			boolean fileCanRead = fileObject.canRead();
			boolean fileCanWrite = fileObject.canWrite();
			boolean fileCanExecute = fileObject.canExecute();
			
			fileObject.setReadable(true);
			fileObject.setWritable(true);
			fileObject.setExecutable(true);
			
			

			
			System.setProperty("webdriver.chrome.driver", path + "/src/main/resources/chromedriver_mac64/chromedriver");			
				WebDriver driver = new ChromeDriver(options);
				
				
				driver.get("https://iopticoremlhk.cognizant.com/");
				System.out.println("Open Browser");
				driver.findElement(By.xpath("//*[@id='MainContent_Login1_UserName']")).sendKeys("407354");
				driver.findElement(By.xpath("//*[@id='MainContent_Login1_Password']")).sendKeys("Feb@2019");
				driver.findElement(By.xpath("//*[@id='MainContent_Login1_LoginButton']")).click();				
				Thread.sleep(30);
				driver.findElement(By.xpath("//*[@id='ctl01']/div[3]/div/div[2]/ul[1]/li[5]/a")).click();				
				Thread.sleep(10);
				driver.findElement(By.xpath("//*[@id='MainContent_combo_BU_Modules']")).sendKeys("MOVE_Regional_POC");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='MainContent_UpdatePanel1']/div[1]/div/div[2]/label")).click();
				driver.findElement(By.xpath("//*[@id='MainContent_combo_LOB_Modules']")).sendKeys("MOVE_Regional_LOB");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='MainContent_UpdatePanel1']/div[1]/div/div[2]/label")).click();
				driver.findElement(By.xpath("//*[@id='MainContent_combo_Application_Modules']")).sendKeys("MOVE_5_Regional_POC");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='MainContent_UpdatePanel1']/div[1]/div/div[2]/label")).click();
				Select moduleDropDown=new Select(driver.findElement(By.xpath("//*[@id='MainContent_listBox_Module']")));
				moduleDropDown.selectByIndex(1);
				moduleDropDown.selectByIndex(3);
				moduleDropDown.selectByIndex(5);
				moduleDropDown.selectByIndex(7);
				moduleDropDown.selectByIndex(9);
				moduleDropDown.selectByIndex(12);
				moduleDropDown.selectByIndex(16);			
				
				driver.findElement(By.xpath("//*[@id='MainContent_btn_Submit']")).click();
				Thread.sleep(2000);
				Alert alt = driver.switchTo().alert();
			    alt.accept();
			    driver.findElement(By.xpath("//*[@id='ctl01']/div[3]/div/div[2]/ul[1]/li[4]/a")).click();
			    Thread.sleep(2000);
			    driver.findElement(By.xpath("//*[@id='MainContent_combo_BU_Modules']")).sendKeys("MOVE_Regional_POC");			    
			    Thread.sleep(2000);				
				driver.findElement(By.xpath("//*[@id='MainContent_combo_LOB_Modules']")).sendKeys("MOVE_Regional_LOB");
				Thread.sleep(2000);				
				driver.findElement(By.xpath("//*[@id='MainContent_combo_Application_Modules']")).sendKeys("MOVE_5_Regional_POC");
				Thread.sleep(2000);
				WebElement element = driver.findElement(By.xpath("//*[@id='MainContent_btn_Trigger']"));
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("arguments[0].scrollIntoView(true);",element );
				Thread.sleep(2000);
				driver.findElement(By.xpath("//*[@id='MainContent_btn_Trigger']")).click();
				
				WebDriverWait wait = new WebDriverWait(driver, 20000);
				wait.until(ExpectedConditions.alertIsPresent());
				driver.switchTo().alert().accept();
				Thread.sleep(2000);				
				element = driver.findElement(By.xpath("//*[@id='MainContent_btn_Dnld']"));				
				js.executeScript("arguments[0].scrollIntoView(true);",element );
				Thread.sleep(2000);
				//System.out.println("Before Download click");
				driver.findElement(By.xpath("//*[@id='MainContent_btn_Dnld']")).click();
				//System.out.println("After Download click");
				Thread.sleep(10000);
				System.out.println("driver quits");
				driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
				driver.quit();
				
			  
				
				
				
				
		
		
	}
	
    
}