package com.quantum.listeners;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.core.TestBaseProvider;
import com.quantum.listeners.QuantumReportiumListener;

/**
 * Required Parameters - Global Switch Key - Enable/ disable Create new Jira
 * tasks for failures Switch Key - Enable/Disable Jira Host URL - Eg:
 * https://kulin.atlassian.net Project Key - Eg: TEST Jira Authentication
 * Username & Password XRay Plugin - Client ID & Client Secret Test Execution
 * Key - Eg: TEST-1 Test Key - Eg: Test-4 (This will be configured in the
 * cucumber scenario tags.)
 * 
 * @author kulin sitwala
 *
 */
public class JiraListener implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		String globalJiraSwitchKey = ConfigurationManager.getBundle().getString("globalJiraSwitchKey");
		String projectKey = ConfigurationManager.getBundle().getString("projectKey");
		String xrayClientID = ConfigurationManager.getBundle().getString("xrayClientID");
		String xrayClientSecret = ConfigurationManager.getBundle().getString("xrayClientSecret");
		String xrayHost = ConfigurationManager.getBundle().getString("xrayHost");
		String testExecutionKey = ConfigurationManager.getBundle().getString("testExecutionKey");
		
		String scenarioName = result.getMethod().getMethodName();
		String reportURL = QuantumReportiumListener.getReportClient().getReportUrl();
		
		
		String createNewJiraTasks = ConfigurationManager.getBundle().getString("createNewJiraTasks");
		String jiraHostURL = ConfigurationManager.getBundle().getString("jiraHostURL");
		String jiraUser = ConfigurationManager.getBundle().getString("jiraUser");
		String jiraPassword = ConfigurationManager.getBundle().getString("jiraPassword");

		
		
		String testKey = "";
		String[] tags = result.getMethod().getGroups();
		for(String tag : tags) {
			if(tag.contains(projectKey + "-") ) {
				testKey = tag.replace("@", "");
			}
		}
		System.out.println("Test Key is - " + testKey);
		
		if (globalJiraSwitchKey.equalsIgnoreCase("true") && !testKey.isEmpty()) {
//			String xRayAuthToken = getXRAYAuthorization(xrayHost, xrayClientID, xrayClientSecret);
			postXRayExDetails(jiraHostURL, jiraUser, jiraPassword,testExecutionKey, true, testKey, null, null);
		}
	}

	@Override
	public void onTestFailure(ITestResult result) {
		String scenarioName = result.getMethod().getMethodName();
		String reportURL = QuantumReportiumListener.getReportClient().getReportUrl();
		
		
		String globalJiraSwitchKey = ConfigurationManager.getBundle().getString("globalJiraSwitchKey");
		String createNewJiraTasks = ConfigurationManager.getBundle().getString("createNewJiraTasks");
		String jiraHostURL = ConfigurationManager.getBundle().getString("jiraHostURL");
		String projectKey = ConfigurationManager.getBundle().getString("projectKey");
		String jiraUser = ConfigurationManager.getBundle().getString("jiraUser");
		String jiraPassword = ConfigurationManager.getBundle().getString("jiraPassword");
		String xrayClientID = ConfigurationManager.getBundle().getString("xrayClientID");
		String xrayClientSecret = ConfigurationManager.getBundle().getString("xrayClientSecret");
		String xrayHost = ConfigurationManager.getBundle().getString("xrayHost");
		String testExecutionKey = ConfigurationManager.getBundle().getString("testExecutionKey");
		
		
		String testKey = "";
		String[] tags = result.getMethod().getGroups();
		for(String tag : tags) {
			if(tag.contains(projectKey + "-") ) {
				testKey = tag.replace("@", "");
			}
		}
		System.out.println("Test Key is - " + testKey);
		
		if (globalJiraSwitchKey.equalsIgnoreCase("true") && !testKey.isEmpty()) {
			String xRayAuthToken = getXRAYAuthorization(xrayHost, xrayClientID, xrayClientSecret);
			
			byte[] fileContent;
			String encodedStringEvidence = "";
			try {
				fileContent = FileUtils.readFileToByteArray(new File(TestBaseProvider.instance().get().getLastCapturedScreenShot()));
				encodedStringEvidence = java.util.Base64.getEncoder().encodeToString(fileContent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			postXRayExDetails(jiraHostURL, jiraUser,jiraPassword, testExecutionKey, false, testKey, encodedStringEvidence , "failureScreen" + scenarioName);
			if (createNewJiraTasks.equalsIgnoreCase("true")) {
				
				String failureException = "";
				if (result.getThrowable() == null) {
					failureException = "No exception stacktrace";
				} else {
					failureException = ExceptionUtils.getStackTrace(result.getThrowable());
				}

				String taskDesc = "Please check the failed test case - " + scenarioName + " in the ReportURl - "
						+ reportURL + "\n This test case failed with exception - " + failureException;

				createJiraTask(jiraHostURL, jiraUser, jiraPassword, projectKey, taskDesc,testKey);
			}
		}
	}

	@Override
	public void onTestSkipped(ITestResult result) {

	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {

	}

	@Override
	public void onStart(ITestContext context) {

	}

	@Override
	public void onFinish(ITestContext context) {

	}

	private static final int TIMEOUT_MILLIS = 60000;

	public static String makeAPICall(String hostURL, String endPoint, Map<String, String> headers, String body,
			String basicAuthUser, String basicAuthPass) {
		URIBuilder taskUriBuilder;
		try {
			taskUriBuilder = new URIBuilder(hostURL + endPoint);
			
			CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
			if (basicAuthUser != null) {
				System.out.println("Adding tthe authentication");
				UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(basicAuthUser, basicAuthPass);
				credentialsProvider.setCredentials(AuthScope.ANY, credentials);
			}
			System.out.println("BODY before setting the entity is - " + body);
			StringEntity requestEntity = new StringEntity(body, ContentType.APPLICATION_JSON);

			HttpPost httpPost = new HttpPost(taskUriBuilder.build());
			addRequestHeaders(httpPost, headers);
			httpPost.setEntity(requestEntity);

			HttpResponse response = null;
			HttpClient httpClient = HttpClientBuilder.create()
					.setRetryHandler(new DefaultHttpRequestRetryHandler(3, true))
					.setDefaultRequestConfig(RequestConfig.custom().setSocketTimeout(TIMEOUT_MILLIS)
							.setConnectTimeout(TIMEOUT_MILLIS).setConnectionRequestTimeout(TIMEOUT_MILLIS).build())
					.setDefaultCredentialsProvider(credentialsProvider).build();
			response = httpClient.execute(httpPost);
			HttpEntity entity = response.getEntity();
			String responseString = EntityUtils.toString(entity, "UTF-8");
			System.out.println("Response of URL - " + hostURL + endPoint + " is response - " + responseString);
			return responseString;
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;

	}

	public static void addRequestHeaders(HttpRequestBase request, Map<String, String> headers) {
		for (String key : headers.keySet()) {
			request.addHeader(key, headers.get(key));
		}
	}

	@SuppressWarnings("unused")
	private static String convertStreamToString(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	@SuppressWarnings("unused")
	public static void main(String[] args) {
		// Global Switch Key - Enable/ disable
		// * Create new Jira tasks for failures Switch Key - Enable/Disable
		// * Jira Host URL - Eg: https://kulin.atlassian.net
		// * Project Key - Eg: TEST
		// * Jira Authentication Token or Username & Password
		// * XRay Plugin - Client ID & Client Secret
		// * Test Execution Key - Eg: TEST-1
		// * Test Key - Eg: Test-4 (This will be configured in the cucumber scenario
		// tags.)
		String globalSwitchKey = "true";
		String createNewJiraTasks = "true";
		String jiraHostURL = "https://jira.ap.manulife.com";
		String projectKey = "MOV";
		String jiraUser = "santu_halder@MFCGD.COM";
		String jiraPassword = "Hongkong@2010";
//		String xrayClientID = "1308216C4B6E4A86BE6C737469F78B14";
//		String xrayClientSecret = "32a268617006606868dc5187ccdd8157f011df3e289321b69d31b3221e574312";
//		String xrayHost = "https://xray.cloud.xpand-it.com";
		String testExecutionKey = "MOV-20119";
		String testKey = "MOV-12948";
		if (globalSwitchKey.equalsIgnoreCase("true")) {
			// String xRayAuthToken = getXRAYAuthorization(xrayHost, xrayClientID,
			// xrayClientSecret);
			// postXRayExDetails(xrayHost, xRayAuthToken);
			
			postXRayExDetails(jiraHostURL, jiraUser, jiraPassword,testExecutionKey, true, testKey, null, null);
			if (createNewJiraTasks.equalsIgnoreCase("true")) {
				String scenarioName = "Sample Scenario Name";
				String reportURL = "https:www.google.com";
				String failureException = "Exception StackTracew";
				String taskDesc = "Please check the failed test case - " + scenarioName + " in the ReportURl - "
						+ reportURL + "\n This ttest case failed with exception - " + failureException;

				createJiraTask(jiraHostURL, jiraUser, jiraPassword, projectKey, taskDesc,testKey);
			}
		}

	}

	private static String getXRAYAuthorization(String xrayHost, String xrayClientID, String xrayClientSecret) {
		Map<String, String> xrayHeader = new HashMap<String, String>();
		xrayHeader.put("Content-Type", "application/json");

		String xrayAuthBody = "{ \"client_id\": \"$clientID\",\"client_secret\": \"$clientSecret\" }"
				.replace("$clientID", xrayClientID).replace("$clientSecret", xrayClientSecret);
		// System.out.println(xrayAuthBody);
		String appListResponse = makeAPICall(xrayHost, "/api/v1/authenticate", xrayHeader, xrayAuthBody, null, null);

		System.out.println(appListResponse);

		String xRayAuthToken = appListResponse.replace("\"", "");
		System.out.println(xRayAuthToken);
		return xRayAuthToken;
	}

	@SuppressWarnings("unchecked")
	private static String postXRayExDetails(String jiraHostURL, String jiraUser, String jiraPassword, String testExecutionKey, boolean passFailStatus, String testKey, String evidence, String fileName) {
		String updateTestRunResp = "";
		Map<String, String> xrayHeaderBearer = new HashMap<String, String>();
		xrayHeaderBearer.put("Content-Type", "application/json");
		//xrayHeaderBearer.put("Authorization", "Bearer " + xRayAuthToken);
		String auth = jiraUser + ":" + jiraPassword;
		byte[] encodedAuth = Base64.encodeBase64(
		  auth.getBytes(StandardCharsets.ISO_8859_1));
		String authHeader = "Basic " + new String(encodedAuth);
		xrayHeaderBearer.put(HttpHeaders.AUTHORIZATION, authHeader);
		JSONParser parser = new JSONParser();

		Object obj, passObj, failObj;
		try {
			obj = parser.parse(new FileReader("src/main/resources/Jira/xrayTestExUpdate.wsc"));
			JSONObject jsonObject = (JSONObject) obj;
			
			if(passFailStatus) {
				passObj = parser.parse(new FileReader("src/main/resources/Jira/xrayTestPass.wsc"));
				JSONObject passJsonObject = (JSONObject) passObj;
				passJsonObject.put("testKey", testKey);
				((JSONArray)jsonObject.get("tests")).add(passJsonObject);
			} else  { 
				failObj = parser.parse(new FileReader("src/main/resources/Jira/xrayTestFail.wsc"));
				JSONObject failJsonObject = (JSONObject) failObj;
				failJsonObject.put("testKey", testKey);
				JSONObject evidenceObj = ((JSONObject)((JSONArray)failJsonObject.get("evidences")).get(0));
				evidenceObj.put("data", evidence);
				evidenceObj.put("filename", fileName);
				((JSONArray)jsonObject.get("tests")).add(failJsonObject);
			}
			jsonObject.put("testExecutionKey", testExecutionKey);
			// Code to add body as JSON object
			
			System.out.println("JSON BODY - " + jsonObject.toString());
			if(passFailStatus){
			updateTestRunResp = makeAPICall(jiraHostURL, "/rest/raven/1.0/import/execution", xrayHeaderBearer,
					jsonObject.toString(), jiraUser, jiraPassword); // user name and password
			}
			System.out.println("Finished with updating the execution status");
			System.out.println(updateTestRunResp);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return updateTestRunResp;
	}

	@SuppressWarnings("unchecked")
	private static String createJiraTask(String jiraHostURL, String basicAuthUser, String basicAuthPass, String projectKey,
			String taskDesc, String testKey) {
		String jiraTaskCreateResp = "";
		Map<String, String> jiraHeader = new HashMap<String, String>();
		jiraHeader.put("Content-Type", "application/json");

		String auth = basicAuthUser + ":" + basicAuthPass;
		byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
		String authHeader = "Basic " + new String(encodedAuth);
		jiraHeader.put(HttpHeaders.AUTHORIZATION, authHeader);

		// System.out.println(xrayAuthBody);

		JSONParser parser = new JSONParser();

		Object obj;
		try {
			obj = parser.parse(new FileReader("src/main/resources/Jira/jiraNewTask.wsc"));
			JSONObject jsonObject = (JSONObject) obj;
			JSONObject fieldsObj = ((JSONObject) jsonObject.get("fields"));
			((JSONObject)fieldsObj.get("project")).put("key", projectKey);
			fieldsObj.put("summary","Automation  Failure Task - " +  testKey);
			fieldsObj.put("description", taskDesc);
			//JSONObject nameObj = ((JSONObject) jsonObject.get("name"));
			//nameObj.put("name", "-1");
			// Code to add body as JSON object

			System.out.println("JSON BODY - " + jsonObject.toString());
			jiraTaskCreateResp = makeAPICall(jiraHostURL, "/rest/api/2/issue/", jiraHeader, jsonObject.toString(), null,
					null);
			System.out.println("Finished with updating the execution status");
			System.out.println(jiraTaskCreateResp);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return jiraTaskCreateResp;
	}
}
