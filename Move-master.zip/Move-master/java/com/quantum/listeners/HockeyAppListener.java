package com.quantum.listeners;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URISyntaxException;
import java.net.URL;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.utils.URIBuilder;
import org.apache.http.impl.client.DefaultHttpRequestRetryHandler;
import org.apache.http.impl.client.HttpClientBuilder;
import org.json.JSONArray;
import org.testng.ISuite;
import org.testng.ISuiteListener;

import com.jayway.jsonpath.JsonPath;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.quantum.utils.CloudUtils;

public class HockeyAppListener implements ISuiteListener {

	private static String convertStreamToString(InputStream is) {

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try {
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return sb.toString();
	}

	private static final int TIMEOUT_MILLIS = 60000;

	public static String makeAPICall(String url, String hockeyAppToken) {
		URIBuilder taskUriBuilder;
		try {
			taskUriBuilder = new URIBuilder(url);

			HttpGet httpGet = new HttpGet(taskUriBuilder.build());
			addDefaultRequestHeaders(httpGet, hockeyAppToken);
			HttpResponse response = null;
			HttpClient httpClient = HttpClientBuilder.create()
					.setRetryHandler(new DefaultHttpRequestRetryHandler(3, true))
					.setDefaultRequestConfig(RequestConfig.custom().setSocketTimeout(TIMEOUT_MILLIS)
							.setConnectTimeout(TIMEOUT_MILLIS).setConnectionRequestTimeout(TIMEOUT_MILLIS).build())
					.build();
			response = httpClient.execute(httpGet);
			System.out.println("Response of URL - " + url + " is response - " + response);
			InputStream instream = response.getEntity().getContent();
			return convertStreamToString(instream);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;

	}

	private static void addDefaultRequestHeaders(HttpRequestBase request, String accessToken) {
		request.addHeader("X-HockeyAppToken", accessToken);
	}

	@Override
	public void onStart(ISuite suite) {
		// Code to upload the hockey app to the Perfecto Cloud Repo
		// Properties to be configured in the testNG parameters

		if (suite.getParameter("downloadLatestHockeyApp").equalsIgnoreCase("true")) {

			// hockeyApp.name - Name of the Hockey App exactly as displayed in the
			// driver.capabilities.user or perfecto.capabilities.user - The user of the
			// perfecto cloud
			// driver.capabilities.password or perfecto.capabilities.password - The password
			// of the perfecto cloud
			// app.upload.cloud.path - The path in the perfecto cloud repository where the
			// hockey app needs to be uploaded. Example - PUBLIC:Kulin/HockeyAppTest.ipa
			// The same path (app.upload.cloud.path) needs to be configured in the app
			// capability of the driver
			String hockeyAppName = suite.getParameter("hockeyApp.name");
			String username = suite.getParameter("driver.capabilities.user") != null
					? suite.getParameter("driver.capabilities.user")
					: suite.getParameter("perfecto.capabilities.user");
			String password = suite.getParameter("driver.capabilities.password") != null
					? suite.getParameter("driver.capabilities.password")
					: suite.getParameter("perfecto.capabilities.password");
			String appUploadPath = suite.getParameter("app.upload.cloud.path");
			String remoteServerURL = ConfigurationManager.getBundle().getString("remote.server") != null
					? ConfigurationManager.getBundle().getString("remote.server")
					: suite.getParameter("remote.server");
			String cloudName = remoteServerURL.substring(8, remoteServerURL.indexOf("/nexperience"));
			String hockeyAppToken = suite.getParameter("hockeyAppToken");

			System.out.println("Username" + username);
			System.out.println("HockeyApp Name" + hockeyAppName);

			if (hockeyAppName == null || hockeyAppName.isEmpty()) {
				System.out.println(
						"Please make sure that the hockey App name to be used is configured in property - hockeyApp.name");
			}
			if (username == null || username.isEmpty()) {
				System.out.println(
						"Please make sure that the cloud User name is configured in property - driver.capabilities.user or perfecto.capabilities.user");
			}
			if (password == null || password.isEmpty()) {
				System.out.println(
						"Please make sure that the cloud password is configured in property - driver.capabilities.password or perfecto.capabilities.password");
			}
			if (appUploadPath == null || appUploadPath.isEmpty()) {
				System.out.println(
						"Please make sure that cloud repo path where the app needs to be uploaded is configured in property - app.upload.cloud.path");
			}
			if (hockeyAppToken == null || hockeyAppToken.isEmpty()) {
				System.out.println("Please make sure that hockey App Token is configured in property - hockeyAppToken");
			}

			// Code to find the App Identifier for the given App name from Hockey App
			String appIdentifier = "";
			String appListResponse = makeAPICall("https://rink.hockeyapp.net/api/2/apps/", hockeyAppToken);

			JSONArray appsArray = new JSONArray(String.valueOf((Object) JsonPath.read(appListResponse, "$..apps")));
			int numberOfApps = appsArray.getJSONArray(0).length();

			for (int i = 0; i < numberOfApps; i++) {
				String appTitle = String.valueOf((Object) JsonPath.read(appListResponse, "$.apps[" + i + "].title"));
				if (appTitle.equalsIgnoreCase(hockeyAppName)) {
					System.out.println("App name found, getting the public identifier!");
					appIdentifier = String
							.valueOf((Object) JsonPath.read(appListResponse, "$.apps[" + i + "].public_identifier"));
					System.out.println("App's identifier is - " + appIdentifier);
					break;
				}
			}

			// Code to get the latest App version download page URL
			String latestAppId = "";
			String appVersionListResponse = makeAPICall(
					"https://rink.hockeyapp.net/api/2/apps/" + appIdentifier + "/app_versions", hockeyAppToken);
			latestAppId = String.valueOf((Object) JsonPath.read(appVersionListResponse, "$.app_versions[0].id"));
			String downloadPageURL = "https://rink.hockeyapp.net/api/2/apps/" + appIdentifier + "/app_versions/"
					+ latestAppId;
			String latestAppDownloadURL = "";
			try {

				String appDownloadPageResponse = makeAPICall(downloadPageURL, hockeyAppToken);
				latestAppDownloadURL = appDownloadPageResponse.split("<key>url</key>")[1].split("</string>")[0]
						.replace("<string>", "").trim();
				System.out.println("Uploading the app file from this URL to perfecto cloud -" + latestAppDownloadURL);
				CloudUtils.uploadMedia(cloudName, username, password, new URL(
						"https://rink.hockeyapp.net/api/2/apps/" + appIdentifier + "/app_versions/" + latestAppId),
						appUploadPath);
			} catch (Exception e) {
				try {
					String command = "curl -X GET -H 'X-HockeyAppToken: " + hockeyAppToken + "' " + downloadPageURL;
					Process process = Runtime.getRuntime().exec(command);
					latestAppDownloadURL = convertStreamToString(process.getInputStream()).split("href=\"")[1]
							.split("\"")[0];
					System.out.println(latestAppDownloadURL);
					CloudUtils.uploadMedia(cloudName, username, password, new URL(latestAppDownloadURL), appUploadPath);
				} catch (Exception exception) {
					exception.printStackTrace();
				}
			}
		}
	}
	

	@Override
	public void onFinish(ISuite suite) {
	}

}
