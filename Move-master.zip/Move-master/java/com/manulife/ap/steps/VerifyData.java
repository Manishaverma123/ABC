package com.manulife.ap.steps;

import static com.qmetry.qaf.automation.step.CommonStep.getText;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.time.DateUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.simple.parser.JSONParser;

import com.google.gson.Gson;
import com.manulife.ap.steps.common.GetDataFromDB;
import com.manulife.ap.steps.common.HealthDay;
import com.manulife.ap.steps.common.HealthTracker;
import com.manulife.ap.steps.common.MUser;
import com.manulife.ap.steps.common.ManulifeMember;
import com.manulife.ap.steps.common.Participation;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.rest.RestRequestBean;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.WsStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.quantum.utils.DriverUtils;


import gherkin.deps.com.google.gson.reflect.TypeToken;

public class VerifyData {
		
	public List<Participation> getParticipationUsingWebAPI(String strUserID) {
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		String myResponse ="" ; 
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "dev");			
			System.out.println("DEV env");
		}
		
		ConfigurationManager.getBundle().addProperty("USER_ID", strUserID);				
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.Participation");
		bean.resolveParameters(null);
		WsStep.request(bean);
		
		//get response and parser to Participation class
		myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		System.out.println("my response:" + myResponse);
		Gson gson = new Gson();
		List<Participation> participations = gson.fromJson(myResponse, new TypeToken<List<Participation>>(){}.getType());	
		return participations ;
	}
	
	@QAFTestStep(description="I patching data for {0} with {1} steps for today")	
    public void IPatchingDataForToday(String email, String steps){
		String strUserId="";
		String strTrackerName="";
		String strTrackerId="";
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
		
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
			com.quantum.steps.PerfectoApplicationSteps.waitFor(15);
			
			bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetHealthTracker");
			bean.resolveParameters(null);
			WsStep.request(bean);
			myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			List<HealthTracker> healthtrackers = gson.fromJson(myResponse, new TypeToken<List<HealthTracker>>(){}.getType());
			for(int i=0; i< healthtrackers.size();i++) {
				if("active".equals(healthtrackers.get(i).status)) {
					strTrackerName = healthtrackers.get(i).data.deviceName ;
					strTrackerId = healthtrackers.get(i).identifier ;
					break;
				}
			}
			
			ConfigurationManager.getBundle().addProperty("DEVICE_ID", strTrackerId);
			ConfigurationManager.getBundle().addProperty("DEVICE_TYPE", strTrackerName);
			ConfigurationManager.getBundle().addProperty("STEPS", steps);
			ConfigurationManager.getBundle().addProperty("SLEEP", "420");
			ConfigurationManager.getBundle().addProperty("WEIGHT", "65");
			ConfigurationManager.getBundle().addProperty("CALORIES", "1234");
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
			Date dToday =new Date();
			String dateFormatted= sdf.format(dToday);
			
			ConfigurationManager.getBundle().addProperty("TODAY", dateFormatted);
			
			bean = new RestRequestBean();
			bean.fillData("post.Move5.HealthDataHK");
			bean.resolveParameters(null);
			WsStep.request(bean);
		}
		else {
			//leave blank for waiting DB access.
		}
	}
	
	@QAFTestStep(description="I verify Tracking Period is 182 days for non-eligible user")	
    public void IVerifyTrackingPeriodForNonEligibleUsers(){
	
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		String strUserID ;
		
		List<Participation> participations = null; 
		
		Date dStartDate = null;
		Date dEndDate = null ;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			strUserID = "5b445e6fd8fa1d0040d4e3fa" ;
		}
		else {			
			strUserID = "ABCDEFGHIJKLMN" ;
		}
		
		//We are using Web API ?
		if("false".compareToIgnoreCase(strUsingDB) == 0) {					
			participations = getParticipationUsingWebAPI(strUserID);
			
			try {
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10)) ;
				dEndDate = sdf.parse(participations.get(0).getEndDate().substring(0, 10)) ;
				
			} catch (Exception e) {
				System.err.println("Parse string to Date exception");
			}
		}
		else {
			//Leave it blank for waiting accessable to Database
			//dStartDate = get from database
			//dEndDate = get from database
		}
		
		//And we calculate the Period Tracking
		
		Calendar calendar1 = Calendar.getInstance();
		Calendar calendar2 = Calendar.getInstance();
		calendar1.setTime(dStartDate);
		calendar2.setTime(dEndDate);
		
		//int diffInDays = (int)( (dEndDate.getTime() - dStartDate.getTime())/ (1000 * 60 * 60 * 24) ) ;
		int diffInDays = dateDiff(calendar1, calendar2);
		
		if(diffInDays != 182) {
			System.err.println("Tracking Period is not 182 days.");
			assert(false);
		}
		
		System.out.println("Tracking Period : " +  diffInDays + "days");
		QAFExtendedWebElement dayElement = new QAFExtendedWebElement("progress.Goal.CountDownTimer.Days") ;
		String daytogo = dayElement.getText() ;
		System.out.println("time to go (MOVE5 app) : " + daytogo);
		Date today = new Date();
		int myDayToGo = (int)( (dEndDate.getTime() - today.getTime())/ (1000 * 60 * 60 * 24) ) + 1 ;
		System.out.println("time to go (my calculation) : " + myDayToGo);
		
		if(!String.valueOf(myDayToGo).equals(daytogo)) {
			System.err.println("Day To Go is wrong.");
			assert(false);
		}
		
	}
	
	
	@QAFTestStep(description="I verify Tracking Period is 182 days")	
    public void IVerifyTrackingPeriod(){
	
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		String strUserID ;
		
		List<Participation> participations = null; 
		
		Date dStartDate = null;
		Date dEndDate = null ;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		

		strUserID = ConfigurationManager.getBundle().getString("USER_ID");
		//We are using Web API ?
		if("false".compareToIgnoreCase(strUsingDB) == 0) {					
			participations = getParticipationUsingWebAPI(strUserID);
			
			try {
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10)) ;
				dEndDate = sdf.parse(participations.get(0).getEndDate().substring(0, 10)) ;
				
			} catch (Exception e) {
				System.err.println("Parse string to Date exception");
			}
		}
		else {
			//Leave it blank for waiting accessable to Database
			//dStartDate = get from database
			//dEndDate = get from database
		}
		
		//And we calculate the Period Tracking
		
		Calendar calendar1 = Calendar.getInstance();
		Calendar calendar2 = Calendar.getInstance();
		calendar1.setTime(dStartDate);
		calendar2.setTime(dEndDate);
		
		//int diffInDays = (int)( (dEndDate.getTime() - dStartDate.getTime())/ (1000 * 60 * 60 * 24) ) ;
		int diffInDays = dateDiff(calendar1, calendar2);		
		
		if(diffInDays != 182) {
			System.err.println("Tracking Period is not 182 days.");
			assert(false);
		}
		
		System.out.println("Tracking Period : " +  diffInDays + "days");
		QAFExtendedWebElement dayElement = new QAFExtendedWebElement("progress.Goal.CountDownTimer.Days") ;
		String daytogo = dayElement.getText() ;
		System.out.println("time to go (MOVE5 app) : " + daytogo);
		Date today = new Date();
		int myDayToGo = (int)( (dEndDate.getTime() - today.getTime())/ (1000 * 60 * 60 * 24) ) + 1 ;
		System.out.println("time to go (my calculation) : " + myDayToGo);
		
		if(!String.valueOf(myDayToGo).equals(daytogo)) {
			System.err.println("Day To Go is wrong.");
			assert(false);
		}
		
	}
	
	
		
	@QAFTestStep(description="I verify step data in Steps Detail screen of {0}")	
    public void IVerifyStepsDataInStepsDetailScreen(String email) {
		
        SimpleDateFormat sdf = new SimpleDateFormat("dd MMM yyyy");
        String strStepDate ;
        String strStepValue ;
        Date date;
        int iStepsValueInDB ;
        int iStepValueMOVE4;
        String platform = ConfigurationManager.getBundle().getString("target.platform");
		if(platform.equals("iOS")) {					
		}
		else {                
			
			email = returnParamValue(email);
			
			//get the Date
	        strStepDate = getText("progress.Dashboard.Steps.DateStxt");
	        //get the Value
	        strStepValue = getText("progress.Dashboard.Steps.StepsValueStxt");
	        iStepValueMOVE4= Integer.parseInt(strStepValue) ;
	        
	        try {
					date = sdf.parse(strStepDate);
					iStepsValueInDB = GetDataFromDB.getSteps(email, date);
					if(iStepValueMOVE4 != iStepsValueInDB) {
						assert(false);
					}
					
			} catch (ParseException e) {			
				System.out.println(e.getMessage()) ;
			}	        
	        
		}        
	}
		
	@QAFTestStep(description="I see greeting text {0}")
	public void IVerifyGreetingGivenNameInPopupDashboard(String greeting ) {
		String text = getText("progress.Popup.HelloStxt");
		if(!text.isEmpty()) {
			if(text.compareTo(greeting) > 0 )
			{
				assert(false);
			}			
		}				
	}
	
	@QAFTestStep(description="I see email intro text as {0}")
	public void IVerifyEmailIntroInResetPasswordPage(String constText) {		
		String text = getText("login.Resetpwd.VerificationIsNecessaryStxt");
		System.out.println("--------gettexet:" + text);
		System.out.println("-------constText:" + text);
		if(!text.isEmpty()) {
			if(text.compareTo(constText) > 0 )
			{
				assert(false);			
			}			
		}
	}
	
	public String returnParamValue(String strParam)
	{		
		String strRunningTag="" ;            
        String strData="";
        String realData=strParam ;
        String[] arrValue ;
        
		if(strParam.matches("<.+>"))
		{			            	                                      
            strRunningTag = ConfigurationManager.getBundle().getString("RunningCucumberTag") ;
            strData = ConfigurationManager.getBundle().getString(strRunningTag);	
            if(strData ==null) {
            	strData="";            	
            }
            else {
            	if(!strData.isEmpty()) {
            		arrValue = strData.split(",");	                 
            		for(int i=0;i<arrValue.length;i++) {	                	
            			if(arrValue[i].matches(strParam + ".+")) {
            				realData=arrValue[i].replaceAll(strParam, "");
            				break;
            			}
            		}            	
            	}           
            }
		}
		return realData;
	}
		
		
	public int getSumStepUsingWebAPI(String strUserID, String firstSyncDate, String currentDate) {
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		String myResponse ="" ; 
		int sumStep = 0;
				
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
				
		ConfigurationManager.getBundle().addProperty("USER_ID", strUserID);	
		ConfigurationManager.getBundle().addProperty("BEGIN", firstSyncDate);	
		ConfigurationManager.getBundle().addProperty("END", currentDate);		
		RestRequestBean bean3 = new RestRequestBean();	
		//com.quantum.steps.PerfectoApplicationSteps.waitFor(30);
		bean3.fillData("get.MOVE5.HealthDay");
		bean3.resolveParameters(null);
		com.quantum.steps.PerfectoApplicationSteps.waitFor(30);
		WsStep.request(bean3);
		
		//get response and parser to HealthDay class
		myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		Gson gson = new Gson();
		List<HealthDay> healthDay = gson.fromJson(myResponse, new TypeToken<List<HealthDay>>(){}.getType());	
		for(HealthDay x : healthDay) {
			sumStep +=Integer.valueOf(x.getSteps());
			
		}
		//System.out.println(sumStep);
		return sumStep;
	}
	
		
	@QAFTestStep(description="I verify Time To Go and Percent and Target Steps Level {0} with email {1}")	
    public void IVerifyPercent_TargetSteps_TimeToGo( int level, String email) throws ParseException {
	
		String strUserID ;
		strUserID = iGetUserIdUsingWebAPI(email);
		
		boolean correctPercent = false, correctDaysToGo = false, correctTargetSteps = false;
		
		//verify Percent
		String percentText = getPercent(strUserID, level);
		
		System.out.println("My Calculate Percentage: " + percentText );
		
		Map params1 = new HashMap<>();		
		params1.put("content", percentText);		
		Object result1 = DriverUtils.getDriver().executeScript("mobile:checkpoint:text", params1);		
		correctPercent = Boolean.valueOf(result1.toString());
		
		//verify Target Steps
		String strTargetSteps = String.format("%,d", getTargetSteps(strUserID, level));		
		String strMOVE5TargetSteps = getText("progress.Goal.LevelTrophyOne.AVGSteps") ;
		
		System.out.println("MOVE5 TARGET STEPS: " + strMOVE5TargetSteps);
		System.out.println("MY CALCULATE TARGET STEPS: " + strTargetSteps);
		
		if(strMOVE5TargetSteps.equals(strTargetSteps)){
			correctTargetSteps = true;
		}
		// verify Days To Go
		
		String strDaysToGo = String.valueOf(getDaysToGo(strUserID));
		String strMOVE5DayToGo = getText("progress.Goal.LevelTrophyOne.182Text") ;
		
		System.out.println("MOVE5 Day To Go " + strMOVE5DayToGo);
		System.out.println("My calculate Day To Go " + strDaysToGo);
		
		if(strMOVE5DayToGo.equals(strDaysToGo)){
			correctDaysToGo = true;
		}
		
		if(correctPercent && correctTargetSteps && correctDaysToGo)
			assert(true);
		else
			assert(false);
		
	}
	
	public String getPercent(String strUserID, int level) throws ParseException {
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		int sumStep, percent;
		int requiredStepsLevel1 = 7000;
		int requiredStepsLevel2 = 10000;
		int trackingPeriod = 182;
							
		List<Participation> participations = null; 
				
		Date dStartDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		
		//We are using Web API ?
		if("false".compareToIgnoreCase(strUsingDB) == 0) {					
			participations = getParticipationUsingWebAPI(strUserID);
			
			try {
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10)) ;
				
								
			} catch (Exception e) {
				System.err.println("Parse string to Date exception");
			}
		}
		else {
			//Leave it blank for waiting accessable to Database
			//dStartDate = get from database
			//dEndDate = get from database
		}
		
		//And we calculate the Percent
		Date currentDay = new Date();
		String dStartDateText = sdf.format(dStartDate);
		String currentDayText = sdf.format(currentDay);
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(dStartDateText));
		c.add(Calendar.DAY_OF_MONTH, 1); 
		String newdStartDateText = sdf.format(c.getTime());
		
		sumStep = getSumStepUsingWebAPI(strUserID, newdStartDateText, currentDayText);
		
		if(level == 1){
			percent = sumStep * 100 / (requiredStepsLevel1 * trackingPeriod );
		}
		else {
			percent = (sumStep - (requiredStepsLevel1 * trackingPeriod)) * 100 / ((requiredStepsLevel2 - requiredStepsLevel1 ) * trackingPeriod);
		}
		
		String percentText = String.valueOf(percent) + "%";
	
		System.out.println("currentDay: " + currentDayText);
		System.out.println("dStartDate: " + newdStartDateText);
		System.out.println("sumStep: " + sumStep);
		System.out.println("percent: " + percentText);
		return percentText;
	}
	
	
    public String iGetUserIdUsingWebAPI(String email){
		String strUserId="";
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
		}
		else {
			//leave blank for waiting DB access.
		}
		return strUserId;
    }
	
	public int getDaysToGo(String userid){
		int daysToGo = 0;
		try {
			String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
			List<Participation> participations = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dEndDate = null;
			Date currentDay = new Date();
			
			if ("false".compareToIgnoreCase(strUsingDB) == 0) {
				participations = getParticipationUsingWebAPI(userid);
				dEndDate = sdf.parse(participations.get(0).getEndDate().substring(0, 10));
			} else {
				// Leave it blank for waiting accessable to Database
				// dStartDate = get from database
				// dEndDate = get from database
		}
		
		Calendar calendar1 = Calendar.getInstance();
		Calendar calendar2 = Calendar.getInstance();
		calendar1.setTime(currentDay);
		calendar2.setTime(dEndDate);
		daysToGo = dateDiff(calendar1, calendar2) + 1;
		System.out.println("DAYS TO GO: "+daysToGo);
		} catch (Throwable e){ }
		return daysToGo;
	}
		
	
	public int dateDiff(Calendar dateStart, Calendar dateEnd){
	    if (dateStart.get(Calendar.YEAR) == dateEnd.get(Calendar.YEAR)) {
	      return Math.abs(dateStart.get(Calendar.DAY_OF_YEAR) - dateEnd.get(Calendar.DAY_OF_YEAR));
	    } else {
	    	if (dateEnd.get(Calendar.YEAR) > dateStart.get(Calendar.YEAR)) {
		      Calendar temp = dateStart;
		      dateStart = dateEnd;
		      dateEnd = temp;
	    	}
		    int resultDays = 0;
		    int dayOneOriginalYearDays = dateStart.get(Calendar.DAY_OF_YEAR);
		    while (dateStart.get(Calendar.YEAR) > dateEnd.get(Calendar.YEAR)) {
		    	dateStart.add(Calendar.YEAR, -1);
		    	resultDays += dateStart.getActualMaximum(Calendar.DAY_OF_YEAR);
		    }
		    return resultDays - dateEnd.get(Calendar.DAY_OF_YEAR) + dayOneOriginalYearDays ;
	    }
	  }
	
	public int getTargetSteps(String userid, int level) {
		int targetSteps = 0;
		int requiredSteps = 0;
		if(level == 1){
			requiredSteps = 7000;
		}else requiredSteps = 10000;
		try {
			String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
			int sumSteps = 0;
			List<Participation> participations = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dStartDate = null;
			Date dEndDate = null;
			Date currentDay = new Date();
			String currentDayText = sdf.format(currentDay);

			// We are using Web API ?
			if ("false".compareToIgnoreCase(strUsingDB) == 0) {
				participations = getParticipationUsingWebAPI(userid);
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10));
				dEndDate = sdf.parse(participations.get(0).getEndDate().substring(0, 10));
				String dStartDateText = sdf.format(dStartDate);
				Calendar c = Calendar.getInstance();
				c.setTime(sdf.parse(dStartDateText));
				c.add(Calendar.DAY_OF_MONTH, 1); 
				String newdStartDateText = sdf.format(c.getTime());
				sumSteps = getSumStepUsingWebAPI(userid, newdStartDateText, currentDayText);

			} else {
				// Leave it blank for waiting accessable to Database
				// dStartDate = get from database
				// dEndDate = get from database
			}
			
			Calendar calendar1 = Calendar.getInstance();
			Calendar calendar2 = Calendar.getInstance();
			calendar1.setTime(currentDay);
			calendar2.setTime(dEndDate);
			System.out.println(dateDiff(calendar1, calendar2));
			targetSteps = (int) Math.round(( (requiredSteps * 182) - sumSteps ) / (dateDiff(calendar1, calendar2) + 1) );
			
		} catch (Throwable e) {

		}
		System.out.println("TARGET STEPS: "+targetSteps);
		return targetSteps;
	}
	
	@QAFTestStep(description="I verify percentage, target daily average steps and days to go in incompleted trophy details level {0} and userid {1}")	
    public void IVerifyPercentIncompleLevel2(int level, String userid) throws ParseException {
		boolean correctPercent = false, correctDaysToGo = false, correctTargetSteps = false;
		//verify Percent
		String percentText = getPercent(userid, level);
		Map params1 = new HashMap<>();		
		params1.put("content", percentText);		
		Object result1 = DriverUtils.getDriver().executeScript("mobile:checkpoint:text", params1);	
		System.out.println(result1);
		correctPercent = Boolean.valueOf(result1.toString());	
		//verify Target Steps
		String strTargetSteps = String.format("%,d", getTargetSteps(userid, level));
		System.out.println("TARGET STEPS: "+strTargetSteps);
		String avgSteps1 = "TEST";
		String avgSteps2 = "TEST";
		while (avgSteps1.equalsIgnoreCase(avgSteps2)){
		avgSteps1 = getText("progress.GoalTab.TrophyLevel1.ActiveValueTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(1);
		avgSteps2 = getText("progress.GoalTab.TrophyLevel1.ActiveValueTxt");
		System.out.println(avgSteps1);
		System.out.println(avgSteps2);
		}
		if(avgSteps1.equals(strTargetSteps)||avgSteps2.equals(strTargetSteps)){
			correctTargetSteps = true;
		}
		// verify Days To Go
		String strDaysToGo = String.valueOf(getDaysToGo(userid));
		if(getText("progress.GoalTab.TrophyLevel1.LinearLayoutLeft.ValueLeftTxt").equals(strDaysToGo)){
			correctDaysToGo = true;
		}
		
		if(correctPercent && correctTargetSteps && correctDaysToGo)
			assert(true);
		else
			assert(false);
	}
	
	@QAFTestStep(description="I get userid for email {0} and save it {1}")
	public void getUserID(String email, String userid){
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		String strUserId = "";
		if(strUsingDB == null) strUsingDB ="false" ;
	
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
	
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
		}
		else {
			//leave blank for waiting DB access.
		}			
		//ConfigurationManager.getBundle().addProperty(userid, strUserId);

	}
	
	@QAFTestStep(description="I verify users {0} in Period 1")
	public void iVerify(String email){
		String strUserId ;
		int iDayToGo;
		
		strUserId = iGetUserIdUsingWebAPI(email);
				
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		
		iDayToGo = getDaysToGo(strUserId) ;		
		if(iDayToGo !=182) {			
			System.err.println("Days to Go is wrong : " + iDayToGo);
			assert(false);
		}			
		else {
			System.out.println("Days To Go is correct " + iDayToGo);
		}
	}
	
	@QAFTestStep(description="I verify HongKong users {0} in Period 1")
	public void iVerifyHKuser(String email){
		String strUserId ;
		int iDayToGo;
		
		strUserId = iGetUserIdUsingWebAPI(email);
				
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		
		iDayToGo = getDaysToGo(strUserId) ;		
		if(iDayToGo < 305) {			
			System.err.println("Days to Go is wrong : " + iDayToGo);
			assert(false);
		}			
		else {
			System.out.println("Days To Go is correct " + iDayToGo);
		}
	}
	
	
	@QAFTestStep(description = "I get {0} data and save it to {1}")
	public void getData(String data, String myValue) {
		String strRunningTag= "";            
        String strData= "";
        String realData= "";
        String[] arrValue ;
        String myValueInput = String.valueOf(data);
        strRunningTag = ConfigurationManager.getBundle().getString("RunningCucumberTag") ;
		strData = ConfigurationManager.getBundle().getString(strRunningTag);
		if(!strData.isEmpty()) {
       	 	arrValue = strData.split(",");	                 
            for(int i=0;i<arrValue.length;i++) {
            	if(arrValue[i].matches(myValueInput + ".+")) {
            		realData=arrValue[i].replaceAll(myValueInput, "");
           		 	break;
            	}
            }
         
        }
		ConfigurationManager.getBundle().addProperty(myValue, realData);
	}
	
	public int getAVGDailySteps(String userid){
		int avgDailySteps = 0;
		try {
		//	String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
			int sumSteps = 0;
			List<Participation> participations = null;
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dStartDate = null;
			Date currentDay = new Date();
			String currentDayText = sdf.format(currentDay);
			//if ("false".compareToIgnoreCase(strUsingDB) == 0) {
				participations = getParticipationUsingWebAPI(userid);
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10));			
				String dStartDateText = (sdf.format(dStartDate));
				Thread.sleep(5);
				Calendar c = Calendar.getInstance();
				c.setTime(sdf.parse(dStartDateText));
				c.add(Calendar.DAY_OF_MONTH, 1); 
				String newdStartDateText = sdf.format(c.getTime());						
				sumSteps = getSumStepUsingWebAPI(userid, newdStartDateText, currentDayText);
				System.out.println("sum steps" +sumSteps);
				

			//} else {
				// Leave it blank for waiting accessable to Database
				// dStartDate = get from database
				// dEndDate = get from database
			//}
			
			Calendar calendar1 = Calendar.getInstance();
			Calendar calendar2 = Calendar.getInstance();
			calendar1.setTime(currentDay);
			calendar2.setTime(dStartDate);
			calendar2.add(Calendar.DAY_OF_MONTH, 1);
			avgDailySteps = Math.round( sumSteps /( dateDiff(calendar1, calendar2) + 1 ) );
		} catch(Throwable e) {
			
		}
		return avgDailySteps;
	}
	
	@QAFTestStep(description="I verify average daily step for userid {0}")
	public void verifyAVGDailySteps(String userid){
		//progress.Dashboard.DailyAVGValueTxt
		String avgDailySteps = String.format("%,d", getAVGDailySteps(userid));		
		if(getText("progress.Dashboard.DailyAVGValueTxt").equals(avgDailySteps)) {
			assert(true);
		} else assert(false);
	}
	
	@QAFTestStep(description="I patching data for email {0} with {1} Steps and {2} Calories Burned and {3} Weight and {4} Sleep for today")	
    public void IPatchingHealthDataForToday(String email, String steps, String caloriesBurned, String weight, String sleep){

		String strUserId="";
		String strTrackerName="";
		String strTrackerId="";
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
		
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
			bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetHealthTracker");
			bean.resolveParameters(null);
			WsStep.request(bean);
			myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			List<HealthTracker> healthtrackers = gson.fromJson(myResponse, new TypeToken<List<HealthTracker>>(){}.getType());
			for(int i=0; i< healthtrackers.size();i++) {
				if("active".equals(healthtrackers.get(i).status)) {
					strTrackerName = healthtrackers.get(i).data.deviceName ;
					strTrackerId = healthtrackers.get(i).identifier ;
					break;
				}
			}
			
			ConfigurationManager.getBundle().addProperty("DEVICE_ID", strTrackerId);
			ConfigurationManager.getBundle().addProperty("DEVICE_TYPE", strTrackerName);
			ConfigurationManager.getBundle().addProperty("STEPS", steps);
			ConfigurationManager.getBundle().addProperty("SLEEP", sleep);
			ConfigurationManager.getBundle().addProperty("WEIGHT", weight);
			ConfigurationManager.getBundle().addProperty("CALORIES", caloriesBurned);
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
			Date dToday =new Date();
			String dateFormatted= sdf.format(dToday);
			
			ConfigurationManager.getBundle().addProperty("TODAY", dateFormatted);
			
			//bean = new RestRequestBean();
			RestRequestBean bean1 = new RestRequestBean();
			bean1.fillData("post.Move5.HealthData");
			bean1.resolveParameters(null);
			WsStep.request(bean1);
		}
		else {
			//leave blank for waiting DB access.
		}
	}
	
	
	@QAFTestStep(description="I verify Percent level {0} with email {1}")	
    public void IVerifyPercent( int level, String email) throws ParseException {
	
		String strUserID ;
		strUserID = iGetUserIdUsingWebAPI(email);
		
		boolean correctPercent = false;
		
		//verify Percent
		String percentText = getPercent(strUserID, level);
		
		Map params1 = new HashMap<>();		
		params1.put("content", percentText);		
		Object result1 = DriverUtils.getDriver().executeScript("mobile:checkpoint:text", params1);		
		correctPercent = Boolean.valueOf(result1.toString());
				
		if(correctPercent )
			assert(true);
		else
			assert(false);
	}
	
	
	public String getUserId(String pEmail) {
		System.out.println("Email");
		String strUserId ;		
		String strEnv = ConfigurationManager.getBundle().getString("Environment");				
		
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		ConfigurationManager.getBundle().addProperty("USER_EMAIL", pEmail);
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.GetMuser");
		bean.resolveParameters(null);
		WsStep.request(bean);
		
		//get response and parser to Participation class
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		Gson gson = new Gson();
		List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
		
		//Get UserId return from Web Service
		strUserId = musers.get(0).id;
		ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
		return strUserId;
		
	}
		
	
	public List<HealthDay> getHealthDayInRange(String pUserId,String pDateStart, String pEndDate) {		
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		String myResponse ="" ; 		
				
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
				
		ConfigurationManager.getBundle().addProperty("USER_ID", pUserId);	
		ConfigurationManager.getBundle().addProperty("BEGIN", pDateStart);	
		ConfigurationManager.getBundle().addProperty("END", pEndDate);	
		
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.HealthDay");
		bean.resolveParameters(null);
		WsStep.request(bean);
		
		//get response and parser to HealthDay class
		myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		Gson gson = new Gson();
		List<HealthDay> healthDays = gson.fromJson(myResponse, new TypeToken<List<HealthDay>>(){}.getType());	
		
		return healthDays;
	}
	
	public int getTotalSleepTimeInRange(String pEmail, String pStartDate, String pEndDate) {
		int iTotalSleepTime =0 ;
	
		String strUSerId = getUserId(pEmail);
		List<HealthDay> healthDays = getHealthDayInRange(strUSerId, pStartDate,pEndDate) ;
		
		if(healthDays==null)
			return 0;
		
		int size  = healthDays.size();
		
		for(int i=0; i<size ; i++) {
			iTotalSleepTime += Integer.parseInt(healthDays.get(i).getSleep());
		}
		
		return iTotalSleepTime;		
	}
	
	
	@QAFTestStep(description="I verify total sleep time of user email {0}")	
    public void iVerifyTotalSleepTimeUserEmail(String pEmail) {
		String strEmail = pEmail;
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			
			System.out.println("Testing email: " + strEmail);
						
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dEndDate ;
			Date dStartDate ;
			String strStartDate;
			String strEndDate ;
			int iTotalSleep = 0 ;
			int iTotalSleepHours = 0;
			int iTotalSleepMinutes = 0;
			
			dEndDate = new Date();
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dEndDate);
			cal.add(Calendar.DATE, -30);
			
			dStartDate = cal.getTime();
			
			strStartDate = sdf.format(dStartDate);
			strEndDate = sdf.format(dEndDate);
			
			System.out.println("start date :" + strStartDate);
			System.out.println("end date :" + strEndDate);
			
			iTotalSleep = getTotalSleepTimeInRange(strEmail, strStartDate, strEndDate);
			if(iTotalSleep > 0) {
				iTotalSleepHours = iTotalSleep/60 ;
				iTotalSleepMinutes = iTotalSleep%60 ;
			}
			
			QAFExtendedWebElement ele = new QAFExtendedWebElement("progress.Dashboard.Sleep.TotalSleepStxt") ;
			String strMoveSleepText = ele.getText() ;
			String strMySleepText =  String.valueOf(iTotalSleepHours) + " hours " + String.valueOf(iTotalSleepMinutes) + " mins" ;
			
			System.out.println("MOVE sleep text : " + strMoveSleepText);
			System.out.println("Calc sleep text : " + strMySleepText);
						
			if(! strMySleepText.equals(strMoveSleepText)) {				
				assert(false);
			}
		}
		else {
			//Leave blank for waiting DB access permission
			//Leave blank for waiting DB access permission
		}
	}
	
	public int getTotalCaloriesBurned(String pEmail, String pStartDate, String pEndDate) {
		int iTotalCaloriesBurned =0 ;
	
		String strUSerId = getUserId(pEmail);
		List<HealthDay> healthDays = getHealthDayInRange(strUSerId, pStartDate,pEndDate) ;
		
		if(healthDays==null)
			return 0;
		
		int size  = healthDays.size();
		
		for(int i=0; i<size ; i++) {
			iTotalCaloriesBurned += Integer.parseInt(healthDays.get(i).getCaloriesBurnt());
		}
		
		return iTotalCaloriesBurned;		
	}
	
	@QAFTestStep(description="I verify total Calories Burned time of user email {0}")	
    public void iVerifyTotalCaloriesBurnedTimeUserEmail(String email) {
		String strEmail = email;
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			
			System.out.println("Testing email: " + strEmail);
						
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date dEndDate ;
			Date dStartDate ;
			String strStartDate;
			String strEndDate ;
			int iCaloriesBurned = 0 ;
						
			dEndDate = new Date();
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(dEndDate);
			cal.add(Calendar.DATE, -7);
			
			dStartDate = cal.getTime();
			
			strStartDate = sdf.format(dStartDate);
			strEndDate = sdf.format(dEndDate);
			
			System.out.println("start date :" + strStartDate);
			System.out.println("end date :" + strEndDate);
			
			iCaloriesBurned = getTotalCaloriesBurned(strEmail, strStartDate, strEndDate);
			QAFExtendedWebElement ele = new QAFExtendedWebElement("progress.Dashboard.CaloriesBurned.Last7DaysTotalSleepStxt") ;
			String strCaloriesBurenedText = ele.getText() ;
			
			
			System.out.println("MOVE Calories burned text : " + strCaloriesBurenedText);
			System.out.println("Calc Calories burned text : " + iCaloriesBurned);
						
			if(! strCaloriesBurenedText.equals(iCaloriesBurned)) {				
				assert(false);
			}
		}
		else {
			//Leave blank for waiting DB access permission
			//Leave blank for waiting DB access permission
		}
	}
	
	public ManulifeMember getManulifeUser(String pUserId) {
		
		String strEnv = ConfigurationManager.getBundle().getString("Environment");				
		
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		ConfigurationManager.getBundle().addProperty("USER_ID", pUserId);
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.GetManulifeMember");
		bean.resolveParameters(null);
		WsStep.request(bean);
		
		//get response and parser to Participation class
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		Gson gson = new Gson();
		List<ManulifeMember> manulifeMembers = gson.fromJson(myResponse, new TypeToken<List<ManulifeMember>>(){}.getType());
				
		return manulifeMembers.get(0);
		
	}
	
	public void putManulifeMember(String pBody) {
		String strEnv = ConfigurationManager.getBundle().getString("Environment");				
		
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		ConfigurationManager.getBundle().addProperty("BODY", pBody);
		System.out.println("pBody:\n" + pBody);
		
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("put.MOVE5.PutManulifeMember");
		bean.resolveParameters(null);
		WsStep.request(bean);
		
	}
	
	@QAFTestStep(description="I update EYW Staus to {0} and MoveKey Status to {1} for user email {2}")	
	public void iChangeEYWStatusAndMoveKeyStatusForUserEmail(String pEYWStatus, String pMoveKeyStatus, String pEmail) {
		String strUserId;
		String strBody ;
		Gson gson ;
		
		strUserId = getUserId(pEmail) ;
		
		ManulifeMember member = getManulifeUser(strUserId);		
		member.data.challenges.eyw.eligibilityStatus =pEYWStatus ;
		member.status = pMoveKeyStatus;
		
		gson = new Gson() ;
		
		strBody = gson.toJson(member) ;
		System.out.println(strBody);
		
		//call Put Manulife Member Web Service
		putManulifeMember(strBody);
		
	}
	
	@QAFTestStep(description="I verify email {0} tracking period")	
	public void iVerifyEmailTrackingPeriod(String pEmail) {
		String strUserId ;		
		List<Participation> participations = null; 
		
		Date dStartDate = null;
		Date dEndDate = null ;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) 
		{				
			strUserId = getUserId(pEmail) ;
			
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
			
			participations = getParticipationUsingWebAPI(strUserId) ;
			
			try {
			dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10)) ;
			dEndDate = sdf.parse(participations.get(0).getEndDate().substring(0, 10)) ;
			}catch(Exception e) {
				System.err.println("Error while parsing Date");
			}
			
			int diffInDays = (int)( (dEndDate.getTime() - dStartDate.getTime())/ (1000 * 60 * 60 * 24) ) ;
			
			if(diffInDays != 182) {
				System.err.println("Tracking Period is not 182 days.");
				assert(false);
			}
			
			System.out.println("Tracking Period : " +  diffInDays + "days");			
		}
		else
		{
			//Leave it blank for waiting for DB access 
		}
	}
	
	@QAFTestStep(description="I get welcome message for user with First Name {0} and save it to {1}")	
	public void verifyMessageOnRegisterSuccessful(String firstName, String welcomeMsg){
		String welcomeMsgLoc = "//*[@label='Hi, "+firstName+"!  Welcome To Move!']";
		ConfigurationManager.getBundle().addProperty(welcomeMsg, welcomeMsgLoc);
	}
	
	@QAFTestStep(description="I verify Steps display today on page with email {0}")	
	public void iVerifyStepDisplayToday(String pEmail){
		String strUserID ;
		String strMoveStepValue ;
		String strMyStepValue;
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		//We are using WebAPi ???
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			strUserID = getUserId(pEmail);
			strMoveStepValue = new QAFExtendedWebElement("progress.Dashboard.Steps.StepsValueStxt").getText();			
			if(strMoveStepValue.isEmpty()) 
				return ;
			if(strMoveStepValue.equals("0"))
				return;
						
			
			//replace comma in format number, ex: 1,234 --> 1234
			strMoveStepValue = strMoveStepValue.replaceAll(",", "");			
			
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd") ;
			String strToday = sdf.format(new Date()) ;
			
			List<HealthDay> healthDays = getHealthDayInRange(strUserID, strToday, strToday) ;
			
			strMyStepValue = healthDays.get(0).getSteps() ;
			
			if(!strMyStepValue.equals(strMoveStepValue)) {
				System.err.println("Step Today is wrong.");
				assert(false);
			}
			System.out.println("Expected: " + strMyStepValue + "\nActualy: " + strMoveStepValue);
		}
		//Using Database
		else {
			//leave it blank for waiting Database access permission
		}				
	}
		
	@QAFTestStep(description="I verify Steps display yesterday on page with email {0}")	
	public void iVerifyStepDisplayYesterday(String pEmail){
		String strUserID ;
		String strMoveStepValue ;
		String strMyStepValue;
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		//We are using WebAPi ???
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			strUserID = getUserId(pEmail);
			strMoveStepValue = new QAFExtendedWebElement("progress.Dashboard.Steps.StepsValueStxt").getText();			
			if(strMoveStepValue.isEmpty()) 
				return ;
			if(strMoveStepValue.equals("0"))
				return;
						
			
			//replace comma in format number, ex: 1,234 --> 1234
			strMoveStepValue = strMoveStepValue.replaceAll(",", "");			
			
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd") ;
			Calendar cal = Calendar.getInstance() ;
			
			cal.setTime(new Date());
			cal.add(Calendar.DATE, -1);
			
			String strYesterday = sdf.format(cal.getTime()) ;
			
			List<HealthDay> healthDays = getHealthDayInRange(strUserID, strYesterday, strYesterday) ;
			
			strMyStepValue = healthDays.get(0).getSteps() ;
			
			if(!strMyStepValue.equals(strMoveStepValue)) {
				System.err.println("Step yesterday is wrong");
				assert(false);
			}
			
			System.out.println("Expected: " + strMyStepValue + "\nActualy: " + strMoveStepValue);
		}
		//Using Database
		else {
			//leave it blank for waiting Database access permission
		}				
	}
	
	@QAFTestStep(description="I get Steps data for today and yesterday with email {0} and save it to {1} {2}")	
	public void iGetStepData(String pEmail, String todaySteps, String yesterdaySteps){
		String strUserID ;
		String strTodayStep = "0";
		String strYesterdayStep = "0";
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		//We are using WebAPi ???
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
			strUserID = getUserId(pEmail);
						
			SimpleDateFormat sdf =new SimpleDateFormat("yyyy-MM-dd") ;
			String strToday = sdf.format(new Date()) ;
			Calendar cal = Calendar.getInstance() ;
			cal.setTime(new Date());
			cal.add(Calendar.DATE, -1);
			String strYesterday = sdf.format(cal.getTime()) ;
			
			List<HealthDay> healthDataToDay = getHealthDayInRange(strUserID, strToday, strToday) ;
			List<HealthDay> healthDataYesterday = getHealthDayInRange(strUserID, strYesterday, strYesterday) ;
			if(healthDataToDay.size() != 0){
				strTodayStep = String.format("%,d", Integer.parseInt(healthDataToDay.get(0).getSteps()));
			}
			if(healthDataYesterday.size() != 0){
				strYesterdayStep = String.format("%,d", Integer.parseInt(healthDataYesterday.get(0).getSteps()));
			}
			
			ConfigurationManager.getBundle().addProperty(todaySteps, strTodayStep);
			ConfigurationManager.getBundle().addProperty(yesterdaySteps, strYesterdayStep);
		}
		//Using Database
		else {
			//leave it blank for waiting Database access permission
		}				
	}
	
	
	
	public static String patchData(String sUrl, String param) throws Throwable{
		String result = "";
		URL url = null;
		url = new URL(sUrl);
		HttpURLConnection httpCon = (HttpURLConnection) url.openConnection();
		httpCon.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
		httpCon.setDoOutput(true);
		httpCon.setDoInput(true);
		allowMethods("PATCH");
		// httpCon.setRequestProperty("X-HTTP-Method-Override", "PATCH");
		httpCon.setRequestMethod("PATCH");
		httpCon.connect();
		OutputStream os = httpCon.getOutputStream();
		byte[] outputBytes = param.getBytes("UTF-8");
		os.write(outputBytes);
		os.flush();
		os.close();
	

		StringBuilder sb = new StringBuilder();
		if (httpCon.getResponseCode() == HttpURLConnection.HTTP_OK) {
			InputStreamReader streamReader = new InputStreamReader(httpCon.getInputStream());
			BufferedReader bufferedReader = new BufferedReader(streamReader);
			String response = null;
			while ((response = bufferedReader.readLine()) != null) {
				sb.append(response + "\n");
			}
			bufferedReader.close();
			result = sb.toString();
		} else {
			result = "error";
		}
		return result;
	}
	
	
	private static void allowMethods(String... methods) {
		try {
			Field methodsField = HttpURLConnection.class.getDeclaredField("methods");

			Field modifiersField = Field.class.getDeclaredField("modifiers");
			modifiersField.setAccessible(true);
			modifiersField.setInt(methodsField, methodsField.getModifiers() & ~Modifier.FINAL);

			methodsField.setAccessible(true);

			String[] oldMethods = (String[]) methodsField.get(null);
			Set<String> methodsSet = new LinkedHashSet<>(Arrays.asList(oldMethods));
			methodsSet.addAll(Arrays.asList(methods));
			String[] newMethods = methodsSet.toArray(new String[0]);

			methodsField.set(null/* static field */, newMethods);
		} catch (NoSuchFieldException | IllegalAccessException e) {
			throw new IllegalStateException(e);
		}
	}
	
	@QAFTestStep(description="I patch User Email {email} to be verified")
	public void patchUserEmailVerify(String pEmail) {
		String strUserId = getUserId(pEmail);
		String url;
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		if("SIT".equals(strEnv)) {			
		 url = "https://move5-app-service-sit.apps.sea.preview.pcf.manulife.com/api/Musers/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		else {			
		url = "https://move5-app-service-uat.apps.eas.pcf.manulife.com/api/Musers/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
				
		url = String.format(url, strUserId);						
		String param = "{\"isEmailVerified\": true}" ;
		try {
			patchData(url, param);
		} catch (Throwable e) {			
			System.out.println("There is an error when patch User Email to be verified.");
		}
	}
		
	@QAFTestStep (description="I get user ID and email")
	public void userID(){
	//Object email;
	//ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.GetMuser");
	bean.resolveParameters(null);
	WsStep.request(bean);
	
	//get response and parser to Participation class
	String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
	Gson gson = new Gson();
	List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
	
	//Get UserId return from Web Service
	String strUserId = musers.get(0).id;
	ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
	}
	
	
	@QAFTestStep(description="I patching Health data for {0} with {1} steps for today")	
    public void IPatchingHealthForToday(String email, String steps){
		String strUserId="";
		String TotalSteps = steps;
		String HealthTrackerId;
		String url;
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
		
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");	
				url = "https://move5-health-service-sit.apps.sea.preview.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");	
				url = "https://move5-health-service-uat.apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
			com.quantum.steps.PerfectoApplicationSteps.waitFor(15);
			
			bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetHealthSummaries");
			bean.resolveParameters(null);
			WsStep.request(bean);
			myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			List<HealthDay> HealthDayID = gson.fromJson(myResponse, new TypeToken<List<HealthDay>>(){}.getType());
			HealthTrackerId = HealthDayID.get(4).getId();
			
					
			url = String.format(url, HealthTrackerId);						
			String param = "{\"steps\": "+TotalSteps+"}" ;
			
			try {
				patchData(url, param);
			} catch (Throwable e) {			
				System.out.println("There is an error when patch User Email to be verified.");
			}
			

		}
				
	}
	
	
	@QAFTestStep(description="Validate Account create for language {language} with email {email}")	
	public void CreateAccountAPI (String language, String email) {
		ConfigurationManager.getBundle().addProperty("USER_Lang", language);
		ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.MuserAccountCreate");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		
		//get response and parser to Participation class		
		
		if (Status.equalsIgnoreCase("ok")){
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			JSONObject reader = new JSONObject(myResponse);	
			System.out.println(reader.get("status"));	
			JSONObject emailObject = reader.getJSONObject("data").getJSONObject("task").getJSONObject("data");				
			if (email.equalsIgnoreCase((String) emailObject.get("email"))){		
				assert true;
			
			}
			else {
				
				assert false;		
			}
			
			JSONObject CountryObject = reader.getJSONObject("data").getJSONObject("task").getJSONObject("data").getJSONObject("input").getJSONObject("data");			
			if (((String) CountryObject.get("country")).equalsIgnoreCase("HK") && ((String) CountryObject.get("language")).equalsIgnoreCase("en")){		
				assert true;
			System.out.println("Registration API Working Successfully");
			}
			else {
				
				assert false;		
			}
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
			bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			String strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
				
		}
		else {
			assert false;
		}
		}
	
	@QAFTestStep(description="Create Installation Id and save it in {0}")	
	public void CreateInstallationIdAPi (String InsId){
		
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "dev");			
			System.out.println("UAT env");
		}
		
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.InstallationId");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		if (Status.equalsIgnoreCase("ok")){
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();	
			JSONObject reader = new JSONObject(myResponse);		
			//JSONObject Id = reader.get("id");
			String InstallationId = (String) reader.get("id");
		//get response and parser to Participation class		
		ConfigurationManager.getBundle().addProperty(InsId, InstallationId);
		}
		else{
			assert false;
		}
	}
		
	@QAFTestStep(description="Validate TrackerBind API")	
	public void BindTrackerAPI (){
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.TrackerBindFitbit");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		if (Status.equalsIgnoreCase("ok")){
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();	
			JSONObject reader = new JSONObject(myResponse);		
			//JSONObject Id = reader.get("id");
			String Identifier = (String) reader.get("identifier");
			String TrackerStatus = (String) reader.get("status");
			String TrackerId = (String) reader.get("id");
			System.out.println(Identifier);
			System.out.println(TrackerStatus);
		//get response and parser to Participation class		
		ConfigurationManager.getBundle().addProperty("Tracker_ID", TrackerId);
		ConfigurationManager.getBundle().addProperty("Tracker_Identifier", Identifier);
		System.out.println("Bind Tracker API working Successfully");
		}
		else{
			assert false;
		}
	}
		
	@QAFTestStep(description="Validate HealthSummaryQueue API with email {email} for {days} days")	
	public void HealthSummaryQueue ( String email,int Numday){
		String key = null;
		String strUserID ;
		String TrackerStatus = "";
		strUserID = iGetUserIdUsingWebAPI(email);
		//Patching Tracker sync date		
		PatchTrackerSync(strUserID,Numday);
		
		String fitbitData = healthArr(strUserID,Numday).toString();
		JSONObject reader = new JSONObject(fitbitData);				 
		System.out.println(reader.get("health"));
		fitbitData = reader.get("health").toString();
		
		ConfigurationManager.getBundle().addProperty("fitbitData", fitbitData);		
		
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.HealthQueue");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		
		//get response from health queue		
		
		if (Status.equalsIgnoreCase("ok")){
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			reader = new JSONObject(myResponse);	
			key = (reader.get("key")).toString();
			System.out.println("Health queue API Working Successfully");
			
		}
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		
		
		while (!TrackerStatus.equalsIgnoreCase("completed")){
			String url = "https://move5-facade-service-sit.apps.sea.preview.pcf.manulife.com/api/Trackers/result?key=%s&clear=true&access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
			url = String.format(url, key);
			ConfigurationManager.getBundle().addProperty("url", url);
			bean.fillData("get.MOVE5.TrackerResult");
			bean.resolveParameters(null);
			WsStep.request(bean);	
			Status = new RestTestBase().getResponse().getStatus().toString();
			
			//get response from Tracker Result		
			
			if (Status.equalsIgnoreCase("ok")){
				String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
				reader = new JSONObject(myResponse);			
				System.out.println(reader.get("status"));
				TrackerStatus = (reader.get("status")).toString();				
				
			}	
			
		}			
				

	}
		
	JSONObject  healthObj(String reqdate, String strUserID) {
		   JSONObject Health = new JSONObject();
		   Health .put("userId",strUserID );
		   Health .put("duration", "day");
		   Health .put("summaryType", "sum");
		   Health .put("date", reqdate);
		   Health .put("endDate", reqdate);
		   Health .put("steps", "2200");
		   Health .put("sleep", "0");
		   Health .put("weight", "59");
		   Health .put("caloriesBurnt", "1000");
		   Health .put("standHours", "0");
		   Health .put("exerciseTime", "0");
		   Health .put("energyBurnt", "0");
		   JSONObject data = new JSONObject();
		   data.put("deviceId", "72GG29");
		   data.put("deviceType", "fitbit");
		   Health .put("data", data);
		   return Health;
	}
		   		   
	JSONObject  healthArr(String strUserID, int numday) {
		   	JSONArray healthData = new JSONArray();
		   	for(int i=0; i<=numday; i++){
		   		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
				Date dToday = DateUtils.addDays(new Date(), -i);
				String dateFormatted= sdf.format(dToday);
				healthData.put(i, healthObj(dateFormatted,strUserID));
			   }
		   	
		   	JSONObject obj1 = new JSONObject();
		   	obj1.putOpt("health", healthData)	;		   	
		   	return obj1;
	}
	@QAFTestStep(description="Patch tracker sync date for user {email} and for day {days}")
	public void PatchTrackerSync (String email, int numday){
		
		//userID
		String strUserID ;
		strUserID = iGetUserIdUsingWebAPI(email);
		
		///		
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.UserStatesID");
		bean.resolveParameters(null);
		WsStep.request(bean);			
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		String userStatesID = (((((returnNodeValue("id",myResponse)).replace("}"," ")).replace("]", " ")).trim()).replaceAll("^\"|\"$", ""));
		
   		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
   		String url = null;
		Date dToday = DateUtils.addDays(new Date(), -numday);
		String dateFormatted= sdf.format(dToday);
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			url = "https://move5-app-service-sit.apps.sea.preview.pcf.manulife.com/api/UserStates/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			url = "https://move5-app-service-uat.apps.eas.pcf.manulife.com/api/UserStates/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		
		url = String.format(url,userStatesID);		
		String param = 	"{\"userId\": \""+strUserID+"\",\"originalFirstDataSync\": \""+dateFormatted+"\", \"firstDataSync\": \""+dateFormatted+"\",\"lastDataSync\": \""+dateFormatted+"\",\"firstRingDataSync\": \""+dateFormatted+"\"}";
	
		try {
			patchData(url, param);
		} catch (Throwable e) {			
			System.out.println("There is an error when patch last sync date");
		}	

	}
	
	@QAFTestStep(description="Validate Login API")	
	public void loginAPI (){
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			System.out.println("SIT env");
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			System.out.println("UAT env");
		}
		
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "dev");			
			System.out.println("DEV env");
		}
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.Login");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		

		if (Status.equalsIgnoreCase("ok")){
			
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();	
			JSONObject reader = new JSONObject(myResponse);		
			//JSONObject Id = reader.get("id");
			JSONObject access = reader.getJSONObject("access");
			
			String refreshToken = (String) access.get("refreshToken");
			String uuid = (String) access.get("uuid");
			System.out.println(refreshToken);
			System.out.println(uuid);
			System.out.println("Login API Working Successfully");
			assert true;
		}
		else{
			assert false;
		}
	}
		
	@QAFTestStep(description="Validate Logout API")	
	public void logOutAPI (){
		String accesstoken="";
		String url="";
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");	
			url = "https://move5-app-service-sit.apps.sea.preview.pcf.manulife.com/api/Musers/logout?access_token=%s";
			System.out.println("SIT env");
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");	
			url = "https://move5-app-service-uat.apps.eas.pcf.manulife.com/api/Musers/logout?access_token=%s";
			System.out.println("UAT env");
		}
		
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "dev");
			url = "https://move5-app-service-dev.apps.eas.pcf.manulife.com/api/Musers/logout?access_token=%s";
			System.out.println("DEV env");
		}
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.GetAccessToken");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();

		if (Status.equalsIgnoreCase("ok")){
			
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			accesstoken=(returnNodeValue("accessToken",myResponse)).replaceAll("^\"|\"$", "");
			System.out.println(accesstoken + "API Working Successfully");
			ConfigurationManager.getBundle().addProperty("ACCESS_TOKEN", accesstoken);	
		}
		else{
			assert false;
		}			
		
		url = String.format(url, accesstoken);
		ConfigurationManager.getBundle().addProperty("LOGOUT_URL", url);
		RestRequestBean bean1 = new RestRequestBean();
		bean1.fillData("post.Move5.UserlogOut");
		bean1.resolveParameters(null);
		WsStep.request(bean1);
		Status = new RestTestBase().getResponse().getStatus().toString();
		if (Status.equalsIgnoreCase("ok")){
		System.out.println("LogOut API Working Successfully");
		}
		else
		{
			assert false;
		}
	}
		
    public static String returnNodeValue(String Node,String response)

    {

           int count = 0;

           int rcount = 0;

           String[] requiredVal = null;          

           String[] result = response.split("\""+Node+"\"");

           count = 0;

           for (java.lang.String s2 : result) {


                  if (count == 1) {

                        String[] splitResult = s2.split(":");

                        rcount = 0;

                        for (java.lang.String s3 : splitResult) {

                               String s4 = stringValue(s3);

                               //System.out.println(s4);

                               if (rcount == 1) {

                                      requiredVal = s4.split(",");

                                      //System.out.println(requiredVal[0]);



                               }

                               rcount = rcount + 1;



                        }



                  }

                  count = count + 1;



           }

           return requiredVal[0];

          

    }
    
    public static String stringValue(String data)

    {          

          // String[] arrSplit = data.split(" ");

          // String joined2 = String.join("", arrSplit);

           String joined3=data.trim();

           return joined3;

    }
	
	@QAFTestStep(description="Validate CASmember API for userId {userid} and country {country}")
	public void verifyParticipation(String userid , String Country){
		String avgDailySteps = (String.format("%,d", getAVGDailySteps(userid))).replaceAll(",","");		
		System.out.println(avgDailySteps);		
		ConfigurationManager.getBundle().addProperty("COUNTRY", Country);
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("get.MOVE5.CasMemberDetails");
		bean.resolveParameters(null);
		WsStep.request(bean);	
		String Status = new RestTestBase().getResponse().getStatus().toString();
		if (Status.equalsIgnoreCase("Ok")){
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();

		JSONObject reader = new JSONObject(myResponse);	
		
		JSONObject casAvgStp= reader.getJSONArray("participations").getJSONObject(0).getJSONArray("userGoals").getJSONObject(0).getJSONObject("data");
		
				if (avgDailySteps.equalsIgnoreCase((casAvgStp.get("current")).toString())){		
					assert true;
				
				}
						else{
							
							assert false;
						}
		}
	}
	
	@QAFTestStep(description="Validate Create MOVEkey API for {0}")	
	public void CreateMoveKeyAPI (String country){
		
		if (country.equalsIgnoreCase("HK")){
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.MoveKeyHK");
		bean.resolveParameters(null);
		WsStep.request(bean);
		}else if (country.equalsIgnoreCase("SG")){
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("post.Move5.MoveKeySG");
			bean.resolveParameters(null);
			WsStep.request(bean);
			}
		else {
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("post.Move5.MoveKeyVN");
			bean.resolveParameters(null);
			WsStep.request(bean);
			}
		String Status = new RestTestBase().getResponse().getStatus().toString();
		

		if (Status.equalsIgnoreCase("ok")){
			
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			JSONArray arrKey = new JSONArray (myResponse);
			JSONObject reader = (JSONObject) arrKey.get(0);				
			String keyId=reader.getString("id").toString();
			ConfigurationManager.getBundle().addProperty("KEYID", keyId);
			System.out.println("Create MOVE key API Working Successfully");
			assert true;
		}
		else{
			assert false;
		}
	}
    
	@QAFTestStep(description="Validate Activate MOVEkey API with mail {0} for {1}")	
	public void ActivateMoveKeyAPI (String email, String country){
		
		String strUSerId = getUserId(email);
		if (country.equalsIgnoreCase("HK")){
		RestRequestBean bean = new RestRequestBean();
		bean.fillData("post.Move5.ActivateMoveKeyHK");
		bean.resolveParameters(null);
		WsStep.request(bean);
		}else if (country.equalsIgnoreCase("SG")){
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("post.Move5.ActivateMoveKeySG");
			bean.resolveParameters(null);
			WsStep.request(bean);
			}
		else {
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("post.Move5.ActivateMoveKeyVN");
			bean.resolveParameters(null);
			WsStep.request(bean);
			}
		String Status = new RestTestBase().getResponse().getStatus().toString();
		

//		if (Status.equalsIgnoreCase("ok")){
//			com.quantum.steps.PerfectoApplicationSteps.waitFor(60);
//			//String myResponse = new RestTestBase().getResponse().getMessageBody().toString();	
//			RestRequestBean bean1 = new RestRequestBean();
//			bean1.fillData("get.MOVE5.AppOverAll");
//			bean1.resolveParameters(null);
//			WsStep.request(bean1);	
//			Status = new RestTestBase().getResponse().getStatus().toString();	
//			if (Status.equalsIgnoreCase("ok")){
//				
//				String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
//				JSONObject reader = new JSONObject(myResponse);					
//				String moveKey = reader.getJSONObject("member").getJSONObject("moveKey").getString("value");
//				
//				
//				if (moveKey.equalsIgnoreCase(RandomMoveKey)){
//					assert true;
//					System.out.println("Move key activated and reflected in appsOverall");
//				}
//				else
//				{
//					assert false;
//				}
//			
//			}
//			
//		}
//		else{
//			assert false;
//		}
	}
	
	
	@QAFTestStep(description="I create data for {0} with {1} steps for today")	
    public void ICreateDataForToday(String email, String steps){
		String strUserId="";
		String strTrackerName="";
		String strTrackerId="";
		String url;
		String param = null;
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		if(strUsingDB == null) strUsingDB ="false" ;
		
		if("false".compareToIgnoreCase(strUsingDB) == 0) {
		
			String strEnv = ConfigurationManager.getBundle().getString("Environment");
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				System.out.println("SIT env");
			}
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				System.out.println("UAT env");
			}
			
			ConfigurationManager.getBundle().addProperty("USER_EMAIL", email);
			RestRequestBean bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetMuser");
			bean.resolveParameters(null);
			WsStep.request(bean);
			
			//get response and parser to Participation class
			String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			Gson gson = new Gson();
			List<MUser> musers = gson.fromJson(myResponse, new TypeToken<List<MUser>>(){}.getType());
			
			//Get UserId return from Web Service
			strUserId = musers.get(0).id;
			ConfigurationManager.getBundle().addProperty("USER_ID", strUserId);
			
			com.quantum.steps.PerfectoApplicationSteps.waitFor(15);
			
			bean = new RestRequestBean();
			bean.fillData("get.MOVE5.GetHealthTracker");
			bean.resolveParameters(null);
			WsStep.request(bean);
			myResponse = new RestTestBase().getResponse().getMessageBody().toString();
			List<HealthTracker> healthtrackers = gson.fromJson(myResponse, new TypeToken<List<HealthTracker>>(){}.getType());
			for(int i=0; i< healthtrackers.size();i++) {
				if("active".equals(healthtrackers.get(i).status)) {
					strTrackerName = healthtrackers.get(i).data.deviceName ;
					strTrackerId = healthtrackers.get(i).identifier ;
					break;
				}
			}
			
			ConfigurationManager.getBundle().addProperty("DEVICE_ID", strTrackerId);
			ConfigurationManager.getBundle().addProperty("DEVICE_TYPE", strTrackerName);
			ConfigurationManager.getBundle().addProperty("STEPS", steps);
			ConfigurationManager.getBundle().addProperty("SLEEP", "420");
			ConfigurationManager.getBundle().addProperty("WEIGHT", "80");
			ConfigurationManager.getBundle().addProperty("CALORIES", "978");
			
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
			Date dToday =new Date();
			String dateFormatted= sdf.format(dToday);
			
			ConfigurationManager.getBundle().addProperty("TODAY", dateFormatted);
			
			//Call health summary API
			
			
			//Set Environment is SIt or UAT, so we can call the correct Web API
			if("SIT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "sit");			
				url = "https://move5-health-service-sit.apps.sea.preview.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
			}
			else if ("UAT".equals(strEnv)) {			
				ConfigurationManager.getBundle().addProperty("ENV", "uat");			
				url = "https://move5-health-service-uat.apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
			}
			
			else {			
				ConfigurationManager.getBundle().addProperty("ENV", "dev");			
				url = "https://move5-health-service-dev.apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
			}
			bean = new RestRequestBean();		
			bean.fillData("get.MOVE5.GetHealthSummaries");
			bean.resolveParameters(null);
			WsStep.request(bean);
			Gson gson1 = new Gson();
			String myResponse1 = new RestTestBase().getResponse().getMessageBody().toString();
			List<HealthDay> HealthDayID = gson.fromJson(myResponse1, new TypeToken<List<HealthDay>>(){}.getType());
			for(int i=0; i< HealthDayID.size();i++) {
							
						if ( HealthDayID.get(i).getDuration().equalsIgnoreCase("day"))
						{
							url = String.format(url, HealthDayID.get(i).getId());
							param = "{\"steps\": \""+steps+"\",  \"sleep\": 420,	\"calories\": 978,  \"weight\": 80}";
							try {
								
								patchData(url, param);
							} catch (Throwable e) {			
								System.out.println("Patching Not Done");
							}
						}											

					
					
			}

		}
		else {
			//leave blank for waiting DB access.
		}
	}
	
	@QAFTestStep(description="User delete Participation")	
    public void DeleteParticipation(){
		String url = null;	
	String myResponse;
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.Participation");
	bean.resolveParameters(null);
	WsStep.request(bean);
	
	//get response and parser to Participation class
	myResponse = new RestTestBase().getResponse().getMessageBody().toString();
	String participationsID = (((((returnNodeValue("id",myResponse)).replace("}"," ")).replace("]", " ")).trim()).replaceAll("^\"|\"$", ""));	
	String strEnv = ConfigurationManager.getBundle().getString("Environment");
	//Set Environment is SIt or UAT, so we can call the correct Web API
	if("SIT".equals(strEnv)) {			
		ConfigurationManager.getBundle().addProperty("ENV", "sit");	
		url = "https://move5-challenge-service-sit.apps.sea.preview.pcf.manulife.com/api/Participations/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		System.out.println("SIT env");
	}
	else if ("UAT".equals(strEnv)) {			
		ConfigurationManager.getBundle().addProperty("ENV", "uat");	
		url = "https://move5-challenge-service-uat.apps.eas.pcf.manulife.com/api/Participations/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		System.out.println("UAT env");
	}
	url = String.format(url, participationsID);
	ConfigurationManager.getBundle().addProperty("DELETE_PARTICIPATION", url);
	bean = new RestRequestBean();
	bean.fillData("delete.Move5.deleteParticipation");
	bean.resolveParameters(null);
	WsStep.request(bean);
	
	
	
	
	
	
	}
	
	
@QAFTestStep(description="Patching fitbit payload with email {email} and steps {steps}")	
	
	public void FitbitPayload ( String email, String steps){
		String step = steps;
		String url;
		String strUserID ;
		strUserID = iGetUserIdUsingWebAPI(email);
		
		//Call health summary API
	
		String strEnv = ConfigurationManager.getBundle().getString("Environment");
		//Set Environment is SIt or UAT, so we can call the correct Web API
		if("SIT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "sit");			
			url = "https://move5-health-service-sit.apps.sea.preview.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		else if ("UAT".equals(strEnv)) {			
			ConfigurationManager.getBundle().addProperty("ENV", "uat");			
			url = "https://move5-health-service-uat.apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		
		else {			
			ConfigurationManager.getBundle().addProperty("ENV", "dev");			
			url = "https://move5-health-service-dev.apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
		}
		RestRequestBean bean = new RestRequestBean();		
		bean.fillData("get.MOVE5.GetHealthSummaries");
		bean.resolveParameters(null);
		WsStep.request(bean);
		Gson gson = new Gson();
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		List<HealthDay> HealthDayID = gson.fromJson(myResponse, new TypeToken<List<HealthDay>>(){}.getType());
		for(int i=0; i< HealthDayID.size();i++) {
					System.out.println(HealthDayID.get(i).getId());
	
					
					if ("day".equalsIgnoreCase(HealthDayID.get(i).getDuration())){
					String env =ConfigurationManager.getBundle().getPropertyValue("ENV");
					if (env.equalsIgnoreCase("sit")){
						url = "https://move5-health-service-"+env+".apps.sea.preview.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
					}
					else
						url = "https://move5-health-service-"+env+".apps.eas.pcf.manulife.com/api/HealthSummaries/%s?access_token=493AFDE37C4427C06D41F91B716DE1DB770BAD8BF1FB17940E8EF47A0017B09B";
						url = String.format(url, HealthDayID.get(i).getId());
				String param = "{	\"steps\": \""+step+"\"}";
				try {
					patchData(url, param);
				} catch (Throwable e) {			
					System.out.println("Patching Not Done");
				}
					}
				
			}

}
@QAFTestStep(description="Validate User First Sync Date with email {email} and day {days}")	
public void userFirstSyncDate (String email, int numday ){
	String strUserID ;
	strUserID = iGetUserIdUsingWebAPI(email);
	
	///		
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.UserStatesID");
	bean.resolveParameters(null);
	WsStep.request(bean);			
	String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
	String firstSyncDate = (returnNodeValue("firstDataSync",myResponse)).substring(1, 11);
	
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		String url = null;
	Date dToday = DateUtils.addDays(new Date(), -numday);
	String dateFormatted= sdf.format(dToday);
	if (firstSyncDate.equalsIgnoreCase(dateFormatted)){
		assert true;
	}
	else 
		assert false;
}

@QAFTestStep(description="User get MOVEkey ID {MoveKey}")	
public void GetMoveKeyID (String MoveKey){
	ConfigurationManager.getBundle().addProperty("MOVE_KEY", MoveKey);
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.GetMoveKeyID");
	bean.resolveParameters(null);
	WsStep.request(bean);	
	String Status = new RestTestBase().getResponse().getStatus().toString();
	

	if (Status.equalsIgnoreCase("ok")){
		
		String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
		JSONArray arrKey = new JSONArray (myResponse);
		JSONObject reader = (JSONObject) arrKey.get(0);		
		
		String keyId=reader.getString("id").toString();
		ConfigurationManager.getBundle().addProperty("KEYID", keyId);
		System.out.println("Get MOVE key API Working Successfully");
		assert true;
	}
	else{
		assert false;
	}
}

@QAFTestStep(description="Activate MOVEkey")	
public void ActivateMoveKey (){
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("post.Move5.ActivateMoveKeyHK");
	bean.resolveParameters(null);
	WsStep.request(bean);	
	String Status = new RestTestBase().getResponse().getStatus().toString();
}

@QAFTestStep(description="Validate Average Steps useremail {email} and country {country}")
public void verifyAverageSteps(String email , String Country){
	String userID = iGetUserIdUsingWebAPI(email);
	
	
	ConfigurationManager.getBundle().addProperty("COUNTRY", Country);
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.CasMemberDetails");
	bean.resolveParameters(null);
	WsStep.request(bean);	
	String Status = new RestTestBase().getResponse().getStatus().toString();
	if (Status.equalsIgnoreCase("Ok")){
	String myResponse = new RestTestBase().getResponse().getMessageBody().toString();

	JSONObject reader = new JSONObject(myResponse);	
	String avgDailySteps = (new QAFExtendedWebElement("progress.Dashboard.ProgressTxt.AverageSteps").getText()).replace(",", "");
	JSONObject casAvgStp= reader.getJSONArray("participations").getJSONObject(0).getJSONArray("userGoals").getJSONObject(0).getJSONObject("data");
	System.out.println(casAvgStp.get("current"));
			if (avgDailySteps.equalsIgnoreCase((casAvgStp.get("current")).toString())){		
				assert true;
			
			}
					else{
						
						assert false;
					}
	}
}
    /////END/////////

}



	

