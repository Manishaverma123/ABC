package com.manulife.ap.steps.common;

import com.google.gson.JsonObject;

public class MUser {
	public String username ;
	public String email;
	public String language;
	public String allowPush;
	public String allowNews;
	public String role;
	public String country;
	public transient JsonObject data ;
	public boolean isEmailVerified ;
	public String theme;
	public String birthday;
	public String avatar;
	public transient JsonObject lastLocation;
	public String status ;
	public String created;
	public String modified;
	public String id ;
	public String installationId ;		
	
}
