package com.manulife.ap.steps.common;



/**
 * @author nnguyen95
 *
 */
public class HealthDataInfo{

	private String recordDate = "";
	private String recordStartDate = "";
	private String recordEndDate = "";
	private String caloriesBurntLife = "";
	private String caloriesBurntLifeCompletePercentage = "";
	private String caloriesBurntLifeToGoal = "";
	private String stepsLife = "";
	private String stepsLifeCompletePercentage = "";
	private String stepsLifeToGoal = "";
	private String sleep = "";
	private String sleepDuration = "";
	private String sleepHours = "";
	private String sleepMins = "";
	private String weight = "";
	private String activeEnergyBurned = "";
	private String activeEnergyBurnedGoal = "";
	private String exerciseTime = "";
	private String exerciseTimeGoal = "";
	private String standHours = "";
	private String standHoursGoal = "";

	public HealthDataInfo() {
		super();
	}

	public String getRecordDate() {
		return recordDate;
	}

	public void setRecordDate(String recordDate) {
		this.recordDate = recordDate;
	}

	public String getRecordStartDate() {
		return recordStartDate;
	}

	public void setRecordStartDate(String recordStartDate) {
		this.recordStartDate = recordStartDate;
	}

	public String getRecordEndDate() {
		return recordEndDate;
	}

	public void setRecordEndDate(String recordEndDate) {
		this.recordEndDate = recordEndDate;
	}

	public String getCaloriesBurntLife() {
		return caloriesBurntLife;
	}

	public void setCaloriesBurntLife(String caloriesBurntLife) {
		this.caloriesBurntLife = caloriesBurntLife;
	}

	public String getCaloriesBurntLifeCompletePercentage() {
		return caloriesBurntLifeCompletePercentage;
	}

	public void setCaloriesBurntLifeCompletePercentage(String caloriesBurntLifeCompletePercentage) {
		this.caloriesBurntLifeCompletePercentage = caloriesBurntLifeCompletePercentage;
	}

	public String getCaloriesBurntLifeToGoal() {
		return caloriesBurntLifeToGoal;
	}

	public void setCaloriesBurntLifeToGoal(String caloriesBurntLifeToGoal) {
		this.caloriesBurntLifeToGoal = caloriesBurntLifeToGoal;
	}

	public String getStepsLife() {
		return stepsLife;
	}

	public void setStepsLife(String stepsLife) {
		this.stepsLife = stepsLife;
	}

	public String getStepsLifeCompletePercentage() {
		return stepsLifeCompletePercentage;
	}

	public void setStepsLifeCompletePercentage(String stepsLifeCompletePercentage) {
		this.stepsLifeCompletePercentage = stepsLifeCompletePercentage;
	}

	public String getStepsLifeToGoal() {
		return stepsLifeToGoal;
	}

	public void setStepsLifeToGoal(String stepsLifeToGoal) {
		this.stepsLifeToGoal = stepsLifeToGoal;
	}

	public String getSleep() {
		return sleep;
	}

	public void setSleep(String sleep) {
		this.sleep = sleep;
	}

	public String getSleepDuration() {
		return sleepDuration;
	}

	public void setSleepDuration(String sleepDuration) {
		this.sleepDuration = sleepDuration;
	}

	public String getSleepHours() {
		return sleepHours;
	}

	public void setSleepHours(String sleepHours) {
		this.sleepHours = sleepHours;
	}

	public String getSleepMins() {
		return sleepMins;
	}

	public void setSleepMins(String sleepMins) {
		this.sleepMins = sleepMins;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getActiveEnergyBurned() {
		return activeEnergyBurned;
	}

	public void setActiveEnergyBurned(String activeEnergyBurned) {
		this.activeEnergyBurned = activeEnergyBurned;
	}

	public String getActiveEnergyBurnedGoal() {
		return activeEnergyBurnedGoal;
	}

	public void setActiveEnergyBurnedGoal(String activeEnergyBurnedGoal) {
		this.activeEnergyBurnedGoal = activeEnergyBurnedGoal;
	}

	public String getExerciseTime() {
		return exerciseTime;
	}

	public void setExerciseTime(String exerciseTime) {
		this.exerciseTime = exerciseTime;
	}

	public String getExerciseTimeGoal() {
		return exerciseTimeGoal;
	}

	public void setExerciseTimeGoal(String exerciseTimeGoal) {
		this.exerciseTimeGoal = exerciseTimeGoal;
	}

	public String getStandHours() {
		return standHours;
	}

	public void setStandHours(String standHours) {
		this.standHours = standHours;
	}

	public String getStandHoursGoal() {
		return standHoursGoal;
	}

	public void setStandHoursGoal(String standHoursGoal) {
		this.standHoursGoal = standHoursGoal;
	}

	
}
