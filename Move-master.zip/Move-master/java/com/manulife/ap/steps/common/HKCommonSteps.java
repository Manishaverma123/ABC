package com.manulife.ap.steps.common;

import com.manulife.ap.steps.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.Dimension;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ws.rest.RestTestBase;
import com.manulife.ap.steps.common.HealthDay;
import com.manulife.ap.steps.common.HealthTracker;
import com.manulife.ap.steps.common.MUser;
import com.manulife.ap.steps.common.CommonSteps;
import com.manulife.ap.steps.common.ManulifeMember;
import com.manulife.ap.steps.common.Participation;
import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.rest.RestRequestBean;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.WsStep;

import static com.qmetry.qaf.automation.step.CommonStep.*;

import com.quantum.utils.AppiumUtils;
import com.quantum.utils.DriverUtils;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.touch.offset.PointOption;

public class HKCommonSteps {

	@QAFTestStep(description = "I select Hong Kong as my country")
	public void iSelectHongKongAsMyCountry() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")){
			DriverUtils.getIOSDriver().findElementByXPath("//XCUIElementTypePickerWheel[" + (1) + "]")
			.sendKeys("Hong Kong");	
		}
		else {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("start", "729,1484");
		params1.put("end", "720,708");
		params1.put("duration", "1");
		DriverUtils.getAppiumDriver().executeScript("mobile:touch:swipe", params1);	
		}
	}

	@QAFTestStep(description = "I click Back button on Android")
	public void iClickBackBtnOnAndroid() {
		DriverUtils.getAndroidDriver().pressKeyCode(AndroidKeyCode.BACK);
		System.out.println("Clicked BACK button");
	}

	@QAFTestStep(description = "I register Hong Kong account {email}")
	public void iRegisterHongKongAccount(String pEmail) {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("Android")) {

			waitForPresent("signup.NextBtn");
			iSelectHongKongAsMyCountry();
			click("signup.NextBtn");

			waitForPresent("signup.NextBtn");
			click("signup.NextBtn");

			checkObjectIsPresent("letgo123.MaintanancePopupChkbox");
			checkObjectIsPresent("letgo123.MaintanancePopupOkbtn");

			waitForPresent("letgo123.CreateAccountBtn");
			click("letgo123.CreateAccountBtn");

			click("signup.Email");
			sendKeys(pEmail, "signup.Email");

			click("signup.NewPassword");
			sendKeys("Abcd@1234", "signup.NewPassword");

			iClickBackBtnOnAndroid();

			waitForPresent("signup.Continue");
			click("signup.Continue");

			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);

			waitForPresent("signup.LetMovingBtn");
			click("signup.LetMovingBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(5);

			waitForPresent("mainmenu.ProgressLnk");
			waitForPresent("mainmenu.SettingLnk");
			// waitForPresent("mainmenu.LeaderBoardLnk");
			waitForPresent("mainmenu.ChallengesLnk");
			waitForPresent("mainmenu.MOVE+Lnk");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
			waitForPresent("progress.Popup.CloseBtn");

		} else {
			waitForPresent("letgo123.CreateAccountBtn");
			click("letgo123.CreateAccountBtn");

			click("signup.EmailTxt");
			sendKeys(pEmail, "signup.EmailTxt");
			click("signup.PasswordTxt");
			sendKeys("Abcd@1234", "signup.PasswordTxt");
			hidekeyboard();
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
			click("signup.ContinueBtn");
			waitForPresent("signup.LetMovingBtn", 30);
			click("signup.LetMovingBtn");
			waitForPresent("progress.Popup.SetUpYourDeviceBtn", 30);
		}
	}

	private void checkObjectIsPresent(String loc) {
		if (new QAFExtendedWebElement(loc).isPresent()) {
			click(loc);
		}
	}

	@QAFTestStep(description = "I select country is {0} in iOS")
	public void selectCountryiOS(String country) {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("label", country);
		DriverUtils.getDriver().executeScript("mobile:button-text:click", params1);
	}

	@QAFTestStep(description = "I select chinese simple language in iOS")
	public void selectChineseSimpleLanguageiOS() {
		QAFExtendedWebElement ProceedBtn = new QAFExtendedWebElement("//*[@label='继续']");
		if (ProceedBtn.isPresent()) {
			// Do nothing, chinese simple is selected
			return;
		}
		ProceedBtn = new QAFExtendedWebElement("//*[@label='Proceed']");

		if (ProceedBtn.isPresent()) {
			Map<String, Object> params4 = new HashMap<>();
			params4.put("start", "389,742");
			params4.put("end", "392,657");
			params4.put("duration", "2");
			DriverUtils.getDriver().executeScript("mobile:touch:swipe", params4);
		} else {
			Map<String, Object> params6 = new HashMap<>();
			params6.put("start", "383,737");
			params6.put("end", "387,844");
			params6.put("duration", "2");
			DriverUtils.getDriver().executeScript("mobile:touch:swipe", params6);
		}
	}

	@QAFTestStep(description = "I select English language in iOS")
	public void selectEnglishLanguageiOS() {
		Map<String, Object> params2 = new HashMap<>();
		params2.put("start", "375,735");
		params2.put("end", "381,931");
		params2.put("duration", "3");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params2);
	}

	@QAFTestStep(description = "I swipe up")
	public void iSwipeUp() {
		Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
		int startX = size.getWidth() / 2;
		int startY = size.getHeight() / 2;
		int endX = 0;
		int endY = (int) (startY * -1 * 0.95);
		TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release().perform();

	}

	@QAFTestStep(description = "I change language to English")
	public void iChangeLanguageToEnglish() {
		waitForPresent("mainmenu.SettingLnk");
		click("mainmenu.SettingLnk");
		waitForPresent("settings.ChangeLanguage");
		click("settings.ChangeLanguage");
		waitForPresent("settings.ChangeLanguage.Popup.English");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		click("settings.ChangeLanguage.Popup.English");
		waitForPresent("mainmenu.ProgressLnk");
		waitForPresent("mainmenu.SettingLnk");

	}

	@QAFTestStep(description = "I change language to Simple Chinese")
	public void iChangeLanguageToSimpleChinese() {
		waitForPresent("mainmenu.SettingLnk");
		click("mainmenu.SettingLnk");
		waitForPresent("settings.ChangeLanguage");
		click("settings.ChangeLanguage");
		waitForPresent("settings.ChangeLanguage.Popup.English");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		click("settings.ChangeLanguage.Popup.SimpleChinese");
		waitForPresent("mainmenu.ProgressLnk");
		waitForPresent("mainmenu.SettingLnk");

	}

	@QAFTestStep(description = "I change language to Traditional Chinese")
	public void iChangeLanguageToTraditionalChinese() {
		waitForPresent("mainmenu.SettingLnk");
		click("mainmenu.SettingLnk");
		waitForPresent("settings.ChangeLanguage");
		click("settings.ChangeLanguage");
		waitForPresent("settings.ChangeLanguage.Popup.English");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		click("settings.ChangeLanguage.Popup.TraditionalChinese");
		waitForPresent("mainmenu.ProgressLnk");
		waitForPresent("mainmenu.SettingLnk");

	}

	@QAFTestStep(description = "I select English language")
	public void iSelectEnglishLanguage() {
		Map<String, Object> params5 = new HashMap<>();
		params5.put("start", "692,1452");
		params5.put("end", "731,2054");
		params5.put("duration", "2");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params5);
	}

	@QAFTestStep(description = "I select Chinese Simple language")
	public void iSelectChineseSimpleLanguage() {
		Map<String, Object> params2 = new HashMap<>();
		params2.put("start", "718,1401");
		params2.put("end", "726,1153");
		params2.put("duration", "1");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params2);
	}

	@QAFTestStep(description = "I select Chinese Traditional language")
	public void iSelectChineseTraditionalLanguage() {
		Map<String, Object> params4 = new HashMap<>();
		params4.put("start", "705,1435");
		params4.put("end", "701,991");
		params4.put("duration", "2");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params4);
	}

	public void hidekeyboard() {
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		DriverUtils.getIOSDriver().hideKeyboard();
		iSwipeUpiOS();

	}

	public void iSwipeUpiOS() {
		Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
		int startX = size.getWidth() / 2;
		int startY = size.getHeight() / 2;
		int endX = 0;
		int endY = (int) (startY * -1 * 0.95);

		TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release().perform();

	}
	
	@QAFTestStep(description="I verify percentage in incompleted trophy details level {0} and userid {1} for HK")	
    public void IVerifyPercentIncompleLevel2(int level, String userid) throws ParseException {
		boolean correctPercent = false, correctDaysToGo = false, correctTargetSteps = false;
		//verify Percent
		String percentText = getPercentHK(userid, level);
		Map params1 = new HashMap<>();		
		params1.put("content", percentText);		
		Object result1 = DriverUtils.getDriver().executeScript("mobile:checkpoint:text", params1);	
		System.out.println(result1);
		correctPercent = Boolean.valueOf(result1.toString());	
		/*//verify Target Steps
		String strTargetSteps = String.format("%,d", getTargetSteps(userid, level));
		System.out.println("TARGET STEPS: "+strTargetSteps);
		String avgSteps1 = "TEST";
		String avgSteps2 = "TEST";
		while (avgSteps1.equalsIgnoreCase(avgSteps2)){
		avgSteps1 = getText("progress.GoalTab.TrophyLevel1.ActiveValueTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(1);
		avgSteps2 = getText("progress.GoalTab.TrophyLevel1.ActiveValueTxt");
		System.out.println(avgSteps1);
		System.out.println(avgSteps2);
		}
		if(avgSteps1.equals(strTargetSteps)||avgSteps2.equals(strTargetSteps)){
			correctTargetSteps = true;
		}
		// verify Days To Go
		String strDaysToGo = String.valueOf(getDaysToGo(userid));
		if(getText("progress.GoalTab.TrophyLevel1.LinearLayoutLeft.ValueLeftTxt").equals(strDaysToGo)){
			correctDaysToGo = true;
		}
		
		if(correctPercent && correctTargetSteps && correctDaysToGo)
			assert(true);
		else
			assert(false);
	}*/

}
	
	public String getPercentHK(String strUserID, int level) throws ParseException {
		
		String strUsingDB = ConfigurationManager.getBundle().getString("UsingDatabase");
		int sumStep, percent;
		int requiredStepsLevel1 = 5000;
		int requiredStepsLevel2 = 7000;
		int trackingPeriod = 365;
							
		List<Participation> participations = null; 
		VerifyData verify = new VerifyData();		
		Date dStartDate = null;
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
		
		//We are using Web API ?
		if("false".compareToIgnoreCase(strUsingDB) == 0) {	
			
			participations =verify.getParticipationUsingWebAPI(strUserID);
			
			try {
				dStartDate = sdf.parse(participations.get(0).getStartDate().substring(0, 10)) ;
				
								
			} catch (Exception e) {
				System.err.println("Parse string to Date exception");
			}
		}
		else {
			//Leave it blank for waiting accessable to Database
			//dStartDate = get from database
			//dEndDate = get from database
		}
		
		//And we calculate the Percent
		Date currentDay = new Date();
		String dStartDateText = sdf.format(dStartDate);
		String currentDayText = sdf.format(currentDay);
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(dStartDateText));
		c.add(Calendar.DAY_OF_MONTH, 1); 
		String newdStartDateText = sdf.format(c.getTime());
		
		sumStep = verify.getSumStepUsingWebAPI(strUserID, newdStartDateText, currentDayText);
		
		if(level == 1){
			percent = sumStep * 100 / (requiredStepsLevel1 * trackingPeriod );
		}
		else {
			percent = (sumStep - (requiredStepsLevel1 * trackingPeriod)) * 100 / ((requiredStepsLevel2 - requiredStepsLevel1 ) * trackingPeriod);
		}
		
		String percentText = String.valueOf(percent) + "%";
	
		System.out.println("currentDay: " + currentDayText);
		System.out.println("dStartDate: " + newdStartDateText);
		System.out.println("sumStep: " + sumStep);
		System.out.println("percent: " + percentText);
		return percentText;
	}

	@QAFTestStep(description = "Validate Days to Go for HK for movekey {movekey} and save it in {var}")
	public void ValidateDaysToGo(String movekey, String var1) throws ParseException{
	int daysToGo = 0;	
	///	
	ConfigurationManager.getBundle().addProperty("MOVE_KEY", movekey);;
	RestRequestBean bean = new RestRequestBean();
	bean.fillData("get.MOVE5.GetMoveKeyID");
	bean.resolveParameters(null);
	WsStep.request(bean);			
	String myResponse = new RestTestBase().getResponse().getMessageBody().toString();
	String NextCommenceDate = (returnNodeValue("nextCommenceDate",myResponse)).substring(1, 11);
	
	//SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd") ;
	
	Date NextCommenceDate1=new SimpleDateFormat("yyyy-MM-dd").parse(NextCommenceDate);
	Date currentDay = new Date();
	
	Calendar calendar1 = Calendar.getInstance();
	Calendar calendar2 = Calendar.getInstance();
	calendar1.setTime(currentDay);
	calendar2.setTime(NextCommenceDate1);
	daysToGo = dateDiff(calendar1, calendar2)-59;
	String DAYS_TO_GO = Integer.toString(daysToGo);
	ConfigurationManager.getBundle().addProperty(var1,DAYS_TO_GO );
	
	
	
}
	

	public int dateDiff(Calendar dateStart, Calendar dateEnd){
	    if (dateStart.get(Calendar.YEAR) == dateEnd.get(Calendar.YEAR)) {
	      return Math.abs(dateStart.get(Calendar.DAY_OF_YEAR) - dateEnd.get(Calendar.DAY_OF_YEAR));
	    } else {
	    	if (dateEnd.get(Calendar.YEAR) > dateStart.get(Calendar.YEAR)) {
		      Calendar temp = dateStart;
		      dateStart = dateEnd;
		      dateEnd = temp;
	    	}
		    int resultDays = 0;
		    int dayOneOriginalYearDays = dateStart.get(Calendar.DAY_OF_YEAR);
		    while (dateStart.get(Calendar.YEAR) > dateEnd.get(Calendar.YEAR)) {
		    	dateStart.add(Calendar.YEAR, -1);
		    	resultDays += dateStart.getActualMaximum(Calendar.DAY_OF_YEAR);
		    }
		    return resultDays - dateEnd.get(Calendar.DAY_OF_YEAR) + dayOneOriginalYearDays ;
	    }
	  }	
	
	
	
/////////return Node Value
	 public static String returnNodeValue(String Node,String response)

	    {

	           int count = 0;

	           int rcount = 0;

	           String[] requiredVal = null;          

	           String[] result = response.split("\""+Node+"\"");

	           count = 0;

	           for (java.lang.String s2 : result) {


	                  if (count == 1) {

	                        String[] splitResult = s2.split(":");

	                        rcount = 0;

	                        for (java.lang.String s3 : splitResult) {

	                               String s4 = stringValue(s3);

	                               //System.out.println(s4);

	                               if (rcount == 1) {

	                                      requiredVal = s4.split(",");

	                                      //System.out.println(requiredVal[0]);



	                               }

	                               rcount = rcount + 1;



	                        }



	                  }

	                  count = count + 1;



	           }

	           return requiredVal[0];

	          

	    }
	    
	    public static String stringValue(String data)

	    {          

	          // String[] arrSplit = data.split(" ");

	          // String joined2 = String.join("", arrSplit);

	           String joined3=data.trim();

	           return joined3;

	    }
	
}