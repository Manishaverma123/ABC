package com.manulife.ap.steps.common;

public class PairValue {
	private String primitive;

	public String getPrimitive() {
		return primitive;
	}

	public void setPrimitive(String primitive) {
		this.primitive = primitive;
	}
	
	
}
