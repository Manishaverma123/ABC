package com.manulife.ap.steps.common;

public class ParticipationLocalization {
	private String name;
	private String strShort;
	private String notes;
	private LocalizationData data;
	private String access;
	private String created;
	private String modified;
	private String id;
	private String clientId;
	private LocalizationPair pairs[];
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStrShort() {
		return strShort;
	}
	public void setStrShort(String strShort) {
		this.strShort = strShort;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public LocalizationData getData() {
		return data;
	}
	public void setData(LocalizationData data) {
		this.data = data;
	}
	public String getAccess() {
		return access;
	}
	public void setAccess(String access) {
		this.access = access;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public LocalizationPair[] getPairs() {
		return pairs;
	}
	public void setPairs(LocalizationPair[] pairs) {
		this.pairs = pairs;
	}

	
	
}
