package com.manulife.ap.steps.common;

import com.manulife.ap.steps.common.CommonSteps;
import java.io.IOException;
import java.text.ParseException;
import com.qmetry.qaf.automation.step.CommonStep;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.WsStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.StringUtil;
import static com.qmetry.qaf.automation.step.CommonStep.*;
import com.manulife.ap.steps.common.CommonLoactors;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.ss.formula.functions.Column;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.*;

import com.quantum.utils.DeviceUtils;
import com.quantum.utils.DriverUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.PointOption;

public class CommonLoactors extends DatePicker {

	public static void setAndroidDatePicker(String date) throws IOException, ParseException {
		

		
		
		
		
		
		int thisYear = Integer.valueOf(new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarYear").getAttribute("text"));
		String today = (new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarDay").getAttribute("text"));
		;
		int thisMonth = getMonthNumber(getMonthNameInThreeChars(today));

		// Split the given date into date, month and year
		String[] splitdate = date.split("-");

		int givenDay = Integer.valueOf(splitdate[2]);
		int givenMonth = Integer.valueOf(splitdate[1]);
		int givenYear = Integer.valueOf(splitdate[0]);

		int forwardTaps = 0;
		int backwardTaps = 0;
		int yearFactor = 0;

		// Year Selection

		
		if (!new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarYear").getText().equals(splitdate[0])) {
			CommonSteps commonsteps = new CommonSteps();
			new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarYear").click();
			WebElement yearFirst = (WebElement) DriverUtils.getAppiumDriver().findElementsById("android:id/text1")
					.get(0);
			String year1 = ((WebElement) yearFirst).getText();
			WebElement yearSecond = (WebElement) DriverUtils.getAppiumDriver().findElementsById("android:id/text1")
					.get(1);
			String year2 = ((WebElement) yearSecond).getText();		 
			 
			
			
			
			if (Integer.parseInt(((WebElement) yearFirst).getText()) > givenYear) {
				int yearDiff = (Integer.parseInt(((WebElement) yearFirst).getText())) - givenYear;
				while (!DeviceUtils.getQAFDriver().findElementsById("android:id/text1").get(0).getText()
						.equals(splitdate[0])) {				
				commonsteps.calendarSwipeDown();
				}
				((WebElement) yearFirst).click();

			} else if (Integer.parseInt(((WebElement) yearFirst).getText()) == givenYear) {
				((WebElement) yearFirst).click();
			} else {
				while (!DeviceUtils.getQAFDriver().findElementsById("android:id/text1").get(0).getText()
						.equals(splitdate[0])) {
					commonsteps.iSwipeUpALittleBit();

				}
				((WebElement) yearFirst).click();
			}
		}

		// Month Selection
		if (givenMonth >= thisMonth) {
			forwardTaps = givenMonth - thisMonth;
		} else {
			backwardTaps = thisMonth - givenMonth;
		}

		for (int i = 1; i <= forwardTaps; i++) {
			new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarNext").click();
		}

		for (int i = 1; i <= backwardTaps; i++) {
			new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarPrev").click();
		}

		String xpath = "//android.view.View[@text='day']";
		DriverUtils.getAndroidDriver().findElement(By.xpath(xpath.replace("day", String.valueOf(givenDay)))).click();
		// Tap on OK button of the date picker
		new QAFExtendedWebElement("settings.UseMyMoveKey.CalendarOk").click();

	}

	public static void selectDateiOS(String dob) {
		System.out.println("Starting the process");
		String[] list = dob.split("@");
		for (int i = 0; i < list.length; i++) {
			System.out.println(list.length);
			DriverUtils.getIOSDriver().findElementByXPath("//XCUIElementTypePickerWheel[" + (i + 1) + "]")
					.sendKeys(list[i]);

		}
		System.out.println("Ending Process");
	}

}
