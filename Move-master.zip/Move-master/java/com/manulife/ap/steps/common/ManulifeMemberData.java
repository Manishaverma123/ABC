package com.manulife.ap.steps.common;

public class ManulifeMemberData {
	public ManulifeMemberDataChallenges challenges;
}
