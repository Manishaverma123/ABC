package com.manulife.ap.steps.common;

public class masud {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		System.out.println("Masud Masud");

	}

}
