package com.manulife.ap.steps.common;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class csvFileReader {


	public List<String> returnTestCase() {
		String path = System.getProperty("user.dir");
		
		String csvFile = path+"/src/main/resources/RBT_OUTPUT/RBT_OUTPUT.csv";        
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String[] autoTest = null;       
        List<String> TestId = new ArrayList<String>();
    
        		
        try {

            br = new BufferedReader(new FileReader(csvFile));
            br.readLine();
            for (line = br.readLine(); line != null; line = br.readLine()) {
            	
                 autoTest = line.split(cvsSplitBy);  
                 TestId.add((autoTest[1].replaceAll("^\"|\"$", "")).replace("_", "-"));

                
             }
           
         

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
		return (TestId);
        


    }

	public void DeleteFile(){
		
		String path = System.getProperty("user.dir");		
		String Filepath = path+"/src/main/resources/RBT_OUTPUT/";
		File f=new File(Filepath);
		File directory = f;
		if (directory.exists()) {
		    for (File file : directory.listFiles()) {
		        file.delete();
		    }
		    directory.delete();
		}
		
		
		
	}
	
	
}