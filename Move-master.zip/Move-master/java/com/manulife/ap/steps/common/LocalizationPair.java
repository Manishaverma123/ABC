package com.manulife.ap.steps.common;

public class LocalizationPair {
	private String key;
	private PairValue value;
	private PairData data;
	private String created;
	private String modified;
	private String id;
	private String localizationId ;
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public PairValue getValue() {
		return value;
	}
	public void setValue(PairValue value) {
		this.value = value;
	}
	public PairData getData() {
		return data;
	}
	public void setData(PairData data) {
		this.data = data;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getLocalizationId() {
		return localizationId;
	}
	public void setLocalizationId(String localizationId) {
		this.localizationId = localizationId;
	}
	
	
}
