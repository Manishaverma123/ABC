package com.manulife.ap.steps.common;

public class ParticipationActiveDay {
	private int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
	
	
}
