package com.manulife.ap.steps.common;

import com.qmetry.qaf.automation.step.CommonStep;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.step.WsStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.StringUtil;
import static com.qmetry.qaf.automation.step.CommonStep.*;
import com.manulife.ap.steps.common.CommonLoactors;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.time.DateUtils;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.rest.RestRequestBean;
import com.quantum.utils.AppiumUtils;
import com.quantum.utils.DeviceUtils;
import com.quantum.utils.DriverUtils;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.touch.offset.PointOption;

public class CommonSteps {

	@QAFTestStep(description = "I launch MOVE5 application")
	public void iLaunchMove5Application() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")) {
			// first time launch app after install
			DriverUtils.getIOSDriver().resetApp();
			if (textCheckpoint("Notifications")) {
				click("mainmenu.AllowNotificationBtn");
			}

			com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
			if (new QAFExtendedWebElement("signup.Update.IgnoreBtn").isPresent()) {
				click("signup.Update.IgnoreBtn");
			}
			if (new QAFExtendedWebElement("signup.maintananceOkBtn").isPresent()) {
				click("signup.maintananceOkBtn");
				com.quantum.steps.PerfectoApplicationSteps.waitFor(3);
			}

			if (new QAFExtendedWebElement("mainmenu.SettingLnk").isPresent()) {
				iLogOutMove5ApplicationiOS();
			}

		} else {
			//DriverUtils.getAndroidDriver().resetApp();
			DriverUtils.getAppiumDriver().resetApp();
			com.quantum.steps.PerfectoApplicationSteps.waitFor(8);
			if (new QAFExtendedWebElement("mainmenu.SettingLnk").isPresent()) {
				iLogOutMove5Application();
			}
		}

	}

	@QAFTestStep(description = "I Open MOVE5 application")
	public void iOpenMove5Application() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")) {
			// first time launch app after install

			if (textCheckpoint("Notifications")) {
				click("mainmenu.AllowNotificationBtn");

				com.quantum.steps.PerfectoApplicationSteps.waitFor(8);
				if (new QAFExtendedWebElement("signup.Update.IgnoreBtn").isPresent()) {
					click("signup.Update.IgnoreBtn");
				}
				if (new QAFExtendedWebElement("signup.maintananceOkBtn").isPresent()) {
					click("signup.maintananceOkBtn");
					com.quantum.steps.PerfectoApplicationSteps.waitFor(8);
				}
				if (new QAFExtendedWebElement("mainmenu.SettingLnk").isDisplayed()) {
					iLogOutMove5Application();
				}

			}
		} else {
			DriverUtils.getAndroidDriver().launchApp();
			com.quantum.steps.PerfectoApplicationSteps.waitFor(30);
			if (new QAFExtendedWebElement("mainmenu.SettingLnk").isPresent()) {
				iLogOutMove5Application();
			}
		}

	}
	
	
	@QAFTestStep(description = "assert {loc} attribute {text} value is {value}")
	public void assertTextValue(String loc,String text,String value) {
		if(value.equalsIgnoreCase(new QAFExtendedWebElement(loc).getAttribute(text))){
			assert true;
		}
		else 
			assert false;
	}
	@QAFTestStep(description = "I open Move5 SIT application")
	public void iiStartApplicationMove5Sit() {
		Map<String, Object> params = new HashMap<>();
		params.put("name", "Move5 SIT");
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:application:open", params);
		waitForPresent("mainmenu.SettingLnk");
	}

	@QAFTestStep(description = "I close Move5 SIT application")
	public void iiCloseApplicationMove5Sit() {
		Map<String, Object> params = new HashMap<>();
		params.put("name", "Move5 SIT");
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:application:close", params);
	}

	@QAFTestStep(description = "I open Clock application")
	public void iiStartApplicationClock() {
		Map<String, Object> params = new HashMap<>();
		params.put("name", "Clock");
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:application:open", params);

	}

	// This function use for start specify application on Phone
	@QAFTestStep(description = "I open {0} application")
	public void iiStartApplication(String appName) {
		Map<String, Object> params = new HashMap<>();
		params.put("name", appName);
		Object result1 = DriverUtils.getDriver().executeScript("mobile:application:open", params);

	}

	// start application base on environment (SIT or UAT)
	@QAFTestStep(description = "I start Move5 application")
	public void iiStartMoveApplication() {
		String appName = ConfigurationManager.getBundle().getString("driver.applicationName");
		Map<String, Object> params = new HashMap<>();
		params.put("name", appName);
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:application:open", params);
	}

	@QAFTestStep(description = "I log in with email {0} and password {1}")
	public void iLogInMove5Application(String email, String password) {
		click("login.LoginBtn");
		waitForPresent("login.EmailTxt");
		click("login.EmailTxt");
		sendKeys(email, "login.EmailTxt");
		click("login.PasswordTxt");
		sendKeys(password, "login.PasswordTxt");
		iClickBack();
		waitForEnabled("login.SigninBtn");
		click("login.SigninBtn");
		/*
		 * waitForPresent("mainmenu.ProgressLnk");
		 * waitForPresent("mainmenu.ChallengesLnk");
		 * waitForPresent("mainmenu.MOVE+Lnk");
		 * waitForPresent("mainmenu.LeaderBoardLnk");
		 * waitForPresent("mainmenu.SettingLnk");
		 */
		com.quantum.steps.PerfectoApplicationSteps.waitFor(8);

	}

	@QAFTestStep(description = "I log in with email {0} and password {1} in iOS")
	public void iLogInMove5ApplicationiOS(String email, String password) {

		// if (new QAFExtendedWebElement("mainmenu.SettingLnk").isDisplayed()) {
		// iLogOutMove5Application();
		// }
		com.quantum.steps.PerfectoApplicationSteps.waitFor(8);
		click("login.LoginBtn");
		waitForPresent("login.EmailTxt");
		click("login.EmailTxt");
		sendKeys(email, "login.EmailTxt");
		click("login.PasswordTxt");
		sendKeys(password, "login.PasswordTxt");
		// com.quantum.steps.PerfectoApplicationSteps.waitFor(30);
		hidekeyboard();
		com.quantum.steps.PerfectoApplicationSteps.waitFor(15);
		// waitForEnabled("login.SigninBtn");
		// click("login.SigninBtn");
/*		waitForPresent("mainmenu.ProgressLnk");
		waitForPresent("mainmenu.ChallengesLnk");
		waitForPresent("mainmenu.MOVE+Lnk");
		waitForPresent("mainmenu.SettingLnk");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(8);*/
	}

	@QAFTestStep(description = "I click Back button")
	public void iClickBack() {
		// Map<String, Object> params1 = new HashMap<>();
		// params1.put("keySequence", "BACK");
		// DriverUtils.getDriver().executeScript("mobile:presskey", params1);
		DriverUtils.getAndroidDriver().pressKeyCode(AndroidKeyCode.BACK);
		System.out.println("Clicked BACK button");
	}

	@QAFTestStep(description = "I click Back Arrow in iOS")
	public void iClickBackBackArrow() {
		click("iOs.BACK");
	}

	@QAFTestStep(description = "I log Out")
	public void iLogOutMove5Application() {
		click("mainmenu.SettingLnk");
		// waitForPresent("settings.TitleStxt");
		// waitForPresent("settings.UseMyMoveKeyLnk");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		iSwipeUp();

		click("settings.LogOutBtn");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		click("settings.Confirm.LogOutBtn");
	}

	@QAFTestStep(description = "I swipe up")
	public void iSwipeUp() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")) {
			// AppiumUtils.swipeUp();
			iSwipeUpiOS();

		} else {
			Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
			int startX = size.getWidth() / 2;
			int startY = size.getHeight() / 2;
			int endX = 0;
			int endY = (int) (startY * -1 * 0.85);
			TouchAction action = new TouchAction(DriverUtils.getAndroidDriver());
			action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release()
					.perform();
		}

	}

	@QAFTestStep(description = "I swipe up a little bit")
	public void iSwipeUpALittleBit() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")) {
			//AppiumUtils.swipeUp();
			Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
			int startX = size.getWidth() / 2;
			int startY = size.getHeight() / 2;
			int endX = startX;
			int endY = startY - 300;
			TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
			action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release()
					.perform();
		} else {
			Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
			int startX = size.getWidth() / 2;
			int startY = size.getHeight() / 2;
			int endX = startX;
			int endY = startY - 500;
			TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
			action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release()
					.perform();
		}

	}
	
	@QAFTestStep(description = "I swipe down a little bit")
	public void iSwipeDownALittleBit() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
	/*	if (platform.equals("iOS")) {
			AppiumUtils.swipeUp();
		} else {*/
			Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
			int startX = size.getWidth() / 2;
			int startY = size.getHeight() / 2;
			int endX = startX;
			int endY = startY + 500;
			TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
			action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release()
					.perform();
	/*	}*/

	}

	@QAFTestStep(description = "I disconnect device in Android")
	public void disconnectDeviceAndroid() {
		click("mainmenu.SettingLnk");
		waitForPresent("settings.ChangeDeviceLnk");
		click("settings.ChangeDeviceLnk");
		click("settings.SetUpYourDevice.DisconnectBtn");
		click("settings.ChangeDevice.SetUpYourDevice.DisconnectBtn");
		waitForPresent("settings.TitleStxt");
	}

	@QAFTestStep(description = "I disconnect device in iOS")
	public void disconnectDeviceiOS() {
		click("mainmenu.SettingLnk");
		waitForPresent("settings.UseMyMoveKeyLnk", 30);
		waitForPresent("settings.ChangeDeviceLnk", 30);
		// waitForPresent("settings.SetAvatarBtn", 30);
		click("settings.ChangeDeviceLnk");
		waitForPresent("settings.ChangeDevice.DisconnectBtn", 30);
		click("settings.ChangeDevice.DisconnectBtn");
		waitForPresent("settings.ChangeDevice.DisconnectWarningPopup.DisconnectBtn", 30);
		// click Disconnect button on warning popup
		click("settings.ChangeDevice.DisconnectWarningPopup.DisconnectBtn");
		waitForPresent("settings.ChangeDeviceLnk");
		waitForPresent("settings.UseMyMoveKeyLnk");

	}

	@QAFTestStep(description = "I click on anywhere")
	public void iClickOnBlank() {

		Map<String, Object> params1 = new HashMap<>();
		params1.put("location", "647,906");
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:touch:tap", params1);

	}

	@QAFTestStep(description = "the hint message is not shown")
	public void messageIsNotShown() {

		Map<String, Object> params1 = new HashMap<>();
		params1.put("content",
				"By selecting country of your residence, MOVE can customise content relevant and suitable for you.");
		Object result1 = DriverUtils.getAppiumDriver().executeScript("mobile:checkpoint:text", params1);

		Boolean resultBool = Boolean.valueOf(result1.toString());
		if (resultBool.equals("false")) {
			System.out.println("==========================Hint message is not shown==========================");
			assert (true);
		}

	}

	@QAFTestStep(description = "I click on the Terms and Conditions link")
	public void clickTermsandCondition() {
		Map<String, Object> params9 = new HashMap<>();
		params9.put("label", "Terms");
		Object result9 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params9);

	}

	@QAFTestStep(description = "I click on the {0} link")
	public void clickText(String text) {
		Map<String, Object> params9 = new HashMap<>();
		params9.put("label", text);
		Object result9 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params9);

	}

	@QAFTestStep(description = "I am shown the Singapore is selected as default")
	public void singaporeSelectedAsDefault() {
		if (new QAFExtendedWebElement("signup.SelectCountryBtn").getAttribute("value").equals("Singapore")) {
			System.out.println("=============Singapore is selected as default============================");
			assert (true);
		}

	}

	@QAFTestStep(description = "I have not setup any device or MOVE Key")
	public void i_have_not_setup_any_device_or_MOVE_Key() {

	}

	@QAFTestStep(description = "I set up Fitbit device with account {0} and password {1}")
	public void setUpDeviceFitbit(String account, String password) {
		waitForPresent("settings.SetUpYourDevice.FitbitBtn");
		click("settings.SetUpYourDevice.FitbitBtn");
		
		if (textCheckpoint("Please sync your device")) {
			click("settings.SetUpYourDevice.ConnectNewDeviceBtn");
		}
		
		
		waitForPresent("settings.SetUpYourDevice.OkGotItBtn");
		click("settings.SetUpYourDevice.OkGotItBtn");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
		click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		sendKeys(account, "settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		//click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitWelcomeTxt");
		//iClickBack();
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitPasswordTxt");
		//click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitPasswordTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		sendKeys(password, "settings.ChangeDevice.SetupDevice.OptFitbit.FitbitPasswordTxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		//click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitWelcomeTxt");
		//iClickBack();
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitLoginBtn");
		click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitLoginBtn");

		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);

		if (new QAFExtendedWebElement("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitSelectAllBtn").isDisplayed()) {

			waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitSelectAllBtn");
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitSelectAllBtn");
			waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitAllowBtn");
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitAllowBtn");
		}
		waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitStartNowBtn");
		click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitStartNowBtn");

		com.quantum.steps.PerfectoApplicationSteps.waitFor(20);
	}

	@QAFTestStep(description = "I set up Fitbit device with account {0} and password {1} in iOS")
	public void setUpDeviceFitbit_iOS(String account, String password) {
		try {
			click("settings.SetUpYourDevice.FitbitBtn");
			Thread.sleep(5000);
			if (textCheckpoint("Connect New Device")) {
				click("settings.SetUpYourDevice.ConnectNewDeviceBtn");
			}
			click("settings.SetUpYourDevice.ConnectNewDeviceBtn");
			click("settings.SetUpYourDevice.OkGotItBtn");
			waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
			sendKeys(account, "settings.ChangeDevice.SetupDevice.OptFitbit.FitbitEmailTxt");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitPasswordTxt");
			sendKeys(password, "settings.ChangeDevice.SetupDevice.OptFitbit.FitbitPasswordTxt");
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitLoginBtn");

			Thread.sleep(5000);

			// if (CommonSteps.textCheckpoint("Fitbit devices and settings")) {
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitSelectAllBtn");
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitAllowBtn");
			// }
			waitForPresent("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitStartNowBtn");
			click("settings.ChangeDevice.SetupDevice.OptFitbit.FitbitStartNowBtn");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I set up Misfit device with account {0} and password {1} in iOS")
	public void setUpDeviceMisfit_iOS(String account, String password) {
		try {
			click("settings.ChangeDevice.SetupDevice.OptMisfitBtn");
			Thread.sleep(5000);
			if (textCheckpoint("Connect New Device")) {
				click("settings.ChangeDevice.SetupDevice.ListSetUpDeviceOpt.ConnectBtn");
			}
			waitForPresent("settings.ChangeDevice.SetupDevice.OptMisfit.EmailTxt");
			sendKeys(account, "settings.ChangeDevice.SetupDevice.OptMisfit.EmailTxt");
			click("settings.ChangeDevice.SetupDevice.OptMisfit.PasswordTxt");
			sendKeys(password, "settings.ChangeDevice.SetupDevice.OptMisfit.PasswordTxt");
			click("settings.ChangeDevice.SetupDevice.OptMisfit.SignInBtn");

			Thread.sleep(10000);

			if (textCheckpoint("Request for permission")) {
				iSwipeUp();
				waitForPresent("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowForMoveBtn");
				click("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowForMoveBtn");
				Thread.sleep(10000);
			}

			click("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowAccess.StartNowBtn");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I do not input email and password")
	public void i_do_not_input_email_and_password() {

	}

	@QAFTestStep(description = "message {0} is displayed")
	public void message_is_displayed(String message) {
		if (CommonSteps.textCheckpoint(message) == true) {
			System.out.println("==========================" + message + " message is  shown==========================");
			assert (true);
		}
	}

	@QAFTestStep(description = "I set up Google Fit device with account {0}")
	public void selectGgFitAccount(String account) throws InterruptedException {
		try{
		click("settings.SetUpYourDevice.GoogleFitBtn");			
		//if (textCheckpoint("Please sync your device")) {
		//	click("settings.SetUpYourDevice.ConnectNewDeviceBtn");
		//}		
		if(new QAFExtendedWebElement("settings.SetUpYourDevice.ConnectNewDeviceBtn").isPresent()){
		   new QAFExtendedWebElement("settings.SetUpYourDevice.ConnectNewDeviceBtn").click();
		};		
		String xpath = "//android.widget.TextView[@text='" + account + "']";
		click(xpath);
		
			if (new QAFExtendedWebElement("settings.SetUpYourDevice.GoogleFitAllowBtn").isPresent()) {
				new QAFExtendedWebElement("settings.SetUpYourDevice.GoogleFitAllowBtn").click();			
				}	
		
	} catch (NoSuchElementException e) {
	    System.out.println("Element is not present, hence not displayed as well");
	}



				
	}

	
	
	@QAFTestStep(description = "I see the value of Daily Steps Average is calculated correctly for account {0}")
	public void verifyDailyAVGSteps(String account) {
		int appDailyAVGSteps = Integer.parseInt(getText("progress.Dashboard.DailyAVGValueTxt").replace(",", ""));
		int dbDailyAVGSteps = (int) GetDataFromDB.getDailyAVGSteps(account);
		System.out.println("==============================appDailyAVGSteps : " + appDailyAVGSteps
				+ "============================");
		System.out.println(
				"==============================dbDailyAVGSteps : " + dbDailyAVGSteps + "============================");
		if (appDailyAVGSteps == dbDailyAVGSteps) {
			System.out.println(
					"==============================Daily AVG Steps is shown correctly============================");
			assert (true);
		}

	}

	@QAFTestStep(description = "I input the MOVE Key {0} with DOB {1} for my account")
	public void inputMOVEKey(String movekey, String dob) {
		click("mainmenu.SettingLnk");
		click("settings.UseMyMoveKeyLnk");
		sendKeys(movekey, "useMoveKey.MoveKeyTxt");
		sendKeys(dob, "useMoveKey.DobTxt");
		click("useMoveKey.TermConditionChk");
		click("useMoveKey.ActivateBtn");
	}

	@QAFTestStep(description = "I am not see {0}")
	public void notShown(String text) {
		if (!textCheckpoint(text)) {
			System.out.println("==========================" + text + " is NOT shown==========================");
			assert (true);

		}
	}

	@QAFTestStep(description = "I click on the Program Terms and Conditions link")
	public void clickProgramTermsandCondition() {
		Map<String, Object> params3 = new HashMap<>();
		params3.put("label", "Terms and Conditions");
		Object result3 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params3);

	}

	@QAFTestStep(description = "I click on the Program Terms link")
	public void clickProgramTermsLink() {
		Map<String, Object> params3 = new HashMap<>();
		params3.put("label", "Program Terms");
		Object result3 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params3);

	}

	@QAFTestStep(description = "I click on the Personal Data Protection Statement link")
	public void clickPersonalDataProtectionStatement() {
		Map<String, Object> params5 = new HashMap<>();
		params5.put("label", "Protection Statement");
		Object result5 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params5);

	}

	@QAFTestStep(description = "I click on the Personal Data Protection link")
	public void clickPersonalDataProtectionLink() {
		Map<String, Object> params5 = new HashMap<>();
		params5.put("label", "Personal Data Protection");
		DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params5);

	}

	@QAFTestStep(description = "I click on Activate Move Key")
	public void clickSubmitYourMoveKey() {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("location", "187,640");
		DriverUtils.getAppiumDriver().executeScript("mobile:touch:tap", params1);
	}

	@QAFTestStep(description = "I swipe year dob of set up move key")
	public void swipeYearMoveKey() {
		Map<String, Object> params6 = new HashMap<>();
		params6.put("start", "580,856");
		params6.put("end", "577,781");
		params6.put("duration", "1");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params6);
	}
	
	@QAFTestStep(description = "I swipe year to select WRONG dob of set up move key")
	public void swipeYearMoveKeyWrongDOB() {
		Map<String, Object> params6 = new HashMap<>();
		params6.put("start", "480,756");
		params6.put("end", "477,681");
		params6.put("duration", "1");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params6);
	}
	

	@QAFTestStep(description = "I swipe to select today")
	public void iSwipeToSelectToday() {
		Map<String, Object> params3 = new HashMap<>();
		params3.put("start", "204,889");
		params3.put("end", "204,820");
		params3.put("duration", "3");
		DriverUtils.getDriver().executeScript("mobile:touch:swipe", params3);
	}

	@QAFTestStep(description = "I click on {0} blur")
	public void clickActiveButtonBlur(String locatorBlur) {
		if (new QAFExtendedWebElement(locatorBlur).isPresent()) {
			new QAFExtendedWebElement(locatorBlur).click();
		}
	}

	public static boolean textCheckpoint(String textToFind) {
		boolean result = false;
		Map params1 = new HashMap<>();
		params1.put("content", textToFind);
		Object result1 = DriverUtils.getDriver().executeScript("mobile:checkpoint:text", params1);
		result = Boolean.valueOf(result1.toString());
		return result;
	}

	@QAFTestStep(description = "I generate random email address and save it in {0}")
	public void iGenarateRandomEmailAndSaveIt(String var) {
		String randonEmail;
		randonEmail = StringUtil.createRandomString();
		randonEmail = randonEmail + "@yopmail.com";
		ConfigurationManager.getBundle().addProperty(var, randonEmail);

	}

	@QAFTestStep(description = "I generate random move key and save it in {0}")
	public void iGenarateRandomMoveKeyAndSaveIt(String var) {
		String randomMoveKey;

		randomMoveKey = StringUtil.createRandomString();

		ConfigurationManager.getBundle().addProperty(var, randomMoveKey);
		System.out.println("Random MoveKey : " + randomMoveKey);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String dateFormatted = sdf.format(date);
		Date dToday = DateUtils.addDays(new Date(), 365);
		String nextCommenceDate = sdf.format(dToday);
		System.out.println("date formatted : " + dateFormatted);
		ConfigurationManager.getBundle().addProperty("TodayDoB", dateFormatted);
		ConfigurationManager.getBundle().addProperty("NEXTCOMMENCEDATE", nextCommenceDate);

		String env = ConfigurationManager.getBundle().getString("Environment");

		if ("SIT".equals(env)) {
			ConfigurationManager.getBundle().addProperty("ENV", "sit");
			System.out.println("SIT env");
		} else {
			ConfigurationManager.getBundle().addProperty("ENV", "uat");
			System.out.println("UAT env");
		}

	}

	@QAFTestStep(description = "I turn off Step and Activity permission in Health App")
	public void turnOffHealthPermission() {
		click("appleHealth.sourceTab");

		// Move5 SIT or Move5 UAT
		String appName = ConfigurationManager.getBundle().getString("driver.applicationName");
		// click on app
		if (textCheckpoint(appName)) {
			String loc = "//*[@label='" + appName + "']";
			click(loc);
			// turn off activity and step permission
			if (!new QAFExtendedWebElement("appleHealth.sourceTab.move4Permission.activityBtn").getAttribute("value")
					.equals("0")) {
				click("appleHealth.sourceTab.move4Permission.activityBtn");
			}

			if (!new QAFExtendedWebElement("appleHealth.sourceTab.move4Permission.stepBtn").getAttribute("value")
					.equals("0")) {
				click("appleHealth.sourceTab.move4Permission.stepBtn");
			}
		}

		// back
		click("appleHealth.sourceTab.backBtn");

	}

	@QAFTestStep(description = "I do not allow to access Health App")
	public void notAllowToAccessHealthApp() {
		try {
			click("settings.SetUpYourDevice.OkGotItBtn");
			Thread.sleep(5000);
			if (textCheckpoint("Health Access")) {
				click("appleHealth.healthAccess.dontallowBtn");
				click("appleHealth.healthAccess.alertPopup.OkBtn");
			}
			click("settings.SetUpYourDevice.OkGotItBtn");
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@QAFTestStep(description = "I turn on permission in Health App")
	public void allowToAccessHealthApp() {
		click("appleHealth.sourceTab");

		// Move4 SIT or Move4 UAT
		String appName = ConfigurationManager.getBundle().getString("driver.applicationName");
		// click on app
		if (textCheckpoint(appName)) {
			String loc = "//*[@label='" + appName + "']";
			click(loc);

			// turn on permission if it is off
			if (getText("appleHealth.sourceTab.turnOnPermissionBtn").equals("Turn All Categories On")) {
				click("appleHealth.sourceTab.turnOnPermissionBtn");
			}
		}

		// back
		click("appleHealth.sourceTab.backBtn");

	}

	@QAFTestStep(description = "I back to MOVE main screen")
	public void iBackToMOVEMainScreen() {
		QAFExtendedWebElement progressLink = new QAFExtendedWebElement("mainmenu.ProgressLnk");

		while (!progressLink.isPresent()) {
			iClickBack();
			com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		}

	}

	@QAFTestStep(description = "I register a account with email random {0} in Android")
	public void iSignupMoveAccountApplicationAndroid(String RandomEmailAddress) {
		waitForPresent("letgo123.CreateAccountBtn");
		click("letgo123.CreateAccountBtn");
		waitForPresent("signup.SelectCountryBtn");
		click("signup.SelectCountryBtn");
		waitForPresent("signup.FirstName");
		click("signup.FirstName");
		sendKeys("AutoAcc", "signup.FirstName");
		click("signup.LastName");
		sendKeys("SitAcc", "signup.LastName");
		click("signup.Email");
		sendKeys(RandomEmailAddress, "signup.Email");
		click("signup.NewPassword");
		sendKeys("Abcd1234", "signup.NewPassword");
		iClickBack();
		waitForPresent("signup.Continue");
		click("signup.Continue");
		waitForPresent("signupsuccess.IconTicketImg");
		click("signupsuccess.StartMovingBtn");
		waitForPresent("mainmenu.ProgressLnk");

	}

	@QAFTestStep(description = "I register a account with email random {0} in iOS")
	public void iSignupMoveAccountApplicationiOS(String RandomEmailAddress) {
		waitForPresent("letgo123.CreateAccountBtn");
		click("letgo123.CreateAccountBtn");
		click("signup.ProceedBtn");
		waitForPresent("signup.EmailAddressTxt");
		click("signup.EmailAddressTxt");
		sendKeys(RandomEmailAddress, "signup.EmailAddressTxt");
		click("signup.NewPasswordTxt");
		sendKeys("Abcd1234", "signup.NewPasswordTxt");
		click("signup.ConfirmNewPasswordTxt");
		sendKeys("Abcd1234", "signup.ConfirmNewPasswordTxt");
		click("signup.SurnameTxt");
		sendKeys("MoveAutoAcc", "signup.SurnameTxt");
		click("signup.GivenNameTxt");
		sendKeys("MoveAutoAcc", "signup.GivenNameTxt");
		// iClickBack();
		click("signup.SignupBtn");
		waitForPresent("signup.StartMovingBtn");
		click("signup.StartMovingBtn");
		waitForPresent("mainmenu.ProgressLnk");

	}

	public void hidekeyboard() {

		DriverUtils.getIOSDriver().hideKeyboard();

	}

	public void iSwipeUpiOS() {
		Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
		int startX = size.getWidth() / 2;
		int startY = size.getHeight() / 2;
		int endX = 0;
		int endY = (int) (startY * -1 );
		int endY1 = (int) (startY * -1 * 0.98 );		

		TouchAction action = new TouchAction(DriverUtils.getIOSDriver());		 
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release().perform();
		
		TouchAction action1 = new TouchAction(DriverUtils.getIOSDriver());		 
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY1)).release().perform();
		
		
	}

	@QAFTestStep(description = "I log Out in iOS")
	public void iLogOutMove5ApplicationiOS() {
		click("mainmenu.SettingLnk");
		waitForPresent("settings.TitleStxt");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		iSwipeUpiOS();		
		click("settings.LogOutBtn");
		click("settings.Confirm.LogOutBtn");
	}

	@QAFTestStep(description = "I want change avatar for user with picture already in Android")
	public void iChangeAvatarForUser() {
		waitForPresent("mainmenu.SettingLnk");
		click("mainmenu.SettingLnk");
		waitForPresent("settings.SetAvatarBtn");
		click("settings.SetAvatarBtn");
		waitForPresent("settings.SetAvatar.Popup.PhotoAlbumBtn");
		click("settings.SetAvatar.Popup.PhotoAlbumBtn");
		if (textCheckpoint("Allow")) {
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessPhotoBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		}
		waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.PhotoBtn");
		click("settings.SetAvatar.Popup.PhotoAlbum.PhotoBtn");

		if (textCheckpoint("Google+")) {
			// waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.AllowGoogleAccessPhotoBtn");
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowGoogleAccessPhotoBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		}

		click("settings.SetAvatar.Popup.PhotoAlbum.Photo.ListImageBtn");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		click("settings.SetAvatar.Popup.PhotoAlbum.Photo.ListImage.Image1");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		waitForPresent("settings.SetAvatarBtn");

	}

	@QAFTestStep(description = "I want change avatar for user take with camera in Android")
	public void iChangeAvatarForUserWithCamera() {
		waitForPresent("mainmenu.SettingLnk");
		click("mainmenu.SettingLnk");
		waitForPresent("settings.SetAvatarBtn");
		click("settings.SetAvatarBtn");
		click("settings.SetAvatar.Popup.CameraBtn");
		/*
		 * if (textCheckpoint("Allow")) {
		 * click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn1"
		 * ); com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		 * click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn2"
		 * ); com.quantum.steps.PerfectoApplicationSteps.waitFor(10); }
		 */
		com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		if (new QAFExtendedWebElement("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn1").isDisplayed()) {
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn1");
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn1");
		}

		if (textCheckpoint("TURN ON")) {
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TurnOnLocationBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		}

		Map<String, Object> params2 = new HashMap<>();
		params2.put("location", "720,2461");
		Object result2 = DriverUtils.getAppiumDriver().executeScript("mobile:touch:tap", params2);

		waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePictureOkBtn");
		click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePictureOkBtn");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		waitForPresent("settings.SetAvatarBtn");

	}

	@QAFTestStep(description = "I use photo in Photo Album to set avatar for Move account in iOS")
	public void iChangeAvatarForUserWithPhotoAlbumiOS() {
		click("mainmenu.SettingLnk");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(20);
		waitForPresent("settings.SetAvatarBtn");
		click("settings.SetAvatarBtn");
		waitForPresent("settings.SetAvatar.Popup.PhotoAlbumBtn");
		click("settings.SetAvatar.Popup.PhotoAlbumBtn");

		TakePictureFromGalleryIniOS();

		//waitForPresent("settings.SetAvatarBtn");
	}

	public void TakePictureFromGalleryIniOS() {
		/*
		 * if(textCheckpoint("Would Like to Access Your Photos")){
		 * click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessPhotoBtn");
		 * }
		 */
		if (new QAFExtendedWebElement("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessPhotoBtn").isPresent()) {
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessPhotoBtn");
		}
		click("photoAlbum.CameraRollFolder");
		click("photoAlbum.1stPicture");

		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);

		// click Choose button
		Map<String, Object> params3 = new HashMap<>();
		params3.put("label", "Choose");
		Object result3 = DriverUtils.getDriver().executeScript("mobile:button-text:click", params3);
	}

	@QAFTestStep(description = "I change my avatar using Gallery in iOS")
	public void iChangeMyAvatarUsingGalleryIniOS() {
		TakePictureFromGalleryIniOS();
		waitForPresent("signup.CameraBtn");
	}

	@QAFTestStep(description = "I change my avatar using Camera in iOS")
	public void iChangeMyAvatarUsingCameraIniOS() {
		TakePictureFromCameraIniOS();
		// waitForPresent("signup.CameraBtn");
		waitForPresent("settings.SetAvatarBtn");
	}

	@QAFTestStep(description = "I want change avatar for user take with camera in iOS")
	public void iChangeAvatarForUserWithCameraiOS() {
		click("mainmenu.SettingLnk");
		waitForPresent("settings.SetAvatarBtn");
		click("settings.SetAvatarBtn");
		waitForPresent("settings.SetAvatar.Popup.CameraBtn");
		click("settings.SetAvatar.Popup.CameraBtn");

		TakePictureFromCameraIniOS();

		waitForPresent("settings.SetAvatarBtn");
	}

	public void TakePictureFromCameraIniOS() {
		if (new QAFExtendedWebElement("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn").isPresent()) {
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn");
		}
		/*
		 * if (textCheckpoint("Move SIT Would Like to Access the Camera")) {
		 * click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCameraBtn")
		 * ;
		 * 
		 * com.quantum.steps.PerfectoApplicationSteps.waitFor(5); }
		 */

		waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePictureBtn");
		click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePictureBtn");
		waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePicture.UsePhotoBtn");
		click("settings.SetAvatar.Popup.PhotoAlbum.AllowMoveAccessCamera.TakePicture.UsePhotoBtn");
	}

	@QAFTestStep(description = "I click on Hint button")
	public void iClickOnHintBtn() {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("label", "PUBLIC:ImageObjects/iOS_Phone/MOVE_SignUpJourneyScreen/HintIcon.png");
		Object result1 = DriverUtils.getDriver().executeScript("mobile:button-image:click", params1);
	}

	@QAFTestStep(description = "I set up Misfit device with account {0} and password {1} in Android")
	public void setUpDeviceMisfit_Android(String account, String password) {
		try {
			waitForPresent("settings.ChangeDevice.SetupDevice.OptMisfitBtn");
			click("settings.ChangeDevice.SetupDevice.OptMisfitBtn");
			Thread.sleep(5000);
			waitForPresent("settings.ChangeDevice.SetupDevice.OptMisfit.EmailTxt");
			sendKeys(account, "settings.ChangeDevice.SetupDevice.OptMisfit.EmailTxt");
			click("settings.ChangeDevice.SetupDevice.OptMisfit.PasswordTxt");
			sendKeys(password, "settings.ChangeDevice.SetupDevice.OptMisfit.PasswordTxt");
			click("settings.ChangeDevice.SetupDevice.OptMisfit.SignInBtn");

			Thread.sleep(10000);

			if (textCheckpoint("Request for permission")) {
				// iSwipeUp();
				waitForPresent("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowForMoveBtn");
				click("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowForMoveBtn");
				Thread.sleep(10000);
			}

			click("settings.ChangeDevice.SetupDevice.OptMisfit.SignIn.AllowAccess.StartNowBtn");
			waitForPresent("settings.SetUpDevice.SetUpDeviceTitleStxt");

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	@QAFTestStep(description = "I swipe down to refresh data")
	public void iSwipeDownToRefreshData() {

		QAFExtendedWebElement progressDashboardHelpBtn = new QAFExtendedWebElement("progress.Dashboard.HelpBtn");

		/*
		 * while(!progressDashboardHelpBtn.isPresent()) { iSwipeDown();
		 * 
		 * }
		 */
		iSwipeDown();
	}

	public void iSwipeDown() {
		Map<String, Object> params8 = new HashMap<>();
		params8.put("start", "752,757");
		params8.put("end", "719,2512");
		params8.put("duration", "1");
		Object result8 = DriverUtils.getDriver().executeScript("mobile:touch:swipe", params8);
	}

	@QAFTestStep(description = "I am see text {0}")
	public void ShownText(String text) {
		if (textCheckpoint(text)) {
			System.out.println("==========================" + text + " SHOWN==========================");
			assert (true);

		}
	}

	@QAFTestStep(description = "I create account with Email {0} Password {1}")
	public void createAccount(String email, String password) {
		waitForPresent("letgo123.CreateAccountBtn", 30);
		click("letgo123.CreateAccountBtn");
		click("signup.EmailTxt");
		sendKeys(email, "signup.EmailTxt");
		click("signup.PasswordTxt");
		sendKeys(password, "signup.PasswordTxt");
		click("signup.MyMoveAccount");
		waitForPresent("letgo123.NextBtn", 30);
		click("letgo123.NextBtn");
		// waitForPresent("progress.Popup.SetUpYourDeviceBtn", 30);

	}

	@QAFTestStep(description = "I click on {0} if it is presented")
	public void checkObjectIsPresent(String loc) {
		if (new QAFExtendedWebElement(loc).isPresent()) {
			click(loc);
		}
	}

	@QAFTestStep(description = "I install app on iOS")
	public void InstallAppOnIos() {
		Map<String, Object> params = new HashMap<>();
		params.put("app", "D:\\Users\\santu halder\\Downloads\\MoveSit.ipa");
		DriverUtils.getAppiumDriver().executeScript("mobile: installApp", params);

	}

	@QAFTestStep(description = "I swipe left on android screen")
	public void iSwipeleftAnd() {
		Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
		int startX = (int) (size.getWidth() * 0.8);
		int startY = size.getHeight() / 2;
		int endX = (int) (startX * 0.20);

		TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, startY)).release().perform();

	}

	@QAFTestStep(description = "I swipe right on android screen")
	public void iSwipeRightAnd() {
		Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
		int startX = (int) (size.getWidth() * 0.2);
		int startY = size.getHeight() / 2;
		int endX = (int) (size.getWidth() * 0.8);

		TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
		action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, startY)).release().perform();

	}

	@QAFTestStep(description = "Press Enter")

	public void PressEnter() {

		DriverUtils.getAndroidDriver().pressKeyCode(AndroidKeyCode.ENTER);

	}

	@QAFTestStep(description = "I click on the button text {text}")
	public void clickOfferDetails(String btnTxt) {

		Map<String, Object> params9 = new HashMap<>();
		params9.put("label", btnTxt);
		Object result9 = DriverUtils.getAppiumDriver().executeScript("mobile:button-text:click", params9);

	}
	
	@QAFTestStep(description = "set {loc} attribute {text} value is {value}")
	public void SetTextValue(String loc,String text,String value) {
		
		//new QAFExtendedWebElement(loc).setAttribute(text, value);
		JavascriptExecutor js = (JavascriptExecutor) DriverUtils.getAppiumDriver();
		js.executeScript("arguments[0].setAttribute('text', '2019-03-01')",new QAFExtendedWebElement(loc));
	}
	
	@QAFTestStep(description = "Select date from calendar {0}")
    public void setDate(String dob) throws IOException, ParseException {
		CommonLoactors.setAndroidDatePicker(dob);
		
    }
	
	@QAFTestStep(description = "Select date from calendar for iOS {0}")
    public void setDateIos(String dob) {		
		String birth=dob;
		CommonLoactors.selectDateiOS(birth);
    }	
	
	@QAFTestStep(description = "Select language in iOS {0}")
    public void setLanguage(String language) {		
		
		DriverUtils.getIOSDriver().findElementByXPath("//XCUIElementTypePickerWheel[" + (1) + "]")
		.sendKeys(language);
    }
	

	@QAFTestStep(description = "User click on {0}")
	public void userClickOn(String element) {
		Map<String, Object> params = new HashMap<>();
		params.put("xpath", element);		
		Object result9 =DriverUtils.getAppiumDriver().executeScript("application.element.click", element);

	}
	
	public void calendarSwipeDown() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
	/*	if (platform.equals("iOS")) {
			AppiumUtils.swipeUp();
		} else {*/
			Dimension size = AppiumUtils.getAppiumDriver().manage().window().getSize();
			int startX = size.getWidth() / 2;
			int startY = size.getHeight() / 2;
			int endX = startX;
			int endY = startY + 200;
			TouchAction action = new TouchAction(DriverUtils.getAppiumDriver());
			action.longPress(PointOption.point(startX, startY)).moveTo(PointOption.point(endX, endY)).release()
					.perform();
	/*	}*/

	}
	
 /* ##################################################################################################################
  * ##################################################################################################################
  * function to select the country
  * Author:masud
  */
	@QAFTestStep(description = "I select Vietnam as my country")
	public void iSelectVietnamAsMyCountry() {
		String platform = ConfigurationManager.getBundle().getString("target.platform");
		if (platform.equals("iOS")){
			DriverUtils.getIOSDriver().findElementByXPath("//XCUIElementTypePickerWheel[" + (1) + "]")
			.sendKeys("Vietnam");	
		}
		else {
		Map<String, Object> params1 = new HashMap<>();
		params1.put("start", "729,1484");
		params1.put("end", "720,708");
		params1.put("duration", "1");
		DriverUtils.getAppiumDriver().executeScript("mobile:touch:swipe", params1);	
		}
	}
 
	@QAFTestStep(description = "I want to select photo for new account creation with picture already in Android")
	public void iSelectPhotoForNewAccountCreation() {
		waitForPresent("signup.ChangeImgBtn");
		click("signup.ChangeImgBtn");
		waitForPresent("signup.ChoosePhotoBtn");
		click("signup.ChoosePhotoBtn");
		//waitForPresent("settings.SetAvatar.Popup.PhotoAlbumBtn");
		//click("settings.SetAvatar.Popup.PhotoAlbumBtn");
		if (textCheckpoint("ALLOW")) {
			click("signup.dialog.CameraPermissionAllowBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		}
		waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.PhotoBtn");
		click("settings.SetAvatar.Popup.PhotoAlbum.PhotoBtn");

		if (textCheckpoint("Google+")) {
			// waitForPresent("settings.SetAvatar.Popup.PhotoAlbum.AllowGoogleAccessPhotoBtn");
			click("settings.SetAvatar.Popup.PhotoAlbum.AllowGoogleAccessPhotoBtn");
			com.quantum.steps.PerfectoApplicationSteps.waitFor(10);
		}

		click("settings.SetAvatar.Popup.PhotoAlbum.Photo.ListImageBtn");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		click("settings.SetAvatar.Popup.PhotoAlbum.Photo.ListImage.Image1");
		com.quantum.steps.PerfectoApplicationSteps.waitFor(5);
		//waitForPresent("settings.SetAvatarBtn");

	}
	
	
	@QAFTestStep(description = "User click on text {0}")
	public void clickOnText(String TxtValue) {

	Map<String, Object> params = new HashMap<>();
	params.put("content", TxtValue);
	params.put("threshold", 80);
	DriverUtils.getAppiumDriver().executeScript("mobile:text:select", params);

	       }


}// End
