package com.manulife.ap.steps.common;


import com.qmetry.qaf.automation.step.CommonStep;
import com.qmetry.qaf.automation.step.QAFTestStep;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.util.StringUtil;
import static com.qmetry.qaf.automation.step.CommonStep.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;

import org.openqa.selenium.Dimension;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.quantum.utils.AppiumUtils;
import com.quantum.utils.DriverUtils;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidKeyCode;

public class MailOTP {
	
	String hostName = "smtp.outlook.com";
	String username = "automove5sit@outlook.com";
	String password = "Jokinglife@2010";
	int messageCount;
	int unreadMsgCount;
	String emailSubject;
	Message emailMessage;
	@QAFTestStep(description="Read OTP from outlook")
	public void MailReader() {
	    Properties sysProps = System.getProperties();
	    sysProps.setProperty("smtp.live.com", "imaps");

	    try {
	        Session session = Session.getInstance(sysProps, null);
	        Store store = session.getStore();
	        store.connect(hostName, username, password);
	        Folder emailInbox = store.getFolder("INBOX");
	        emailInbox.open(Folder.READ_WRITE);
	        messageCount = emailInbox.getMessageCount();
	        System.out.println("Total Message Count: " + messageCount);
	        unreadMsgCount = emailInbox.getNewMessageCount();
	        System.out.println("Unread Emails count:" + unreadMsgCount);
	        emailMessage = emailInbox.getMessage(messageCount);
	        emailSubject = emailMessage.getSubject();

	        Pattern linkPattern = Pattern.compile("href=\"(.*)\" target"); // here you need to define regex as per you need
	        Matcher pageMatcher =
	                linkPattern.matcher(emailMessage.getContent().toString());

	        while (pageMatcher.find()) {
	            System.out.println("Found OTP " + pageMatcher.group(1));
	        }
	        emailMessage.setFlag(Flags.Flag.SEEN, true);
	        emailInbox.close(true);
	        store.close();

	    } catch (Exception mex) {
	        mex.printStackTrace();
	    }
	}


}
