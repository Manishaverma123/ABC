package com.manulife.ap.steps.common;

public class ManulifeMemberDataChallengesEYW {
	public String eligibilityStatus;
	public String redemptionDate;
}
