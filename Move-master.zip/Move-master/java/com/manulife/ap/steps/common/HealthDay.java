package com.manulife.ap.steps.common;

import org.json.JSONObject;

public class HealthDay {
	private String userId;
	private String duration;
	private String summaryType;
	private HealthDate date;
//	private HealthEndDate endDate;
	private String steps;
	private String sleep;
	private String weight;
	private String caloriesBurnt;
	private String standHours;
	private String exerciseTime;
	private String energyBurnt;
	private JSONObject data;
	private String created;
	private String modified;
	private String id;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getSummaryType() {
		return summaryType;
	}
	public void setSummaryType(String summaryType) {
		this.summaryType = summaryType;
	}
	public HealthDate getDate() {
		return date;
	}
	public void setDate(HealthDate date) {
		this.date = date;
	}
//	public HealthEndDate getEndDate() {
//		return endDate;
//	}
//	public void setEndDate(HealthEndDate endDate) {
//		this.endDate = endDate;
//	}
	public String getSteps() {
		return steps;
	}
	public void setSteps(String steps) {
		this.steps = steps;
	}
	public String getSleep() {
		return sleep;
	}
	public void setSleep(String sleep) {
		this.sleep = sleep;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getCaloriesBurnt() {
		return caloriesBurnt;
	}
	public void setCaloriesBurnt(String caloriesBurnt) {
		this.caloriesBurnt = caloriesBurnt;
	}
	public String getStandHours() {
		return standHours;
	}
	public void setStandHours(String standHours) {
		this.standHours = standHours;
	}
	public String getExerciseTime() {
		return exerciseTime;
	}
	public void setExerciseTime(String exerciseTime) {
		this.exerciseTime = exerciseTime;
	}
	public String getEnergyBurnt() {
		return energyBurnt;
	}
	public void setEnergyBurnt(String energyBurnt) {
		this.energyBurnt = energyBurnt;
	}
	public JSONObject getData() {
		return data;
	}
	public void setData(JSONObject data) {
		this.data = data;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	

}
