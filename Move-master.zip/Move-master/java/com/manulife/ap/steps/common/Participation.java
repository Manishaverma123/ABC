package com.manulife.ap.steps.common;

public class Participation {
	private String userId;
	private transient ParticipationData data;
	private String period;
	private String startDate;
	private String endDate;
	private String status;
	private String created;
	private String modified;
	private String id;
	private String challengeId;
	
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public ParticipationData getData() {
		return data;
	}
	public void setData(ParticipationData data) {
		this.data = data;
	}
	public String getPeriod() {
		return period;
	}
	public void setPeriod(String period) {
		this.period = period;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCreated() {
		return created;
	}
	public void setCreated(String created) {
		this.created = created;
	}
	public String getModified() {
		return modified;
	}
	public void setModified(String modified) {
		this.modified = modified;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getChallengeId() {
		return challengeId;
	}
	public void setChallengeId(String challengeId) {
		this.challengeId = challengeId;
	}
	
//	
//	public static void main(String[] args) {
//		Gson gson = new Gson();
//		List<Participation> p ;
//		
//		String strJSon="[{'userId':'5b1f52f98f754d0007ad96b8','data':{'notes':'','requiresMoveKey':false,'requiresDevice':true,'deviceName':'any','daysElapsed':-4,'notifications':[{'type':'partipation','title':'push-title-partipation','message':'push-message-partipation','enabled':false},{'type':'middle','title':'push-title-middle','message':'push-message-middle','enabled':false},{'type':'completion','title':'push-title-completion','message':'push-message-completion','enabled':false}],'localization':{'name':'SGStepsChallengeTranslation','short':'steps-translation','notes':'Thisisthetranslationfileforchallenges.','data':{'userId':'5ad6fb30cc955e89157c167d','tags':'move,steps,sg,translation'},'access':'all','created':'2018-06-08T05:02:04.558Z','modified':'2018-06-08T05:04:40.551Z','id':'5b1a0dcc3526d40007e9967b','clientId':'5ad72444bf347f4e7f7d5720','pairs':[{'key':'push-message-middle-en','value':{'primitive':'Challegeinthemiddlemessageen.'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:02:20.638Z','modified':'2018-06-08T05:02:44.569Z','id':'5b1a0ddc3526d40007e9967d','localizationId':'5b1a0dcc3526d40007e9967b'},{'key':'push-message-participation-en','value':{'primitive':'Youjuststartedachallegemessageen.'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:02:38.003Z','modified':'2018-06-08T05:02:38.003Z','id':'5b1a0dee3526d40007e9967f','localizationId':'5b1a0dcc3526d40007e9967b'},{'key':'push-message-completion','value':{'primitive':'Challengecompletionmessageen.'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:03:46.346Z','modified':'2018-06-08T05:03:46.346Z','id':'5b1a0e323526d40007e99682','localizationId':'5b1a0dcc3526d40007e9967b'},{'key':'push-title-participation-en','value':{'primitive':'startedtitleen'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:04:02.679Z','modified':'2018-06-08T05:04:02.679Z','id':'5b1a0e423526d40007e99684','localizationId':'5b1a0dcc3526d40007e9967b'},{'key':'push-title-middle-en','value':{'primitive':'middletitleen'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:04:16.010Z','modified':'2018-06-08T05:04:38.007Z','id':'5b1a0e503526d40007e99686','localizationId':'5b1a0dcc3526d40007e9967b'},{'key':'push-title-completion-en','value':{'primitive':'completedtitleen'},'data':{'notes':'','type':'text','tags':''},'created':'2018-06-08T05:04:32.669Z','modified':'2018-06-08T05:04:32.669Z','id':'5b1a0e603526d40007e99688','localizationId':'5b1a0dcc3526d40007e9967b'}]},'activeDays':{'count':0},'daysToGo':186},'period':1,'startDate':'2018-06-24T10:22:54.872Z','endDate':'2018-12-23T10:22:54.872Z','status':'pending','created':'2018-06-19T10:22:54.872Z','modified':'2018-06-19T10:22:54.873Z','id':'5b28d97e514e5400078b49ff','challengeId':'5b1a0d3ffc26470007477eaa'}]" ;
//		p = gson.fromJson(strJSon, new TypeToken<List<Participation>>(){}.getType()) ;
//		
//		System.out.println("Start Date : " );
//	}
}


