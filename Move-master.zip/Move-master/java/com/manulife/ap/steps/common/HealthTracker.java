package com.manulife.ap.steps.common;



public class HealthTracker {
	public String userId ;
	public String type;
	public String platform;
	public HealthTrackerData data;
	public String identifier;
	public String created;
	public String modified;
	public String status;
	public String id ;	
	
}

