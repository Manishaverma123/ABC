package com.manulife.ap.steps.common;

public class ParticipationData {
	private String notes;
	private String requiresMoveKey;
	private String requiresDevice;
	private String deviceName;
	private int daysElapsed;
	private ParticipationNotification notifications[];
	private ParticipationLocalization localization;
	private ParticipationActiveDay activeDays;
	private int  daysToGo;
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getRequiresMoveKey() {
		return requiresMoveKey;
	}
	public void setRequiresMoveKey(String requiresMoveKey) {
		this.requiresMoveKey = requiresMoveKey;
	}
	public String getRequiresDevice() {
		return requiresDevice;
	}
	public void setRequiresDevice(String requiresDevice) {
		this.requiresDevice = requiresDevice;
	}
	public String getDeviceName() {
		return deviceName;
	}
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	public int getDaysElapsed() {
		return daysElapsed;
	}
	public void setDaysElapsed(int daysElapsed) {
		this.daysElapsed = daysElapsed;
	}
	public ParticipationNotification[] getNotifications() {
		return notifications;
	}
	public void setNotifications(ParticipationNotification[] notifications) {
		this.notifications = notifications;
	}
	public ParticipationLocalization getLocalization() {
		return localization;
	}
	public void setLocalization(ParticipationLocalization localization) {
		this.localization = localization;
	}
	public ParticipationActiveDay getActiveDays() {
		return activeDays;
	}
	public void setActiveDays(ParticipationActiveDay activeDays) {
		this.activeDays = activeDays;
	}
	public int getDaysToGo() {
		return daysToGo;
	}
	public void setDaysToGo(int daysToGo) {
		this.daysToGo = daysToGo;
	}
	
	
}
