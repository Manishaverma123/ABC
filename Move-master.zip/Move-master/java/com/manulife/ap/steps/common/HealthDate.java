package com.manulife.ap.steps.common;

public class HealthDate {

	private String _when;
	private String _date;
	public String get_when() {
		return _when;
	}
	public void set_when(String _when) {
		this._when = _when;
	}
	public String get_date() {
		return _date;
	}
	public void set_date(String _date) {
		this._date = _date;
	}
	
}
