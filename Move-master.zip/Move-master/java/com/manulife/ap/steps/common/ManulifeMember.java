package com.manulife.ap.steps.common;

import java.util.List;

public class ManulifeMember {
	public String userId ;
	public List<String> policies ;
	public ManulifeMemberData data;
	public String status;
	public String country;
	public String created ;
	public String modified ;
	public String id;
	public String keyId;
	
}
