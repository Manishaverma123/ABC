package com.manulife.ap.steps.common;

import com.google.gson.JsonObject;

public class HealthTrackerData {
	public transient JsonObject payload;
	public String deviceName ;
	public String id;
}
