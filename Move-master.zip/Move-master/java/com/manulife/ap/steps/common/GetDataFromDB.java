package com.manulife.ap.steps.common;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;
import com.manulife.ap.steps.common.HealthDataInfo;
import gherkin.deps.com.google.gson.Gson;

public class GetDataFromDB {

	static Gson gson = new Gson();

	public static Connection setUpDBConnection() {
		Connection con = null;
		try {
//			String hostname = ConfigurationManager.getBundle().getString("db.hostname");
//			String name = ConfigurationManager.getBundle().getString("db.name");
//			String username = ConfigurationManager.getBundle().getString("db.username");
//			String password = ConfigurationManager.getBundle().getString("db.password");
			
			String hostname = "localhost:80";
			String name = "test";
			String username = "root";
			String password = "root";
			
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://"+hostname+"/"+name+"", username, password);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		return con;
	}

	public static String getUserId(String email) {
		String userId = "";
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt;

			stmt = con.createStatement();

			ResultSet rs = stmt
					.executeQuery("select moveid from move_account where jsoncontent like '%" + email + "%';");
			while (rs.next()) {
				userId = rs.getString(1);
			}

			rs.close();
			con.close();
			
		} catch (Throwable e) {
			e.printStackTrace();
		}
		return userId;
	}

	public static int getSumSteps(String email, Date startDate, Date endDate) {
		int sumSteps = 0;
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt;

			stmt = con.createStatement();

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");

			String sql = "SELECT pay_load from test.move_health_data where user_id = '"
					+ getUserId(email) + "'and record_date BETWEEN '" + formatter.format(startDate) + "' AND '"
					+ formatter.format(endDate) + "';";
			
			ResultSet rs = stmt.executeQuery(sql);

			HealthDataInfo healthDataInfo;
			while (rs.next()) {
				healthDataInfo = new HealthDataInfo();
				healthDataInfo = gson.fromJson(rs.getString(1), HealthDataInfo.class);
				sumSteps = sumSteps + Integer.parseInt(healthDataInfo.getStepsLife());
			}

			rs.close();
			con.close();

		} catch (Throwable e) {	
			e.printStackTrace();
		}

		return sumSteps;
	}

	public static Date getFirstSyncDate(String email) {
		Date firstSyncDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(
					"select jsoncontent from test.move_account where moveid = '" + getUserId(email) + "';");

			String content = "";
			while (rs.next()) {
				content = rs.getString(1);
			}
			rs.close();
			con.close();

			// parse json to obj
			// moveAccountInfo = gson.fromJson(content, MoveAccountInfo.class);
			//MoveAccountInfo moveAccountInfo = gson.fromJson(content, MoveAccountInfo.class);
			//firstSyncDate = formatter.parse(moveAccountInfo.getFirstSyncDate().substring(0, 10));

		} catch (Throwable e) {
			e.printStackTrace();
		}
		return firstSyncDate;
	}

	public static Date getClubCommenceDate(String email) {
		Date clubCommenceDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt = con.createStatement();

			ResultSet rs = stmt.executeQuery(
					"select jsoncontent from test.move_account where moveid = '" + getUserId(email) + "';");

			String content = "";
			while (rs.next()) {
				content = rs.getString(1);
			}
			rs.close();
			con.close();

			// parse json to obj
			//MoveAccountInfo moveAccountInfo = gson.fromJson(content, MoveAccountInfo.class);
			//clubCommenceDate = formatter.parse(moveAccountInfo.getClubCommenceDate().substring(0, 10));

			/*MoveAccountInfo moveAccountInfo = gson.fromJson(content, MoveAccountInfo.class);
			clubCommenceDate = formatter.parse(moveAccountInfo.getClubCommenceDate().substring(0, 10));*/


		} catch (Throwable e) {			
			e.printStackTrace();
		}
		return clubCommenceDate;
	}
	
	public static double getDailyAVGSteps(String email) {
		double dailyAVGSteps = 0;
		int dayPassed = 0;

		String userid = getUserId(email);

		Date clubCommenceDate = null;
		Date currentDate = new Date();

		// get first sync date
		clubCommenceDate = getClubCommenceDate(email);
		// calculate date passed
		dayPassed = (int) ((currentDate.getTime() - clubCommenceDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
		// calculate daily AVG
		dailyAVGSteps = Math.round(((double) getSumSteps(userid, clubCommenceDate, currentDate) / dayPassed));

		return dailyAVGSteps;
	}

	public static Date getNextCommenceDate(String email) {
		Date nextCommenceDate = null;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(
					"select jsoncontent from test.move_account where moveid = '" + getUserId(email) + "';");

			String content = "";
			while (rs.next()) {
				content = rs.getString(1);
			}
			rs.close();
			con.close();


			//nextCommenceDate = formatter
			//.parse(gson.fromJson(content, MoveAccountInfo.class).getNextCommenceDate().substring(0, 10));
			//nextCommenceDate = formatter.parse(gson.fromJson(content, MoveAccountInfo.class).getNextCommenceDate().substring(0, 10));


		} catch (Throwable e) {			
			e.printStackTrace();
		}

		return nextCommenceDate;
	}

	public static int getDaysToGo(String email) {
		int daysToGo = 0;

		Date nextCommenceDate = getNextCommenceDate(email);
		Date currentDate = new Date();

		daysToGo = (int) ((nextCommenceDate.getTime() - currentDate.getTime()) / (1000 * 60 * 60 * 24));

		return daysToGo;
	}

//	public static double getTargetSteps(int stepsTargetOfLevel, String email) {
//		String userid = getUserId(email);
//
//		double targetSteps = 0;
//
//		int trackingPeriod = 182;
//		Date currentDate = new Date();
//		// get first sync date
//		Date firstSyncDate = getFirstSyncDate(userid);
//
//		int sumSteps = getSumSteps(userid, firstSyncDate, currentDate);
//
//		int daysToGo = getDaysToGo(userid);
//
//		targetSteps = ((stepsTargetOfLevel * trackingPeriod) - sumSteps) / daysToGo;
//
//		return targetSteps;
//	}

//	public static double getPercent(int level, String email) {
//		String userid = getUserId(email);
//		double percent = 0;
//		Date firstSyncDate = getFirstSyncDate(userid);
//		Date currentDate = new Date();
//
//		int requiredSteps = 0;
//		if (level == 1)
//			requiredSteps = 7000;
//		else
//			requiredSteps = 10000;
//
//		int sumSteps = getSumSteps(userid, firstSyncDate, currentDate);
//
//		int trackingPeriod = 182;
//
//		percent = (sumSteps / (requiredSteps * trackingPeriod));
//
//		return percent;
//	}

	public static int getSteps(String email, Date recordDate) {
		int steps = 0;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		String userid = getUserId(email);
		try {
			Connection con = null;
			con = setUpDBConnection();
			Statement stmt;
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select pay_load from test.move_health_data where user_id = '" + userid
					+ "' and record_date = '" + formatter.format(recordDate) + "';");

			HealthDataInfo healthDataInfo;
			while (rs.next()) {
				healthDataInfo = new HealthDataInfo();
				healthDataInfo = gson.fromJson(rs.getString(1), HealthDataInfo.class);
				steps = Integer.parseInt(healthDataInfo.getStepsLife());
			}

			rs.close();
			con.close();
			
		} catch (Throwable e) {
			e.printStackTrace();
		}

		return steps;
	}

}
