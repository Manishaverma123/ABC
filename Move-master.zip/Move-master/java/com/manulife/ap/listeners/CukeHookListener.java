package com.manulife.ap.listeners;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.step.QAFTestStepAdapter;
import com.qmetry.qaf.automation.step.StepExecutionTracker;
import com.qmetry.qaf.automation.step.client.TestNGScenario;


public class CukeHookListener  extends QAFTestStepAdapter {

	@Override
	public void onFailure(StepExecutionTracker stepExecutionTracker) {
		
		ConfigurationManager.getBundle().clearProperty("RunningCucumberTag");
		super.onFailure(stepExecutionTracker);
	}

	@Override
	public void beforExecute(StepExecutionTracker stepExecutionTracker) {
		TestNGScenario sc = stepExecutionTracker.getScenario() ;
		String[] strTags = sc.getGroups() ;
		ConfigurationManager.getBundle().addProperty("RunningCucumberTag", strTags[0]);
		
		super.beforExecute(stepExecutionTracker);
	}

	@Override
	public void afterExecute(StepExecutionTracker stepExecutionTracker) {
		ConfigurationManager.getBundle().clearProperty("RunningCucumberTag");
		super.afterExecute(stepExecutionTracker);
	}
	
}
