package com.manulife.ap.listeners;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.manulife.ap.steps.common.CommonSteps;;

public class TestCaseStatusListener implements ITestListener{

	
	@Override
	public void onTestFailure(ITestResult result) {		
		
		com.quantum.steps.PerfectoApplicationSteps.switchNativeContext();		
		System.out.println("-----------------------------handle for test case failed----------------------");
		boolean bCont = true; 
		QAFExtendedWebElement back = new QAFExtendedWebElement("iOs.BACK");
		while(back.isPresent()) {
			back.click();
			if(new QAFExtendedWebElement("letgo123.CreateAccountBtn").isPresent()) {
				bCont = false;
				return;
			}
			if(new QAFExtendedWebElement("mainmenu.ProgressLnk").isPresent() && !back.isPresent()){
				CommonSteps cs = new CommonSteps();
				cs.iLogOutMove5ApplicationiOS();
				bCont = false;
				return;
			}
			back = new QAFExtendedWebElement("iOs.BACK");
		}	
				
		if(new QAFExtendedWebElement("letgo123.CreateAccountBtn").isPresent()) {
			bCont = false;
			return;
		}
		
		if(bCont){
			CommonSteps cs = new CommonSteps();
			cs.iLogOutMove5ApplicationiOS();
		}

	}

	@Override
	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	


}
