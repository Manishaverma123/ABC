package com.manulife.ap.listeners;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.remote.DriverCommand;
import org.openqa.selenium.remote.Response;

import com.qmetry.qaf.automation.core.ConfigurationManager;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker;
import com.qmetry.qaf.automation.ui.webdriver.CommandTracker.Stage;
import com.qmetry.qaf.automation.ui.webdriver.QAFExtendedWebElement;
import com.qmetry.qaf.automation.ui.webdriver.QAFWebElementCommandAdapter;
import com.qmetry.qaf.automation.util.StringUtil;


public class SendKeysListener extends QAFWebElementCommandAdapter {
    @Override
    public void beforeCommand(QAFExtendedWebElement element, CommandTracker commandTracker) {
        if (commandTracker.getCommand().equalsIgnoreCase(DriverCommand.SEND_KEYS_TO_ELEMENT)) {
            //element.clear();
            // you access/modify any parameter!
        	
//            String value = String.valueOf(commandTracker.getParameters().get("value"));            
            CharSequence val = ((CharSequence [])commandTracker.getParameters().get("value"))[0];       	 	
            String myValueInput = String.valueOf(val);
             if (StringUtil.isBlank(myValueInput)) {
                // No need to send key
                // ignore actual command
                commandTracker.setResponce(new Response());
            }
             else{
            	 if(myValueInput.matches("<.+>")){
	            	 String strRunningTag="" ;            
	                 String strData="";
	                 String realData="" ;
	                 String[] arrValue ;
	                 	                                      
	                 strRunningTag = ConfigurationManager.getBundle().getString("RunningCucumberTag") ;
	                 strData = ConfigurationManager.getBundle().getString(strRunningTag);	                 
	                 
	                 if(strData==null) {
	                	 System.out.println("*********Test Data file is not contain "  + strRunningTag + " parameter value(s)******");
	                	 //ignore actual command
	                	 strData="";
	                	 commandTracker.setResponce(new Response());
	                 }else {	                 
		                 if(!strData.isEmpty()) {
		                	 arrValue = strData.split(",");	                 
			                 for(int i=0;i<arrValue.length;i++) {
			                	 //System.out.println("param " + i + ": " + arrValue[i]);
			                	 if(arrValue[i].matches(myValueInput + ".+")) {
			                		 realData=arrValue[i].replaceAll(myValueInput, "");
			                		 break;
			                	 }
			                 }
//			                 System.out.println("running tag : " + strRunningTag);
//			                 System.out.println("real data : " + realData);
			                 ((CharSequence [])commandTracker.getParameters().get("value"))[0]=realData;
		                 }
	                 }
            	 }            	 
            	 
             }
                       
        }
    }
}


