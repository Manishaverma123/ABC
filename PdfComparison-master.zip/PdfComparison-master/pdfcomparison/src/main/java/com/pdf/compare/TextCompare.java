package com.pdf.compare;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Properties;

//import org.apache.commons.lang.*;

public class TextCompare {

        public static void main(String[] args) throws Exception {

            FileReader freader = new FileReader("config.properties");
            Properties p = new Properties();
            p.load(freader);
            PdfReader reader = null, reader1 = null;
            String diff = "";
            int counter = 0;
            final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
            Timestamp ts = new Timestamp(System.currentTimeMillis());
            String logPath = p.getProperty("LogFile") + "\\" + sdf.format(ts)
                    + ".txt";
            FileWriter fileWriter = null;
            StringBuilder sb = new StringBuilder();
            sb.append("PDF comparison log:");
            sb.append(System.lineSeparator());
            sb.append(System.lineSeparator());
            try {

                fileWriter = new FileWriter(logPath, true);
                reader = new PdfReader(p.getProperty("PDFdir") + "\\"
                        + p.getProperty("BasePDF") + ".pdf");
                reader1 = new PdfReader(p.getProperty("PDFdir") + "\\"
                        + p.getProperty("AppsPDF") + ".pdf");

                File outputFile = new File(logPath);
                outputFile.createNewFile();
                int pages = reader.getNumberOfPages();

                for (int j = 1; j <= pages; j++) {
                    String textFromPage = PdfTextExtractor.getTextFromPage(reader,
                            j);

                    String textFromPage1 = PdfTextExtractor.getTextFromPage(
                            reader1, j);
                    String[] text = textFromPage.split("\n");
                    String[] text1 = textFromPage1.split("\n");
                    for (int i = 0; i < text.length; i++) {

                        diff = StringUtils.difference(text[i], text1[i]);
                        if (diff != null && !diff.isEmpty()) {
                            int k=i+1;
                            System.out.println("PDF Page Number : " + j
                                    + " , Difference found in line : " + k
                                    + " & Different Text Starting with : " + diff);
                            sb.append("PDF Page Number : " + j
                                    + " , Difference found in line : " + k
                                    + " & Difference Text Starting with : " + diff);
                            sb.append(System.lineSeparator());
                            sb.append(System.lineSeparator());
                            diff = "";
                            counter++;

                        }
                    }

                }

                if (counter == 0) {
                    sb.append(System.lineSeparator());
                    sb.append(System.lineSeparator());
                    sb.append("No Difference found in PDF");
                }
                reader.close();
                reader1.close();

            } catch (IOException e) {
                System.out.println("File not found");

                if (reader == null) {
                    sb.append(System.lineSeparator());
                    sb.append("Base PDF not found in PDF folder");

                } else {
                    sb.append(System.lineSeparator());
                    sb.append("Apps generated PDF not found in PDF folder");
                }
            }
            String everything = sb.toString();
            fileWriter.write(everything);

            fileWriter.close();

        }

    }















