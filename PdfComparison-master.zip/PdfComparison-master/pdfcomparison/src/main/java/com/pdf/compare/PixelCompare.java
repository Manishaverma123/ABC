package com.pdf.compare;

import com.testautomationguru.utility.CompareMode;
import com.testautomationguru.utility.PDFUtil;
import de.redsix.pdfcompare.PdfComparator;


import java.io.*;
import java.util.Properties;
import java.util.logging.Level;

public class PixelCompare {

    public static void main(String[] args)throws Exception{

        PrintStream myconsole;


            File mylogs = new File("C:\\Jar\\PixelCompareResult\\pixelcompare_report.txt");
            myconsole = new PrintStream(mylogs);
            System.setOut(myconsole);
            System.setErr(myconsole);



        String file1,file2,results;

        FileReader freader = new FileReader("config.properties");
        Properties p = new Properties();
        p.load(freader);

        file1= p.getProperty("PDFdir")+ p.getProperty("BasePDF") + ".pdf";
        file2= p.getProperty("PDFdir")+ p.getProperty("AppsPDF") + ".pdf";
        results= p.getProperty("Result");

        PDFUtil pdfUtil = new PDFUtil();

        pdfUtil.setCompareMode(CompareMode.VISUAL_MODE);
        pdfUtil.compare(file1, file2);

//if you need to store the result
        pdfUtil.highlightPdfDifference(true);
        new PdfComparator(file1, file2).compare().writeTo(results);

        Boolean isEquals= new PdfComparator(file1, file2).compare().writeTo(results);

        System.out.println(isEquals);

//        myconsole.close();
//
//        Console cnsl = null;
//        //Create a console object.
//        cnsl = System.console();


            if (isEquals) {
                System.out.println("Both PDF's are same!");
            }

            if (!isEquals) {
                System.out.println("Differences found!");
            }

//        cnsl.flush();
        myconsole.close();

    }












}
